CREATE TABLE `user` (
  `uid` int(11) NOT NULL,
  `username` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `name` text COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'user.png',
  `meta` text COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `date` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `activation_key` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `role` enum('Admin','Author','User') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'User'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `user` (`uid`, `username`, `email`, `name`, `password`, `image`, `meta`, `status`, `date`, `activation_key`, `role`) VALUES
(1, 'satyam', 'itvision.biz@gmail.com', 'सत्यम मिश्रा', '42fa65fad8326ac51712692e36d6fb25', 'user.png', '', 'Active', '2021-05-22T00:05:46+05:30', '', 'Admin'),
(4, 'ishan', 'aurangabadnow.in@gmail.com', 'Aurangabad Now Desk', '42fa65fad8326ac51712692e36d6fb25', 'user.png', '', 'Active', '2021-05-24T17:14:22+05:30', '', 'Admin');

CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `url` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `site_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `logo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `favicon` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `meta_description` text COLLATE utf8_unicode_ci NOT NULL,
  `meta_keywords` text COLLATE utf8_unicode_ci NOT NULL,
  `social` text COLLATE utf8_unicode_ci NOT NULL,
  `below_article` text COLLATE utf8_unicode_ci,
  `top_menu` int(11) NOT NULL,
  `main_menu` int(11) NOT NULL,
  `mobile_menu` int(11) NOT NULL,
  `footer_menu` int(11) NOT NULL,
  `entry_pass` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `settings` (`id`, `url`, `site_name`, `logo`, `favicon`, `meta_description`, `meta_keywords`, `social`, `below_article`, `top_menu`, `main_menu`, `mobile_menu`, `footer_menu`, `entry_pass`) VALUES
(1, 'https://aurangabadnow.live/', 'Aurangabad Now-Aurangabad News in Hindi: News, Events and Videos', 'logo.png', 'favicon.png', 'Aurangabad News in Hindi (औरंगाबाद समाचार) - Read Latest Aurangabad News Headlines from Aurangabad Local News Paper. Find Aurangabad Hindi News, Aurangabad Local News, Aurangabad News Paper, Aurangabad Latest News, Aurangabad Breaking News, Aurangabad City News stories and in-depth coverage', 'Aurangabad News, Aurangabad News in Hindi, औरंगाबाद समाचार, Aurangabad News Paper, Aurangabad News Today, Aurangabad City News, Aurangabad Local News, Aurangabad Hindi News, Aurangabad Latest News, Aurangabad News Headlines, Dainik Jagran Aurangabad', '[{\"facebook\":\"aurangabadnowdotin\"},{\"twitter\":\"aurangabadnowdotin\"}]', 'औरंगाबाद, बिहार की सभी लेटेस्ट खबरों और विडियोज को देखने के लिए लाइक करिए हमारा <a href=\"https://www.facebook.com/aurangabadnow.in\" target=\"_blank\" rel=\"noreferrer noopener\">फेसबुक पेज </a> , आप हमें <a href=\"https://news.google.com/publications/CAAqBwgKMOCepgswyKm-Aw\" target=\"_blank\" rel=\"noreferrer noopener\">Google News</a> पर भी फॉलो कर सकते हैं।', 3, 10, 10, 6, 47426);


CREATE TABLE `advertisement` (
  `id` int(11) NOT NULL,
  `top_ad` text COLLATE utf8_unicode_ci,
  `in_article_ad` text COLLATE utf8_unicode_ci,
  `in_article_ad2` text COLLATE utf8_unicode_ci,
  `in_article_ad3` text COLLATE utf8_unicode_ci,
  `below_article_ad` text COLLATE utf8_unicode_ci,
  `sidebar_ad` text COLLATE utf8_unicode_ci,
  `footer_ad` text COLLATE utf8_unicode_ci,
  `homepage_feed_ad` text COLLATE utf8_unicode_ci,
  `category_feed_ad` text COLLATE utf8_unicode_ci,
  `homepage_sidebar_ad` text COLLATE utf8_unicode_ci
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `automatic` (
  `id` int(11) NOT NULL,
  `campaign_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `feed_url` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `feed_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `post_status` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `category` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `tags` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `change_text` mediumtext COLLATE utf8_unicode_ci,
  `strip_tag` text COLLATE utf8_unicode_ci,
  `author` int(11) NOT NULL,
  `date` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` enum('Active','Stopped') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Active'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `automatic_post` (
  `id` int(11) NOT NULL,
  `post_url` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `date` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `campaign_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


CREATE TABLE `breaking` (
  `bid` int(11) NOT NULL,
  `message` text COLLATE utf8_unicode_ci NOT NULL,
  `time` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` enum('Active','Deactive') COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


CREATE TABLE `category` (
  `cid` int(11) NOT NULL,
  `slug` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8_unicode_ci,
  `parent` int(11) DEFAULT '0',
  `status` enum('Active','Deactive') COLLATE utf8_unicode_ci DEFAULT 'Active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `category` (`cid`, `slug`, `name`, `description`, `parent`, `status`) VALUES
(1, 'uncategorized', '', NULL, 0, 'Active');

CREATE TABLE `media` (
  `id` int(11) NOT NULL,
  `date` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `meta` text COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


CREATE TABLE `menu` (
  `mid` int(11) NOT NULL,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `location` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `item` text COLLATE utf8_unicode_ci NOT NULL,
  `status` enum('Active','Disabled') COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE `page` (
  `pid` int(11) NOT NULL,
  `slug` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `title` text COLLATE utf8_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8_unicode_ci,
  `featured_image` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'default.png',
  `status` enum('Draft','Published','Modified','Trashed') COLLATE utf8_unicode_ci NOT NULL,
  `publish_date` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `modified_date` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `page` (`pid`, `slug`, `title`, `content`, `featured_image`, `status`, `publish_date`, `modified_date`) VALUES
(1, 'contact-us', 'Contact Us', '<p>You can contact to us through:</p><table class=\"table table-bordered\"><tbody><tr><td style=\"text-align: center; \">Email</td><td style=\"text-align: center;\"><p>connect@aurangabadnow.live<br></p></td></tr><tr><td style=\"text-align: center; \">Call or WhatsApp</td><td style=\"text-align: center;\">+91 947 00 30 829</td></tr><tr><td style=\"text-align: center; \">Facebook</td><td><p style=\"text-align: center; \"><a href=\"https://facebook.com/aurangabad now.in\" target=\"_blank\">facebook.com/aurangabadnow.in</a><br></p></td></tr></tbody></table><p><br></p>																', 'default.png', 'Published', '2021-10-15T13:12:21+05:30', '2021-10-15T13:12:21+05:30');


CREATE TABLE `post` (
  `aid` int(11) NOT NULL,
  `slug` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `subtitle` text COLLATE utf8_unicode_ci,
  `source` text COLLATE utf8_unicode_ci,
  `content` longtext COLLATE utf8_unicode_ci,
  `highlights` text COLLATE utf8_unicode_ci,
  `cid` varchar(100) COLLATE utf8_unicode_ci DEFAULT '0',
  `tags` text COLLATE utf8_unicode_ci,
  `status` enum('Published','Draft','Trashed') COLLATE utf8_unicode_ci DEFAULT NULL,
  `publish_date` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `modified_date` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `place` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `news_source` text COLLATE utf8_unicode_ci,
  `modified_by` int(11) DEFAULT NULL,
  `featured_image` varchar(255) COLLATE utf8_unicode_ci DEFAULT 'default.webp',
  `post_format` enum('Standard','Photo Gallery','Video','Audio') COLLATE utf8_unicode_ci DEFAULT 'Standard',
  `author` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_description` text COLLATE utf8_unicode_ci,
  `meta_keywords` text COLLATE utf8_unicode_ci,
  `site_title` varchar(160) COLLATE utf8_unicode_ci DEFAULT NULL,
  `copyright` varchar(100) COLLATE utf8_unicode_ci DEFAULT 'Aurangabad Now'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `post` (`aid`, `slug`, `title`, `subtitle`, `source`, `content`, `highlights`, `cid`, `tags`, `status`, `publish_date`, `modified_date`, `place`, `news_source`, `modified_by`, `featured_image`, `post_format`, `author`, `meta_description`, `meta_keywords`, `site_title`, `copyright`) VALUES
(1, 'bihar-corona-update-एक्टिव-केस-70-हजार-से-कम-24-घंटे-में-मिले-5-920-पॉजिटिव-मरीज-96-की-मौत', 'Bihar Corona Update: एक्टिव केस 70 हजार से कम, 24 घंटे में मिले 5,920 पॉजिटिव मरीज; 96 की मौत', '', NULL, '<p style=\"margin: 15px 0px; padding: 0px; box-sizing: border-box; font-size: 20px; font-family: Cambay, \'Noto Sans\', \'Hind Siliguri\', \'Hind Vadodara\', \'Baloo Paaji 2\', sans-serif; background-color: #ffffff; text-align: justify;\"><span style=\"margin: 0px; padding: 0px; box-sizing: border-box; font-weight: bolder;\">पटना:</span> बिहार में बीते 24 घंटे में कोरोना के नए 5,920 पॉजिटिव मरीज मिले हैं वहीं 11,216 संक्रमित स्वस्थ भी हुए हैं. बिहार में अब कोरोना के एक्टिव केस की संख्या घटकर 70 हजार से नीचे आ गई है. 24 घंटे में इस महामारी ने सूबे के 96 लोगों की जान ले ली है. वहीं, स्वास्थ्य विभाग ने दावा किया है कि 24 घंटे के अंदर प्रदेश में 1,25,342 लोगों के टेस्ट किए गए हैं.  </p>\r\n<p style=\"margin: 15px 0px; padding: 0px; box-sizing: border-box; font-size: 20px; font-family: Cambay, \'Noto Sans\', \'Hind Siliguri\', \'Hind Vadodara\', \'Baloo Paaji 2\', sans-serif; background-color: #ffffff; text-align: justify;\"><span style=\"margin: 0px; padding: 0px; box-sizing: border-box; font-weight: bolder;\">मौत के आंकड़ों में अभी नहीं आई है कमी</span></p>\r\n<p style=\"margin: 15px 0px; padding: 0px; box-sizing: border-box; font-size: 20px; font-family: Cambay, \'Noto Sans\', \'Hind Siliguri\', \'Hind Vadodara\', \'Baloo Paaji 2\', sans-serif; background-color: #ffffff; text-align: justify;\">राज्य में बीते पांच दिनों से संक्रमण के नए मामले तेजी से कम हो रहे हैं. रविवार को 6,894, शनिवार को 7,336, शुक्रवार को 7,494 और गुरुवार को 7,752 संक्रमित मिले थे. हालांकि मौत के आंकड़ों में अभी कमी नहीं आई है. सोमवार को विभाग ने 96 लोगों के मौत की पुष्टि की. इसके पूर्व रविवार को 89 लोगों की जान गई थी, जबकि शनिवार को 73 की जान कोरोना संक्रमण से गई थी. </p>\r\n<p style=\"margin: 15px 0px; padding: 0px; box-sizing: border-box; font-size: 20px; font-family: Cambay, \'Noto Sans\', \'Hind Siliguri\', \'Hind Vadodara\', \'Baloo Paaji 2\', sans-serif; background-color: #ffffff; text-align: justify;\"><span style=\"margin: 0px; padding: 0px; box-sizing: border-box; font-weight: bolder;\">24 घंटे में 11,216 लोग कोरोना से हो चुके स्वस्थ</span></p>\r\n<p style=\"margin: 15px 0px; padding: 0px; box-sizing: border-box; font-size: 20px; font-family: Cambay, \'Noto Sans\', \'Hind Siliguri\', \'Hind Vadodara\', \'Baloo Paaji 2\', sans-serif; background-color: #ffffff; text-align: justify;\">सोमवार को पटना में 1,189 संक्रमित मिले. रविवार को यहां से 1,103, शनिवार को 1,202 संक्रमित मिले थे. कोरोना संक्रमण को पराजित करने वालों की संख्या तेजी से बढ़ी है जिसकी वजह से एक्टिव केस के आंकड़े भी कम हुए हैं. स्वास्थ्य विभाग की ओर से जारी रिपोर्ट के अनुसार सोमवार को बीते 24 घंटे में 11,216 लोगों ने कोरोना से जंग जीता है. इसके साथ ही एक्टिव केस घटकर 69,697 रह गए हैं, जो कि रविवार को 75,089 थे.</p>								', 'सोमवार को पटना में 1,189 संक्रमित मिले. रविवार को यहां से 1,103, शनिवार को 1,202 संक्रमित मिले थे.|24 घंटे के अंदर प्रदेश में 1,25,342 लोगों के टेस्ट किए गए हैं, जबकि 11,216 लोग इससे स्वस्थ भी हुए हैं.', '1', 'corona bihar', 'Published', '2021-05-18T00:28:24+05:30', '2021-06-19T13:57:59+05:30', '', 'Abp Live', NULL, 'corona_bihar.webp', 'Standard', '1', '', '', '', 'Aurangabad Now');

CREATE TABLE `tag` (
  `tid` int(11) NOT NULL,
  `slug` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


CREATE TABLE `verify` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `id_number` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `file_url` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`uid`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);
  
--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `advertisement`
--
ALTER TABLE `advertisement`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `automatic`
--
ALTER TABLE `automatic`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `automatic_post`
--
ALTER TABLE `automatic_post`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `breaking`
--
ALTER TABLE `breaking`
  ADD PRIMARY KEY (`bid`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`cid`),
  ADD UNIQUE KEY `slug` (`slug`),
  ADD KEY `parent` (`parent`);

--
-- Indexes for table `media`
--
ALTER TABLE `media`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`mid`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `page`
--
ALTER TABLE `page`
  ADD PRIMARY KEY (`pid`),
  ADD UNIQUE KEY `slug` (`slug`);

--
-- Indexes for table `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`aid`),
  ADD UNIQUE KEY `slug` (`slug`);

--
-- Indexes for table `tag`
--
ALTER TABLE `tag`
  ADD PRIMARY KEY (`tid`),
  ADD UNIQUE KEY `slug` (`slug`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `verify`
--
ALTER TABLE `verify`
  ADD PRIMARY KEY (`id`);
COMMIT;
