    
               <div id="loading" class="mx-auto my-auto" style="position:fixed;letf:0;z-index:999999999">
                    <img src="https://flevix.com/wp-content/uploads/2019/07/Clock-Loading.gif" />  
                 </div>
                <div class="row">
                    <div class="col-12 mb-4">
                        <h3>Campaigns</h3>
                    </div>
					<div class="col-md-4 col-12">
					            <h5>Edit Campaign</h5>
					            <form action="" method="post" id="edit">
							    <div class="form-group">
							        <label for="name">Campaign Name</label>
									<input type="text" class="form-control"id="name" name="name" value="<?php echo $campaign['campaign_name']; ?>" required>
								</div>
								<div class="form-group">
							        <label for="url">Feed URL</label>
									<input type="text" class="form-control" value="<?php echo $campaign['feed_url']; ?>" placeholder="Enter Feed URL" name="url" required>
								</div>
								<div class="form-group row">
								    <label class="form-label col-6">Feed Type</label>
								    <select class="form-control col-6" name="feed_type">
								        <option value="RSS2" <?php if($campaign['feed_type']=="RSS2"){echo "selected";} ?>">RSS2</option>
								        <option value="Atom" <?php if($campaign['feed_type']=="Atom"){echo "selected";} ?>>Atom</option>
								    </select>
								</div>
								<div class="form-group row">
								    <label class="form-label col-6">Status</label>
								    <select class="form-control col-6" name="status">
								        <option value="Active" <?php if($campaign['status']=="Active"){echo "selected";} ?>>Active</option>
								        <option value="Stopped" <?php if($campaign['status']=="Stopped"){echo "selected";} ?>>Stopped</option>
								    </select>
								</div>
								<div class="form-group">
							        <label for="replace">Replace Texts from Content</label>
									<input type="text" class="form-control" id="replace" value="<?php echo $campaign['change_text']; ?>" placeholder="Enter comma seperted" name="change_text">
								</div>
								<div class="form-group row">
							        <label class="col-6">Strip Html Tags from Content</label>
							        <div class="col-6">
							            
    									<input type="checkbox" onload='handleChange(this);' onchange='handleChange(this);' value="1" class="form-control my-2" id="strip_tag_status" name="strip_tag_status" <?php if(json_decode($campaign['strip_tag'],TRUE)['status']==1){echo "checked";} ?>>
    									
    									<textarea class="form-control my-2" name="strip_tag_allowed" id="strip_tag_allowed" placeholder="Enter Allowed HTML Tags" style="display:none"><?php echo json_decode($campaign['strip_tag'],TRUE)['allowed']; ?></textarea>
									</div>
								</div>
								<div class="form-group row">
							        <label class="form-label col-6">Category</label>
									<select class="form-control col-6" id="category" name="category[]" multiple required>
									   
									</select>
								</div>
								<div class="form-group row">
								    <label class="form-label col-6">Post Status</label>
								    <select class="form-control col-6" name="post_status">
								        <option value="Published" <?php if($campaign['post_status']=="Published"){echo "selected";} ?>>Published</option>
								        <option value="Draft" <?php if($campaign['post_status']=="Draft"){echo "selected";} ?>>Draft</option>
								    </select>
								</div>
								<div class="form-group row">
									<label class="form-label col-6">User</label>
									<select class="form-control col-6" id="author" name="author" required>
									    <option value="">--Select Author--</option>
									    <?php foreach($users as $user){ ?>
									        <option value="<?php echo $user['uid']; ?>" <?php if($campaign['author']==$user['uid']){echo "selected";} ?>><?php echo $user['name']; ?></option>
									    <?php } ?>
									</select>
								</div>
								<div class="form-group">
							        <label for="tags">Tags</label>
									<input type="text" class="form-control" id="tags" value="<?php echo $campaign['tags']; ?>" placeholder="Enter comma seperted tags" name="tags" required>
								</div>
								<div class="m-2">
									<button type="submit" id="submit" class="btn btn-sm btn-success">Update Campaign</button>
								</div>
								</form>
							
					</div>
					
				</div>
			</div>
          
<script>
	            var $loading = $('#loading').hide();
                   //Attach the event handler to any element
                   $(document)
                     .ajaxStart(function () {
                        //ajax request went so show the loading image
                         $loading.show();
                     })
                   .ajaxStop(function () {
                       //got response so hide the loading image
                        $loading.hide();
                    });


	$(document).ready(function(){
    $("#submit").click(function(){
        
        var data = $("#edit").serialize();
            
            $.ajax({
                url:"<?php echo site_url('automatic/update/'.$campaign['id']);?>",
                type:'post',
                data:data,
                success:function(response){
					alert(response)
                }
            });
			
		});
	});


function select(){
            $.ajax({
				type:'post',
				dataType:'html',
                url:"<?php echo site_url('admin/category/option/'.$campaign['category']);?>",
                success:function(response){
                    $("#category").append(response);
                }
            });
	}
	$(document).ready(select());
	
function handleChange(checkbox) {
    if(checkbox.checked == true){
        document.getElementById("strip_tag_allowed").style.display="block";
    }else{
        document.getElementById("strip_tag_allowed").style.display="none";
    }
}


    
</script>