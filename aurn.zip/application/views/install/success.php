<!doctype html>
<?php 
 $tp_url="http://".$_SERVER['HTTP_HOST'] . str_replace('index.php/install','',$_SERVER['REQUEST_URI']);
 $last_sl=substr($tp_url,(strlen($tp_url)-1),strlen($tp_url));
 if($last_sl=='/'){
	$tp_url=$tp_url; 
 }else{
	$tp_url=$tp_url."/";  
 }
 
 ?>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta2/css/all.min.css" integrity="sha512-YWzhKL2whUzgiheMoBFwW8CKV4qpHQAEuvilg9FAn5VJUDwKZZxkJNuGM4XkWuk94WCrrwslk8yWNGmY1EduTA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title><?php echo $title; ?></title>
	
  </head>
  <body>
	<div class="row">
		<div class="col-md-8 col-12 mx-auto my-3">
			<div class="justify-content-center" style="min-height:100vh">
				<div class="card">
					<div class="card-body">
						<center>
							<h1>Tankaar Press Installation Successful!</h1>
						</center>
					</div>
					<div class="card-body">
						
						<h2>Congrts! :)</h2> 
						<p>You have successfully installed Tankaar Press at <a href="<?php echo $url; ?>"><?php echo $url; ?></a>. Kindly login to Admin Panel at <a href="<?php echo $url.'login/admin/'.$entry_pass; ?>"><?php echo $url.'login/admin/'.$entry_pass; ?></a> </p>
						<p>Your Login Details are: <br>
						Username: <?php echo $username; ?><br>
						Password: <?php echo $password; ?><br>
						</p>	

						<p class="center">&copy; 2021 Tankaar Press</p>
					</div>
				</div>
			</div>
		</div>
	</div>
		
    

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </body>
</html>