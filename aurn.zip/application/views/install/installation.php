<!doctype html>
<?php 
 $tp_url="http://".$_SERVER['HTTP_HOST'] . str_replace('index.php/install','',$_SERVER['REQUEST_URI']);
 $last_sl=substr($tp_url,(strlen($tp_url)-1),strlen($tp_url));
 if($last_sl=='/'){
	$tp_url=$tp_url; 
 }else{
	$tp_url=$tp_url."/";  
 }
 
 ?>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta2/css/all.min.css" integrity="sha512-YWzhKL2whUzgiheMoBFwW8CKV4qpHQAEuvilg9FAn5VJUDwKZZxkJNuGM4XkWuk94WCrrwslk8yWNGmY1EduTA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title><?php echo $title; ?></title>
	<style>
		.multisteps-form__progress {
		  display: grid;
		  grid-template-columns: repeat(auto-fit, minmax(0, 1fr));
		}

		.multisteps-form__progress-btn {
		  transition-property: all;
		  transition-duration: 0.15s;
		  transition-timing-function: linear;
		  transition-delay: 0s;
		  position: relative;
		  padding-top: 20px;
		  color: rgba(108, 117, 125, 0.7);
		  text-indent: -9999px;
		  border: none;
		  background-color: transparent;
		  outline: none !important;
		  cursor: pointer;
		}

		@media (min-width: 500px) {
		  .multisteps-form__progress-btn {
			text-indent: 0;
		  }
		}

		.multisteps-form__progress-btn:before {
		  position: absolute;
		  top: 0;
		  left: 50%;
		  display: block;
		  width: 13px;
		  height: 13px;
		  content: '';
		  -webkit-transform: translateX(-50%);
				  transform: translateX(-50%);
		  transition: all 0.15s linear 0s, -webkit-transform 0.15s cubic-bezier(0.05, 1.09, 0.16, 1.4) 0s;
		  transition: all 0.15s linear 0s, transform 0.15s cubic-bezier(0.05, 1.09, 0.16, 1.4) 0s;
		  transition: all 0.15s linear 0s, transform 0.15s cubic-bezier(0.05, 1.09, 0.16, 1.4) 0s, -webkit-transform 0.15s cubic-bezier(0.05, 1.09, 0.16, 1.4) 0s;
		  border: 2px solid currentColor;
		  border-radius: 50%;
		  background-color: #fff;
		  box-sizing: border-box;
		  z-index: 3;
		}

		.multisteps-form__progress-btn:after {
		  position: absolute;
		  top: 5px;
		  left: calc(-50% - 13px / 2);
		  transition-property: all;
		  transition-duration: 0.15s;
		  transition-timing-function: linear;
		  transition-delay: 0s;
		  display: block;
		  width: 100%;
		  height: 2px;
		  content: '';
		  background-color: currentColor;
		  z-index: 1;
		}

		.multisteps-form__progress-btn:first-child:after {
		  display: none;
		}

		.multisteps-form__progress-btn.js-active {
		  color: #007bff;
		}

		.multisteps-form__progress-btn.js-active:before {
		  -webkit-transform: translateX(-50%) scale(1.2);
				  transform: translateX(-50%) scale(1.2);
		  background-color: currentColor;
		}

		.multisteps-form__form {
		  position: relative;
		}

		.multisteps-form__panel {
		  position: absolute;
		  top: 0;
		  left: 0;
		  width: 100%;
		  height: 0;
		  opacity: 0;
		  visibility: hidden;
		}

		.multisteps-form__panel.js-active {
		  height: auto;
		  opacity: 1;
		  visibility: visible;
		}
		.multisteps-form__panel[data-animation="scaleIn"] {
		  -webkit-transform: scale(0.9);
				  transform: scale(0.9);
		}

		.multisteps-form__panel[data-animation="scaleIn"].js-active {
		  transition-property: all;
		  transition-duration: 0.2s;
		  transition-timing-function: linear;
		  transition-delay: 0s;
		  -webkit-transform: scale(1);
				  transform: scale(1);
		}
	</style>
  </head>
  <body>
	<div class="row">
		<div class="col-md-8 col-12 mx-auto my-3">
			<div class="justify-content-center">
				<div class="card">
					<div class="card-body">
						<center>
							<h1>Welcome to Tankaar Press</h1>
							<h2>Tankaar Press Installation Wizard</h2>
						</center>
					</div>
					<div class="card-body">
										<div class="multisteps-form">
										  <!--progress bar-->
										  <div class="row">
											<div class="col-12 col-lg-8 ml-auto mr-auto mb-4">
											  <div class="multisteps-form__progress">
												<button class="multisteps-form__progress-btn js-active" type="button" title="Site Info">Site Info</button>
												<button class="multisteps-form__progress-btn" type="button" title="Database">Database</button>
												<button class="multisteps-form__progress-btn" type="button" title="Additional Settings">Additional Settings</button>
												<button class="multisteps-form__progress-btn" type="button" title="Agreement">Agreement</button>
											  </div>
											</div>
										  </div>
										  <!--form panels-->
										  <div class="row">
											<div class="col-12 col-lg-8 m-auto">
											  <form class="multisteps-form__form" method="post" action="<?php echo 'http://'.$_SERVER['HTTP_HOST'].'/index.php/install/config_tp';?>">
											  <input type="hidden" value="" name="force_write">
												<!--single form panel-->
												<div class="multisteps-form__panel shadow p-4 rounded bg-white js-active" data-animation="scaleIn">
												  <h3 class="multisteps-form__title">Site Info</h3>
												  <div class="multisteps-form__content">
													<div class="form-group mt-4">
														<input class="multisteps-form__input form-control" name="sitename" type="text" placeholder="Site Name" required>
													</div>
													<div class="form-group mt-4">
														<input class="multisteps-form__input form-control" name="base_url" type="text" placeholder="Site Address followed by slash (/)" required>
													</div>
													
													<div class="button-row d-flex mt-4">
													  <button class="btn btn-primary ml-auto js-btn-next" type="button" title="Next">Next</button>
													</div>
												  </div>
												</div>
												<!--single form panel-->
												<div class="multisteps-form__panel shadow p-4 rounded bg-white" data-animation="scaleIn">
												  <h3 class="multisteps-form__title">Database</h3>
												  <div class="multisteps-form__content">
													<div class="form-group mt-4">
														<input class="multisteps-form__input form-control" name="hostname" type="text" value="localhost" placeholder="Hostname" required>
													</div>
													<div class="form-group mt-4">
														<input class="multisteps-form__input form-control" name="database" type="text" placeholder="Database Name" required>
													</div>
													<div class="form-group mt-4">
														<input class="multisteps-form__input form-control" name="username" type="text" placeholder="Database User Name" required>
													</div>
													<div class="form-group mt-4">
														<input class="multisteps-form__input form-control" name="password" type="password" placeholder="Database Password" >
													</div>
													<div class="form-group mt-4">
														<input class="multisteps-form__input form-control" name="db_prefix" type="text" placeholder="Database Prefix">
													</div>
													
													<div class="button-row d-flex mt-4">
													  <button class="btn btn-primary js-btn-prev" type="button" title="Prev">Prev</button>
													  <button class="btn btn-primary ml-auto js-btn-next" type="button" title="Next">Next</button>
													</div>
												  </div>
												</div>
												<!--single form panel-->
												<div class="multisteps-form__panel shadow p-4 rounded bg-white" data-animation="scaleIn">
												  <h3 class="multisteps-form__title">Additional Settings</h3>
												  <div class="multisteps-form__content">
													<div class="form-group mt-4">
														<input class="multisteps-form__input form-control" name="admin_username" type="text" placeholder="Admin User Name" required>
													</div>
													<div class="form-group mt-4">
														<input class="multisteps-form__input form-control" name="admin_email" type="email" placeholder="Admin Email" required>
													</div>
													<div class="form-group mt-4">
														<input class="multisteps-form__input form-control" name="admin_password" type="pass" placeholder="Admin Password" required>
													</div>
													<div class="form-group mt-4">
														<input class="multisteps-form__input form-control" name="entry_pass" type="pass" placeholder="Login Entry Pass (Eg. 123456)" required>
														<small>Entry Pass is a special security feature which is used during access admin login</small>
													</div>
													<div class="button-row d-flex mt-4">
													  <button class="btn btn-primary js-btn-prev" type="button" title="Prev">Prev</button>
													  <button class="btn btn-primary ml-auto js-btn-next" type="button" title="Next">Next</button>
													</div>
												  </div>
												</div>
												<!--single form panel-->
												<div class="multisteps-form__panel shadow p-4 rounded bg-white" data-animation="scaleIn">
												  <h3 class="multisteps-form__title">Agreement</h3>
												  <div class="multisteps-form__content">
													By clicking <b>Install</b>, I am agree to the Tankaar Press's Usage Polices, Terms & Conditions given below:<br>
													<div class="form-row mt-4">
													  <textarea rows="10" class="multisteps-form__textarea form-control" readonly><?php include('terms.php');?></textarea>
													</div>
													<div class="button-row d-flex mt-4">
													  <button class="btn btn-primary js-btn-prev" type="button" title="Prev">Prev</button>
													  <button class="btn btn-success ml-auto" type="submit" title="Send">Install</button>
													</div>
												  </div>
												</div>
											  </form>
											 </div>
										  </div>
										</div>
					</div>
				</div>
			</div>
		</div>
	</div>
		
    

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
	<script>
		//DOM elements
			const DOMstrings = {
			  stepsBtnClass: 'multisteps-form__progress-btn',
			  stepsBtns: document.querySelectorAll(`.multisteps-form__progress-btn`),
			  stepsBar: document.querySelector('.multisteps-form__progress'),
			  stepsForm: document.querySelector('.multisteps-form__form'),
			  stepsFormTextareas: document.querySelectorAll('.multisteps-form__textarea'),
			  stepFormPanelClass: 'multisteps-form__panel',
			  stepFormPanels: document.querySelectorAll('.multisteps-form__panel'),
			  stepPrevBtnClass: 'js-btn-prev',
			  stepNextBtnClass: 'js-btn-next' };


			//remove class from a set of items
			const removeClasses = (elemSet, className) => {

			  elemSet.forEach(elem => {

				elem.classList.remove(className);

			  });

			};

			//return exect parent node of the element
			const findParent = (elem, parentClass) => {

			  let currentNode = elem;

			  while (!currentNode.classList.contains(parentClass)) {
				currentNode = currentNode.parentNode;
			  }

			  return currentNode;

			};

			//get active button step number
			const getActiveStep = elem => {
			  return Array.from(DOMstrings.stepsBtns).indexOf(elem);
			};

			//set all steps before clicked (and clicked too) to active
			const setActiveStep = activeStepNum => {

			  //remove active state from all the state
			  removeClasses(DOMstrings.stepsBtns, 'js-active');

			  //set picked items to active
			  DOMstrings.stepsBtns.forEach((elem, index) => {

				if (index <= activeStepNum) {
				  elem.classList.add('js-active');
				}

			  });
			};

			//get active panel
			const getActivePanel = () => {

			  let activePanel;

			  DOMstrings.stepFormPanels.forEach(elem => {

				if (elem.classList.contains('js-active')) {

				  activePanel = elem;

				}

			  });

			  return activePanel;

			};

			//open active panel (and close unactive panels)
			const setActivePanel = activePanelNum => {

			  //remove active class from all the panels
			  removeClasses(DOMstrings.stepFormPanels, 'js-active');

			  //show active panel
			  DOMstrings.stepFormPanels.forEach((elem, index) => {
				if (index === activePanelNum) {

				  elem.classList.add('js-active');

				  setFormHeight(elem);

				}
			  });

			};

			//set form height equal to current panel height
			const formHeight = activePanel => {

			  const activePanelHeight = activePanel.offsetHeight;

			  DOMstrings.stepsForm.style.height = `${activePanelHeight}px`;

			};

			const setFormHeight = () => {
			  const activePanel = getActivePanel();

			  formHeight(activePanel);
			};

			//STEPS BAR CLICK FUNCTION
			DOMstrings.stepsBar.addEventListener('click', e => {

			  //check if click target is a step button
			  const eventTarget = e.target;

			  if (!eventTarget.classList.contains(`${DOMstrings.stepsBtnClass}`)) {
				return;
			  }

			  //get active button step number
			  const activeStep = getActiveStep(eventTarget);

			  //set all steps before clicked (and clicked too) to active
			  setActiveStep(activeStep);

			  //open active panel
			  setActivePanel(activeStep);
			});

			//PREV/NEXT BTNS CLICK
			DOMstrings.stepsForm.addEventListener('click', e => {

			  const eventTarget = e.target;

			  //check if we clicked on `PREV` or NEXT` buttons
			  if (!(eventTarget.classList.contains(`${DOMstrings.stepPrevBtnClass}`) || eventTarget.classList.contains(`${DOMstrings.stepNextBtnClass}`)))
			  {
				return;
			  }

			  //find active panel
			  const activePanel = findParent(eventTarget, `${DOMstrings.stepFormPanelClass}`);

			  let activePanelNum = Array.from(DOMstrings.stepFormPanels).indexOf(activePanel);

			  //set active step and active panel onclick
			  if (eventTarget.classList.contains(`${DOMstrings.stepPrevBtnClass}`)) {
				activePanelNum--;

			  } else {

				activePanelNum++;

			  }

			  setActiveStep(activePanelNum);
			  setActivePanel(activePanelNum);

			});

			//SETTING PROPER FORM HEIGHT ONLOAD
			window.addEventListener('load', setFormHeight, false);

			//SETTING PROPER FORM HEIGHT ONRESIZE
			window.addEventListener('resize', setFormHeight, false);
	</script>
  </body>
</html>