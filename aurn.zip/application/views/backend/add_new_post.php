<?php $logged_in=$this->session->userdata('logged_in'); ?>
<link href="/plugins/amsify/amsify.suggestags.css" rel="stylesheet" />

<script>

function replace_array(a, b, text) {
if (a.length != b.length) {
return false;
}
for (var i = 0; i < a. length; i++) {
var pat = new RegExp(a[i], 'g');
text = text.replace(pat, b[i]);
}
return text;
}

function conv_hi_to_en(text, method) {
//var text_en = text.replace(/\n/,"<br/>");

var hic = ['क','ख','ग','घ','च','छ','ज','झ','ट','ठ','ड','ढ','ण','त','थ','द','ध','न','प','फ','ब','भ','म','य','र','ल','व','श','ष','स','ह','ळ','ञ', 'ढ़', 'ड़','ख़'];
if (method == 'basic') {
var enc = ['ka','kha', 'ga','gha','cha','chha','ja','za','ta','__i__th__/i__a','da','__i__dh__/i__a','__i__n__/i__a','__i__t__/i__a','tha','__i__d__/i__a','dha','na','pa','fa','ba','bha','ma','ya','ra','la','va','sha','sha','sa','ha','__i__l__/i__a','nya','dh','d','kh'];
} else {
var enc = ['ka','kha','ga','gha','cha','chha','ja','jha','ta','tha','aa','dha','na','ta','tha','da','dha','na','pa','pha','ba','bha','ma','ya','ra','la','va','sha','sha','sa','ha','la','nya','dha','da','kha'];
}
var hih = ['क्','ख्','ग्','घ्','च्','छ्','ज्','झ्','ट्','ठ्','ड्','ढ्','ण्','त्','थ्','द्','ध्','न्','प्','फ्','ब्','भ्','म्','य्','र्','ल्','व्','श्','ष्','स्','ह्','ळ्','ञ्','ङ','ऽ', 'ड़'];
if (method == 'basic') {
var enh = ['k','kh', 'g','gh','ch','chh','j','z','t','__i__th__/i__','d','__i__dh__/i__','__i__n__/i__','__i__t__/i__','th','__i__d__/i__','dh','n','p','f','b','bh','m','y','r','l','v','sh','sh','s','h','__i__l__/i__','ny','n','’','d'];
} else {
var enh = ['k','kh','g','gh','ch','chh','j','z','t','th','d','dh','n','t','th','d','dh','n','p','f','b','bh','m','y','r','l','v','sh','sh','s','h','l','ny','n','’','d'];
}
var hiv = ['ओ','औ','आ','इ','ई','उ','ऊ','ए','ऐ','ऎ','ऒ','ऋ','ॐ','अ'];
if (method == 'basic') {
var env = ['o','au','aa','i','ee','u','oo','e','ai','e','au','hru','aum','a'];
} else {
var env = ['o','au','a','i','i','u','u','e','ai','e','au','ru','aum','a'];
}
var hivs = ['ि','ी','ु','ू','े','ै','ो','ौ','ॆ','ॊ','ं','ृ','्','ः','ा','ॉ'];
if (method == 'basic') {
var envs = ['i','ee','u','oo','e','ai','o','au','e','au','n','ru','','ah','a','au'];
} else {
var envs = ['i','i','u','u','e','ai','o','au','e','au','n','ru','','ah','a','au'];
}

var hin = ['०','१','२','३','४','५','६','७','८','९'];
var enn = ['0','1','2','3','4','5','6','7','8','9'];

var s = [];
var r = [];

for (var i = 0; i < hic.length; i++) {
for (var j = 0; j < hivs.length; j++) {
var s = new RegExp(hic[i] + hivs[j] + 'ઃ ', 'g');
var r = enh[i] + envs[j] + 'h' + envs[j] + ' ';
text_en = text.replace(s, r);
var s = new RegExp(hic[i] + hivs[j] + 'ઃ', 'g');
var r = enh[i] + envs[j] + 'h';
text_en = text_en.replace(s, r);
}
}

for (var i = 0; i < hic.length; i++) {
for (var j = 0; j < hivs.length; j++) {
var s = new RegExp(hic[i] + hivs[j] + 'ં', 'g');
var r = enh[i] + envs[j] + 'n';
text_en = text_en.replace(s, r);
}
}

for (var i = 0; i < hiv.length; i++) {
var s = new RegExp(hiv[i] + 'ં', 'g');
var r = env[i] + 'n';
text_en = text_en.replace(s, r);
}

for (var i = 0; i < hic.length; i++) {
for (var j = 0 ; j < hivs.length; j++) {
var s = new RegExp(hic[i] + hivs[j], 'g');
var r = enh[i] + envs[j];
text_en = text_en.replace(s, r);
}
}

text_en = replace_array(hih, enh, text_en);
text_en = replace_array(hivs, envs, text_en);
text_en = replace_array(hiv, env, text_en);
text_en = replace_array(hic, enc, text_en);
text_en = replace_array(hin, enn, text_en);

if (method == 'baps') {
for (var i = 0; i < enc.length; i++) {
var pat = new RegExp(enc[i] + ' ', 'g');
var rep = enh[i] + ' ';
text_en = text_en.replace(pat, rep);
}
for (var i = 0; i < enh.length; i++) {
for (var j = 0; j < enc.length; j++) {
var pat = new RegExp(enh[i] + enh[j] + ' ', 'g');
var rep = enh[i] + enc[j] + ' ';
text_en = text_en.replace(pat, rep);
}
}
var encomb = ['kh','gh','ch','chh','th','dh','th','dh','bh','sh','sh','ny'];
for (var i = 0; i < env.length; i++) {
for (var j = 0; j < encomb.length; j++) {
var pat = new RegExp(env[i] + encomb[j] + 'a ', 'g');
var rep = env[i] + encomb[j] + ' ';
text_en = text_en.replace(pat, rep);
}
}
}


/*
//capitalize first word in sentence
var lc = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'ā', 'ḍ', 'ĕ', 'ī', 'ḷ', 'ṇ', 'ŏ', 'ṛ', 'ṣ', 'ṭ', 'ū'];
var uc = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'Ā', 'Ḍ', 'Ĕ', 'Ī', 'Ḷ', 'Ṇ', 'Ŏ', 'Ṛ', 'Ṣ', 'Ṭ', 'Ū'];
for (var i = 0; i < lc.length; i++) {
var p1 = new RegExp('(\\.|\\?|!)\\s' + lc[i], 'g');
var p2 = new RegExp(',\\s("|“)' + lc[i], 'g');
var p3 = new RegExp('(\\."|\\.”)\\s' + lc[i], 'g');
var p4 = new RegExp('(\\.|\\?|!)\\s("|“)' + lc[i], 'g');
var p5 = new RegExp('(\\?”+\\?"|!”|!")\\s' + lc[i], 'g');
var p6 = new RegExp('("|”)\\s("|“)' + lc[i], 'g');
var p7 = new RegExp('^' + lc[i], "g");
var p8 = new RegExp('\n' + lc[i], "g");
text_en = text_en.replace(p1, '$1 ' + uc[i]);
text_en = text_en.replace(p2, ', $1' + uc[i]);
text_en = text_en.replace(p3, '$1 ' + uc[i]);
text_en = text_en.replace(p4, '$1 $2' + uc[i]);
text_en = text_en.replace(p5, '$1 ' + uc[i]);
text_en = text_en.replace(p6, '$1 $2' + uc[i]);
text_en = text_en.replace(p7, uc[i]);
text_en = text_en.replace(p8, '\n' + uc[i]);
}

//Post-processing fixes gna and trailing y
text_en = text_en.replace(/yvar\s/g,"ya");
text_en = text_en.replace(/y\s/g, 'ya ');
text_en = text_en.replace(/jnyaa/g, 'gnaa');
text_en = text_en.replace(/jnya/g, 'gna');
text_en = text_en.replace(/jny\s/g, 'gna');
text_en = text_en.replace(/svaa/g, 'swaa');
text_en = text_en.replace(/svā/g, 'swā');
text_en = text_en.replace(/‍/g,'');
text_en = text_en.replace(/‌/g,'');


*/

return text_en;
}
 
 
 
 
 
 
function convertToSlug(text) {
	var str=conv_hi_to_en(text,'barp');
  //replace all special characters | symbols with a space
  str = str.replace(/[`~!@#$%^&*()_\-+=\[\]{};:'"\\|\/,.<>?\s]/g, ' ').toLowerCase();
	
  // trim spaces at start and end of string
  str = str.replace(/^\s+|\s+$/gm,'');
	
  // replace space with dash/hyphen
  str = str.replace(/\s+/g, '-');	
  document.getElementById("slug").value= str;
  $("#slug").trigger( 'change' );
  //return str;
}



function slug_available(slug) {
        
     $.ajax({
        async: true,
        type: "POST",
        url: "<?php echo site_url('dashboard/check_slug');?>",
        data: {'slug' : slug,'type':'testseries_exam'},
        dataType: "text",
        success: function(msg){
             $("#check_slug").html(msg);
        }
    });
}

function upload_image(data) {
	
	var file_data=$("#slide_file_"+data).prop("files")[0]; 
	var form_data = new FormData(); // Creating object of FormData class
	form_data.append("file", file_data) // Appending parameter named file with properties of file_field to form_data
       
     $.ajax({
        async: true,
        type: "POST",
        url: "<?php echo site_url('admin/upload_img/628/1200');?>",
        dataType: 'script',
		cache: false,
		contentType: false,
		processData: false,
		data: form_data, 
        success: function(msg){
             $("#slide_file_"+data+"_url").val(msg);
        }
    });
}

	function showSource(){
		
		var format=$("#format :selected").val();
		if(format=="Video" || format=="Audio"){
			$("#source").show();
			$("#PhotoGallery").hide();
			$("#post-content").show();
			
		}else if(format=="Photo Gallery"){
			$("#PhotoGallery").show();
			$("#post-content").hide();
		}else{
			$("#source").hide();
			$("#PhotoGallery").hide();
			$("#post-content").show();
		}
		
	}
	


	$(document).ready(function(){
    
	var increment=2;
	
     $("#addGallery").click(function(){
    

	content= '<h4 class="border-bottom p-2">Slide '+increment+'</h4><div class="form-group row p-2 justify-content-center"><input type="text" placeholder="Enter Picture URL" class="form-control col-md-6 col-12" id="slide_file_'+increment+'_url" name="slide[]" required><input type="file" id="slide_file_'+increment+'" class="mx-2 form-control col-md-3 col-6"><button type="button" onclick="upload_image('+increment+')" class="btn btn-info btn-sm col-md-auto col-6">Upload</button></div><div class="form-group p-2"><textarea name="slide_caption[]" class="summernote form-control" placeholder="Enter About Slide"></textarea></div>';

        var block="<div id='Slide"+increment+"'class='border rounded bg-white p-2 my-2'>"+content+"</div>";
        $("#PhotoGalleryGroup").append(block);
        $('.summernote').summernote();
		increment++;
    });
	
     $("#removeGallery").click(function(){

        
		if(increment==2){
            alert("Can Not be less than 1");
            return false;
        }   
        increment--;
		
        $("#Slide" + increment).remove();
        
    });

    
});

	$(document).ready(function(){
    
	var count=1;
	
     $("#addHighlight").click(function(){


	content_high= '<div class="form-group row p-1 justify-content-center"><input type="text" placeholder="Enter Highlight '+count+'" class="form-control col-12" name="highlights[]"></div>';

        var highlights="<div id='Highlight"+count+"'>"+content_high+"</div>";
		
        $("#Highlights").append(highlights);
 
		count++;
    });
	
     $("#removeHighlight").click(function(){

        
		if(count==1){
            alert("Can Not be less than 0");
            return false;
        }   
        count--;
		
        $("#Highlight" + count).remove();
        
    });

    
});

function category_list(){
            $.ajax({
				type:'post',
				dataType:'html',
                url:"<?php echo site_url('admin/category/option');?>",
                success:function(response){
                    $("#category").append(response);
            
                }
            });
	}

	$(document).ready(category_list())

function lower_slug(slug){
    
    slug = slug.replace(/\s+/g, '-').toLowerCase(); 
    $("#slug").val(slug);
}

</script>
<main class="c-main">
          <div class="container-fluid">
            <div class="fade-in">
				<div class="row">
					<div class="col-lg-9 col-md-8 col-12">
					<h2 class="mb-2">Add New Post</h2>
					<form id="post_ajax" action="<?php echo site_url('admin/update/post/'.$aid); ?>" method="post" enctype="multipart/form-data">
						<div class="form-group">
							<input class="form-control input-title" type="text" name="title" onload="convertToSlug(this.value)" onpaste="convertToSlug(this.value)" onkeyup="convertToSlug(this.value)" placeholder="Add Title" required>
						</div>
						<div class="form-group">
							<input class="form-control" type="text" name="subtitle" placeholder="Add Subtitle">
						</div>
						<div class="form-group">
							<b>Permalink: </b><?php echo site_url('hi/post/');?><input class="form-control-sm" type="text" id="slug" onkeyup="lower_slug(this.value);" value="" name="slug">
						</div>
						<div class="form-group">
							<input class="form-control" type="text" name="place" placeholder="News Place" required>
						</div>
						<div id="source" class="form-group row p-2" style="display:none">
							<div class="card">
								<div class="card-header">
									Source
								</div>
								<div class="card-body row">
									<select class="form-control col-2" name="source_type" >
										<option value="youtube">Youtube</option>
										<option value="html">MP4 or WebM</option>
									</select>
									<input class="form-control col-4 mx-2" type="text" name="source" placeholder="Add Source Url">
									<input type="file" id="file-1" class="mx-2 form-control col-md-3 col-2" name="file_source">
									<button type="button" id="upload-source" class="btn btn-info btn-sm col-auto">Upload</button>
								</div>
							</div>
						</div>
						<div id="PhotoGallery" class="PhotoGallery p-2" style="display:none">
							<div id='PhotoGalleryGroup'>
								<div id='Slide1' class="border rounded bg-white p-2 my-2">
								<h4 class="border-bottom p-2">Slide 1</h4>
									<div class="form-group row p-2 justify-content-center">
										<input type="text" placeholder="Enter Picture URL" id="slide_file_1_url" class="form-control col-md-6 col-12" name="slide[]">
										<input type="file" id="slide_file_1" class="mx-2 form-control col-md-3 col-6">
										<button type="button" onclick="upload_image(1);" class="btn btn-info btn-sm col-md-auto col-6">Upload</button>
									</div>
									<div class="form-group p-2">
										<textarea name="slide_caption[]" class="summernote form-control" placeholder="Enter About Slide"></textarea>
									</div>
								</div>
							</div>
							<button class="mx-2 btn btn-success" id="addGallery" type="button">Add New Slide</button><button class="mx-2 btn btn-danger" id="removeGallery" type="button">Remove Last Slide</button>
						</div>
						<div id="post-content">
							<div class="card">
								<div class="card-header">
									Story Highlights
								</div>
								<div class="card-body">
									<div id="Highlights">
									</div>
									<button class="mx-2 btn btn-success" id="addHighlight" type="button">Add New Highlight</button><button class="mx-2 btn btn-danger" id="removeHighlight" type="button">Remove Last Highlight</button>
								</div>
							</div>
							<div class="form-group">
								<textarea class="summernote form-control" rows="70" name="content"></textarea>	
							</div>
							
							<div id="draft-info" class="center small p-1"></div>
						</div>	
						<div class="form-group">
							<input class="form-control" type="text" name="news_source" placeholder="News Source" value="Aurangabad Now" required>
						</div>
    					<ul class="nav nav-tabs" id="extraTab" role="tablist">
                          <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="seo-tab" data-toggle="tab" data-target="#seo" type="button" role="tab" aria-controls="seo" aria-selected="true">SEO</button>
                          </li>
                          <li class="nav-item" role="presentation">
                            <button class="nav-link" id="facebook-tab" data-toggle="tab" data-target="#facebook" type="button" role="tab" aria-controls="facebook" aria-selected="false">Facebook</button>
                          </li>
                          <li class="nav-item" role="presentation">
                            <button class="nav-link" id="twitter-tab" data-toggle="tab" data-target="#twitter" type="button" role="tab" aria-controls="twitter" aria-selected="false">Twitter</button>
                          </li>
                        </ul>
                        <div class="tab-content card" id="extraTabContent">
                          <div class="tab-pane fade show active card-body" id="seo" role="tabpanel" aria-labelledby="seo-tab">
                            <div class="form-group p-2">
    							<input class="form-control" type="text" id="site-title" name="site_title" placeholder="Enter Title" value="">
    						</div>
                            <div class="form-group p-2">
    						    <textarea name="meta_description" class="form-control" placeholder="Enter Meta Description"></textarea>
    						</div>
    						<div class="form-group p-2">
    						    <textarea name="meta_keywords" class="form-control" placeholder="Enter Meta Keywords"></textarea>
    						</div>
    						
                          </div>
                          <div class="tab-pane fade card-body" id="facebook" role="tabpanel" aria-labelledby="facebook-tab">...</div>
                          <div class="tab-pane fade card-body" id="twitter" role="tabpanel" aria-labelledby="twitter-tab">...</div>
                        </div>
						
						
						
						
						
						
					</div>
					
							
					<div class="col-lg-3 col-md-4 col-12">
						<div class="card">
							<div class="card-header">
								<b>Categories</b>
							</div>
							<div class="card-body">
								<div class="form-group">
									<select class="form-control" id="category" name="category[]" multiple>
										
									</select>	
								</div>
								
							</div>
						</div>
						<div class="card">
							<div class="card-header">
								<b>Publish</b>
							</div>
							<div class="card-body">
							
								<div class="row">
									<div class="col-6">
										<button type="button" id="save_draft" class="btn btn-sm btn-outline-success">Save Draft</button>
									</div>
									<div class="col-6">
										<a type="button" style="float:right" target="_blank" href="<?php echo site_url('admin/preview/'.$aid) ?>" class="btn btn-sm btn-outline-primary">Preview</a>
									</div>
								</div>
								<div class="form-group row m-0 p-1">
									<label class="col-form-label col-auto">Published On: </label>
									<div class="col-5 my-auto">
										<input type="text" class="form-control form-control-sm" value="<?php echo date('c'); ?>" name="publish_date">	
									</div>
								</div>
								<div class="form-group row m-0 p-1">
									<label class="col-form-label col-auto">Status: </label>
									<div class="col-6 my-auto">
										<select class="form-control form-control-sm" name="status">
											<option value="Published">Published</option>
											<option value="Draft" selected>Draft</option>
										</select>	
									</div>
								</div>
							</div>
							<div class="card-footer">
								<div class="row">
									<div class="col-6 my-auto">
										<span class="text-danger"><a onclick="return confirm('Do you really want to delete?');" href="<?php echo site_url('admin/remove/post/'.$aid); ?>">Delete Post</a></span>
									</div>
									<div class="col-6 my-auto">
										<button style="float:right" type="submit" class="btn btn-primary">Publish</button>
									</div>
								</div>
							</div>
						</div>
						<div class="card">
							<div class="card-header">
								<b>Post Attributes</b>
							</div>
							<div class="card-body">
								<div class="form-group">
									<select id="format" onchange="showSource();" class="form-control" name="post_format">
										<option value="Standard">Standard</option>
										<option value="Photo Gallery">Photo Gallery</option>
										<option value="Video">Video</option>
										<option value="Audio">Audio</option>
				
									</select>
								</div>
							</div>
						</div>
						<div class="card">
							<div class="card-header">
								<b>Tags</b>
							</div>
							<div class="card-body">
								<div class="form-group">
								    <input type="text" id="tag" name="tag" value="Aurangabad News">
								</div>
							</div>
						</div>
						<div class="card">
							<div class="card-header">
								<b>Featured Image</b>
							</div>
							<div class="card-body">
								<div class="form-group">
									<input type="file" name="file" class="form-control">
									<input type="hidden" name="author" value="<?php echo $logged_in['uid']; ?>" >
									
								</div>
							</div>
						</div>
					</div>
					</form>
				</div>
			</div>
          </div>
</main>

<script>
function current_time(){
    var m_names =["Jan", "Feb", "Mar", 
"Apr", "May", "Jun", "Jul", "Aug", "Sep", 
"Oct", "Nov", "Dec"];

var d = new Date();
var spl = d.toString().split(' ');
var mnth = parseInt(m_names.indexOf(spl[1])+1).toString();
mnth = (mnth.length == 1) ? '0'+mnth : mnth
				//  yyyy       mm      dd       hh:mm:ss 
var data = spl[3]+'-'+mnth+'-'+spl[2]+' '+spl[4]
return data;
}


function executeQuery() {
 var form=$("#post_ajax");
    $.ajax({
            type:"POST",
            url:form.attr("action"),
            data:form.serialize(),//only input
            success: function(response){
                $('#draft-info').html('DRAFT SAVED AT '+ current_time());
            }
        });
  setTimeout(executeQuery, 15000); 
}

$(document).ready(function() {
  setTimeout(executeQuery, 15000);
});

$("#save_draft").click(function(){
     executeQuery()
});
</script>
<script src="/plugins/amsify/jquery.amsify.suggestags.js"></script>
<script>
  $('#tag').amsifySuggestags({
  type : 'bootstrap',
  suggestions: <?php echo json_encode(array_column($tags,"name")); ?>,
  selectOnHover:false
});
</script>