                <div class="row">
                    <div class="col-12 mb-4">
                        <h3>Users</h3>
                    </div>
					<div class="col-md-4 col-12">
					            <h5>Add User</h5>
					            <form action="" method="post" id="add_user">
							    <div class="form-group">
							        <label for="name">Name</label>
									<input type="text" class="form-control" id="name" name="name" required>
									
								</div>
								<div class="form-group">
							        <label for="username">Username</label>
									<input type="text" class="form-control" id="username" placeholder="Enter Desired Username" name="username" required>
									
								</div>
								<div class="form-group">
							        <label for="email">Email ID</label>
									<input type="email" class="form-control" id="email" placeholder="Enter Email ID" name="email" required>
									
								</div>
								<div class="form-group">
							        <label for="password">Password</label>
									<input type="password" class="form-control" id="password" placeholder="Enter Password" name="password" required>
									
								</div>
								
								<div class="form-group">
							        <label for="role">Role</label>
									<select class="form-control" id="role" name="role" required>
									    <option value="Admin">Admin</option>
									    <option value="Author">Author</option>
									</select>
									
								</div>
								
								<div class="form-group">
							        <label for="status">Status</label>
									<select class="form-control" id="status" name="status" required>
									    <option value="Active">Active</option>
									    <option value="Suspended">Suspended</option>
									</select>
									
								</div>
								
								
								<div class="m-2">
									<button type="submit" id="submit" class="btn btn-sm btn-success">Add User</button>
								</div>
								</form>
							
					</div>
					<div class="col-md-8 col-12">
						<div class="card p-0" style="max-height:70vh; overflow-y:auto">
								<div class="card-body m-0">
    							<table id="user_list" class="table table-striped"><tr><th><input type="checkbox" name="select_all"></th><th>Name</th><th>Username</th><th>Email Id</th><th>Role</th><th>Status</th></tr>
    						    </table>
						    </div>
					</div>
				</div>
			</div>
          
<script>
	
	function user_list(){
            $.ajax({
				type:'post',
				dataType:'html',
                url:"<?php echo site_url('admin/user_list');?>",
                success:function(response){
                    $("#user_list").append(response);
                }
            });
	}

	$(document).ready(user_list());

	$(document).ready(function(){
    $("#submit").click(function(){
        
        var data = $("#add_user").serialize();

   
            $.ajax({
                url:"<?php echo site_url('admin/insert/user');?>",
                type:'post',
                data:data,
                success:function(response){
					alert(response)
    				user_list()
                }
            });
			
		});
	});


</script>