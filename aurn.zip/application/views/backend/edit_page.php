<?php $logged_in=$this->session->userdata('logged_in'); ?>
<script>
function convertToSlug( str ) {
	
  //replace all special characters | symbols with a space
  str = str.replace(/[`~!@#$%^&*()_\-+=\[\]{};:'"\\|\/,.<>?\s]/g, ' ').toLowerCase();
	
  // trim spaces at start and end of string
  str = str.replace(/^\s+|\s+$/gm,'');
	
  // replace space with dash/hyphen
  str = str.replace(/\s+/g, '-');	
  document.getElementById("slug").value= str;
  $("#slug").trigger( 'change' );
  //return str;
}

function slug_available(slug) {
        
     $.ajax({
        async: true,
        type: "POST",
        url: "<?php echo site_url('dashboard/check_slug');?>",
        data: {'slug' : slug,'type':'testseries_exam'},
        dataType: "text",
        success: function(msg){
             $("#check_slug").html(msg);
        }
    });
}

	$(document).ready(
		showSource()
	);


	
</script>

				<div class="row">
					<div class="col-lg-9 col-md-8 col-12">
					<h2 style="display: inline-block;" class="mb-2">Edit Post </h2> <a class="mb-2 btn btn-outline-success" role="button" href="<?php echo site_url('admin/add/page'); ?>">Add New</a>
					<form  action="<?php echo site_url('admin/update/page/'.$page['pid']); ?>" method="post" enctype="multipart/form-data">
						<div class="form-group">
							<input class="form-control input-title" type="text" name="title" value="<?php echo $page['title']; ?>"  placeholder="Add Title">
						</div>
						
						<div class="form-group">
							<b>Permalink: </b><?php echo site_url('hi/page/');?><input class="" type="text" id="slug" value="<?php echo $page['slug']; ?>" name="slug">
						</div>
						
							<div class="form-group">
								<textarea class="summernote form-control" rows="50" name="content">
								    <?php echo $page['content']; ?>
								</textarea>	
							</div>
						</div>
					
							
					<div class="col-lg-3 col-md-4 col-12">
						
						<div class="card">
							<div class="card-header">
								<b>Publish</b>
							</div>
							<div class="card-body">
							
								<div class="row">
									<div class="col-6">
										<button type="button" class="btn btn-sm btn-outline-success">Save Draft</button>
									</div>
									<div class="col-6">
										<a type="button" style="float:right" target="_blank" href="<?php echo site_url('hi/page/'.$page['slug']); ?>" class="btn btn-sm btn-outline-primary">Preview</a>
									</div>
								</div>
								<div class="form-group row p-1 mt-1">
									<label class="col-form-label col-auto">Status: </label>
									<div class="col-6 my-auto">
										<select class="form-control-sm" name="status">
											<option value="Published">Published</option>
											<option value="Draft">Draft</option>
										</select>	
									</div>
								</div>
							</div>
							<div class="card-footer">
								<div class="row">
									<div class="col-6 my-auto">
										<span class="text-danger"><a onclick="return confirm('Do you really want to delete?');" href="<?php echo site_url('admin/remove/page/'.$page['pid']); ?>">Delete Page</a></span>
									</div>
									<div class="col-6 my-auto">
										<button style="float:right" type="submit" class="btn btn-success">Update</button>
									</div>
								</div>
							</div>
						</div>

    					<div class="card">
							<div class="card-header">
								<b>Featured Image</b>
							</div>
							<div class="card-body">
								<div>
									<img src="/images/<?php echo $page['featured_image']; ?>" width="100%">
								</div>
								<div class="form-group">
									<input type="file" name="file" class="form-control">
									
								</div>
							</div>
						</div>

					</div>
					</form>
				</div>
