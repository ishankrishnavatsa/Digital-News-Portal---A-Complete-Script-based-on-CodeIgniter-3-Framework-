<?php $logged_in=$this->session->userdata('logged_in'); ?>
<link href="/plugins/amsify/amsify.suggestags.css" rel="stylesheet" />
<script>
function convertToSlug( str ) {
	
  //replace all special characters | symbols with a space
  str = str.replace(/[`~!@#$%^&*()_\-+=\[\]{};:'"\\|\/,.<>?\s]/g, ' ').toLowerCase();
	
  // trim spaces at start and end of string
  str = str.replace(/^\s+|\s+$/gm,'');
	
  // replace space with dash/hyphen
  str = str.replace(/\s+/g, '-');	
  document.getElementById("slug").value= str;
  $("#slug").trigger( 'change' );
  //return str;
}

function slug_available(slug) {
        
     $.ajax({
        async: true,
        type: "POST",
        url: "<?php echo site_url('dashboard/check_slug');?>",
        data: {'slug' : slug,'type':'testseries_exam'},
        dataType: "text",
        success: function(msg){
             $("#check_slug").html(msg);
        }
    });
}

	$(document).ready(
		showSource()
	);

function upload_image(data) {
	
	var file_data=$("#slide_file_"+data).prop("files")[0]; 
	var form_data = new FormData(); // Creating object of FormData class
	form_data.append("file", file_data) // Appending parameter named file with properties of file_field to form_data
       
     $.ajax({
        async: true,
        type: "POST",
        url: "<?php echo site_url('admin/upload_img/628/1200');?>",
        dataType: 'script',
		cache: false,
		contentType: false,
		processData: false,
		data: form_data, 
        success: function(msg){
             $("#slide_file_"+data+"_url").val(msg);
        }
    });
}

	
	function showSource(){
		
		var format=$("#format :selected").val();
		if(format=="Video" || format=="Audio"){
			$("#source").show();
			$("#PhotoGallery").hide();
			$("#post-content").show();
			
		}else if(format=="Photo Gallery"){
			$("#PhotoGallery").show();
			$("#post-content").hide();
		}else{
			$("#source").hide();
			$("#PhotoGallery").hide();
			$("#post-content").show();
		}
		
	}
	
	$(document).ready(function(){
		showSource()
	});
	
	
	$(document).ready(function(){
    
	var increment=<?php if($post['post_format']=="Photo Gallery"){ echo count(json_decode($post['source'],TRUE))+1; } else {echo "1";} ?>
	
     $("#addGallery").click(function(){


	content= '<h4 class="border-bottom p-2">Slide '+increment+'</h4><div class="form-group row p-2 justify-content-center"><input type="text" placeholder="Enter Picture URL" class="form-control col-md-6 col-12" id="slide_file_'+increment+'_url" name="slide[]" required><input type="file" id="slide_file_'+increment+'" class="mx-2 form-control col-md-3 col-6"><button type="button" onclick="upload_image('+increment+')" class="btn btn-info btn-sm col-md-auto col-6">Upload</button></div><div class="form-group p-2"><textarea name="slide_caption[]" class="summernote form-control" placeholder="Enter About Slide"></textarea></div>';

        var block="<div id='Slide"+increment+"'class='border rounded bg-white p-2 my-2'>"+content+"</div>";
		
        $("#PhotoGalleryGroup").append(block);
        $('.summernote').summernote();
		increment++;
    });
	
     $("#removeGallery").click(function(){

        
		if(increment==2){
            alert("Can Not be less than 1");
            return false;
        }   
        increment--;
		
        $("#Slide" + increment).remove();
        
    });

    
});
	
 	
	
	$(document).ready(function(){
    
	var count=<?php if($post['highlights']) {echo count(explode("|",$post['highlights']))+1; }else{echo "1";} ?>;
	
     $("#addHighlight").click(function(){


	content_high= '<div class="form-group row p-1 justify-content-center"><input type="text" placeholder="Enter Highlight '+count+'" class="form-control col-12" name="highlights[]"></div>';

        var highlights="<div id='Highlight"+count+"'>"+content_high+"</div>";
		
        $("#Highlights").append(highlights);
 
		count++;
    });
	
     $("#removeHighlight").click(function(){

        
		if(count==1){
            alert("Can Not be less than 0");
            return false;
        }   
        count--;
		
        $("#Highlight" + count).remove();
        
    });

    
});

function category_list(){
            $.ajax({
				type:'post',
				dataType:'html',
                url:"<?php echo site_url('admin/category/option/'.$post['cid']);?>",
                success:function(response){
                    $("#category").append(response);
            
                }
            });
	}

	$(document).ready(category_list())

    function lower_slug(slug){
    
    slug = slug.replace(/\s+/g, '-').toLowerCase(); 
    $("#slug").val(slug);
    }

	
</script>

				<div class="row">
					<div class="col-lg-9 col-md-8 col-12">
					<h2 style="display: inline-block;" class="mb-2">Edit Post </h2> <a class="mb-2 btn btn-outline-success" role="button" href="<?php echo site_url('admin/add/post'); ?>">Add New</a>
					<form id="post_ajax" action="<?php echo site_url('admin/update/post/'.$post['aid']); ?>" method="post" enctype="multipart/form-data">
						<div class="form-group">
							<input class="form-control input-title" type="text" name="title" value="<?php echo $post['title']; ?>"  placeholder="Add Title">
						</div>
						<div class="form-group">
							<input class="form-control" type="text" name="subtitle" value="<?php echo $post['subtitle']; ?>" placeholder="Add Subtitle">
						</div>
						<div class="form-group">
							<b>Permalink: </b><?php echo site_url('hi/post/');?><input class="" type="text" id="slug" value="<?php echo $post['slug']; ?>" onkeyup="lower_slug(this.value);" name="slug">
						</div>
						<div class="form-group">
							<input class="form-control" type="text" name="place" value="<?php echo $post['place']; ?>" placeholder="News Place">
						</div>
						<div id="source" style="display:none">
							<div class="card">
								<div class="card-header">
									Source
								</div>
								<div class="card-body form-group row">
									<select class="form-control col-md-2 col-6" name="type" >
										<option value="youtube" <?php if(isset(json_decode($post['source'],TRUE)['type'])=='youtube'){echo 'selected';}?>>Youtube</option>
										<option value="html" <?php if(isset(json_decode($post['source'],TRUE)['type'])=='html'){echo 'selected';}?>>MP4 or WebM</option>
									</select>
									<input class="form-control col-md-4 col-6 mx-2" value="<?php if(isset(json_decode($post['source'],TRUE)['url'])){echo json_decode($post['source'],TRUE)['url']; } ?>" type="text" name="source" placeholder="Add Source Url">
									<input type="file" id="file-1" class="mx-2 form-control col-md-3 col-6" name="file_source">
									<button type="button" id="upload-source" class="btn btn-info btn-sm col-md-2 col-6">Upload</button>
								</div>
							</div>
						</div>
						<div id="PhotoGallery" class="PhotoGallery p-2" style="display:none">
							<div id='PhotoGalleryGroup'>
							<?php if($post['post_format']=="Photo Gallery"){ foreach(json_decode($post['source'],TRUE) as $key=>$source){ ?>
								<div id='Slide<?php echo $key+1; ?>' class="border rounded bg-white p-2 my-2">
								<h4 class="border-bottom p-2">Slide <?php echo $key+1; ?></h4>
									<div class="form-group row p-2 justify-content-center">
										<input type="text" placeholder="Enter Picture URL" value="<?php echo $source['pic']; ?>" class="form-control col-md-6 col-12" id="slide_file_<?php echo $key+1; ?>_url" name="slide[]" required>
										<input type="file" id="slide_file_<?php echo $key+1; ?>" class="mx-2 form-control col-md-3 col-6">
										<button type="button" onclick="upload_image(<?php echo $key+1; ?>)" class="btn btn-info btn-sm col-md-auto col-6">Upload</button>
									</div>
									<div class="form-group p-2">
										<textarea name="slide_caption[]" class="summernote form-control" placeholder="Enter About Slide"><?php echo $source['caption']; ?></textarea>
									</div>
								</div>
							<?php }} ?>
							</div>
							<button class="mx-2 btn btn-success" id="addGallery" type="button">Add New Slide</button><button class="mx-2 btn btn-danger" id="removeGallery" type="button">Remove Last Slide</button>
						</div>
						<div id="post-content">
							<div class="card">
								<div class="card-header">
									Story Highlights
								</div>
								<div class="card-body">
									<div id="Highlights">
									<?php if($post['highlights']){ foreach(explode("|",$post['highlights']) as $key=>$highlight){ ?>
										<div id='Highlight<?php echo $key+1; ?>'>
											<div class="form-group row p-1 justify-content-center"><input type="text" placeholder="Enter Highlight <?php echo $key+1; ?>" value="<?php echo $highlight; ?>" class="form-control col-12" name="highlights[]"></div>
										</div>
									<?php }} ?>
									</div>
									<button class="mx-2 btn btn-success" id="addHighlight" type="button">Add New Highlight</button><button class="mx-2 btn btn-danger" id="removeHighlight" type="button">Remove Last Highlight</button>
								</div>
							</div>
							<div class="form-group">
								<textarea class="summernote form-control" rows="50" name="content">
								<?php echo $post['content']; ?>
								</textarea>	
							</div>
						</div>
						<div id="draft-info" class="center small p-1"></div>
						<div class="form-group">
							<input class="form-control" type="text" name="news_source" placeholder="News Source" value="<?php echo $post['news_source']; ?>" required>
						</div>
    					<ul class="nav nav-tabs" id="extraTab" role="tablist">
                          <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="seo-tab" data-toggle="tab" data-target="#seo" type="button" role="tab" aria-controls="seo" aria-selected="true">SEO</button>
                          </li>
                          <li class="nav-item" role="presentation">
                            <button class="nav-link" id="facebook-tab" data-toggle="tab" data-target="#facebook" type="button" role="tab" aria-controls="facebook" aria-selected="false">Facebook</button>
                          </li>
                          <li class="nav-item" role="presentation">
                            <button class="nav-link" id="twitter-tab" data-toggle="tab" data-target="#twitter" type="button" role="tab" aria-controls="twitter" aria-selected="false">Twitter</button>
                          </li>
                        </ul>
                        <div class="tab-content card" id="extraTabContent">
                          <div class="tab-pane fade show active card-body" id="seo" role="tabpanel" aria-labelledby="seo-tab">
                            <div class="form-group p-2">
    							<input class="form-control" type="text" id="site-title" name="site_title" placeholder="Enter Title" value="<?php echo $post['site_title']; ?>">
    						</div>
                            <div class="form-group p-2">
    						    <textarea name="meta_description" class="form-control" placeholder="Enter Meta Description"><?php echo $post['meta_description']; ?></textarea>
    						</div>
    						<div class="form-group p-2">
    						    <textarea name="meta_keywords" class="form-control" placeholder="Enter Meta Keywords"><?php echo $post['meta_keywords']; ?></textarea>
    						</div>
                          </div>
                          <div class="tab-pane fade card-body" id="facebook" role="tabpanel" aria-labelledby="facebook-tab">...</div>
                          <div class="tab-pane fade card-body" id="twitter" role="tabpanel" aria-labelledby="twitter-tab">...</div>
                        </div>
						
					</div>
							
					<div class="col-lg-3 col-md-4 col-12">
						<div class="card">
							<div class="card-header">
								<b>Categories</b>
							</div>
							<div class="card-body">
								<div class="form-group">
									<select class="form-control" id="category" name="category[]" multiple>
										
									</select>	
								</div>
							</div>
						</div>
						<div class="card">
							<div class="card-header">
								<b>Publish</b>
							</div>
							<div class="card-body">
							
								<div class="row">
									<div class="col-6">
										<button id="save_draft" type="button" class="btn btn-sm btn-outline-success">Save Draft</button>
									</div>
									<div class="col-6">
										<a type="button" style="float:right" target="_blank" href="<?php echo site_url('admin/preview/'.$post['aid']); ?>" class="btn btn-sm btn-outline-primary">Preview</a>
									</div>
								</div>
								
								<div class="form-group row m-0 p-1">
									<label class="col-form-label col-auto">Published On: </label>
									<div class="col-5 my-auto">
										<input type="text" class="form-control form-control-sm" value="<?php echo $post['publish_date']; ?>" name="publish_date">	
									</div>
								</div>
								<div class="form-group row m-0 p-1">
									<label class="col-form-label col-auto">Status: </label>
									<div class="col-6 my-auto">
										<select class="form-control form-control-sm" name="status">
											<option value="Published" <?php if($post['status']=="Published"){echo 'selected';}?>>Published</option>
											<option value="Draft" <?php if($post['status']=="Draft"){echo 'selected';}?>>Draft</option>
										</select>	
									</div>
								</div>
								<div class="form-group">
                                    <div class="custom-control custom-switch">
                                      <input type="checkbox" class="custom-control-input" value=1 name="push" id="pushSwitch">
                                      <label class="custom-control-label" for="pushSwitch">Send Push Notification</label>
                                    </div>
                                </div>
							</div>
							<div class="card-footer">
								<div class="row">
									<div class="col-6 my-auto">
										<span class="text-danger"><a onclick="return confirm('Do you really want to delete?');" href="<?php echo site_url('admin/remove/post/'.$post['aid']); ?>">Delete Post</a></span>
									</div>
									<div class="col-6 my-auto">
										<button style="float:right" type="submit" class="btn btn-success">Update</button>
									</div>
								</div>
							</div>
						</div>
						<div class="card">
							<div class="card-header">
								<b>Post Attributes</b>
							</div>
							<div class="card-body">
								<div class="form-group">
									<select id="format" onchange="showSource();" class="form-control" name="post_format">
										<option value="Standard" <?php if($post['post_format']=="Standard"){echo 'selected';} ?>>Standard</option>
										<option value="Photo Gallery" <?php if($post['post_format']=="Photo Gallery"){echo 'selected';} ?>>Photo Gallery</option>
										<option value="Video" <?php if($post['post_format']=="Video"){echo 'selected';} ?>>Video</option>
										<option value="Audio" <?php if($post['post_format']=="Audio"){echo 'selected';} ?>>Audio</option>
				
									</select>
								</div>
							</div>
						</div>
						<div class="card">
							<div class="card-header">
								<b>Tags</b>
							</div>
							<div class="card-body">
								<div class="form-group">
									 <input type="text" id="tag" name="tag" value="<?php echo $post['tags']; ?>">
								</div>
							</div>
						</div>
						<div class="card">
							<div class="card-header">
								<b>Featured Image</b>
							</div>
							<div class="card-body">
								<div>
									<img src="/images/<?php echo $post['featured_image']; ?>" width="100%">
								</div>
								<div class="form-group">
									<input type="file" name="file" class="form-control">
									<input type="hidden" name="author" value="<?php echo $logged_in['uid']; ?>" class="form-control">
								</div>
							</div>
						</div>

					</div>
					</form>
				</div>
				
<script>
function current_time(){
    var m_names =["Jan", "Feb", "Mar", 
"Apr", "May", "Jun", "Jul", "Aug", "Sep", 
"Oct", "Nov", "Dec"];

var d = new Date();
var spl = d.toString().split(' ');
var mnth = parseInt(m_names.indexOf(spl[1])+1).toString();
mnth = (mnth.length == 1) ? '0'+mnth : mnth
				//  yyyy       mm      dd       hh:mm:ss 
var data = spl[3]+'-'+mnth+'-'+spl[2]+' '+spl[4]
return data;
}


function executeQuery() {
 var form=$("#post_ajax");
    $.ajax({
            type:"POST",
            url:form.attr("action"),
            data:form.serialize(),//only input
            success: function(response){
                $('#draft-info').html('DRAFT SAVED AT '+ current_time());
            }
        });
  setTimeout(executeQuery, 35000); 
}

$(document).ready(function() {
  setTimeout(executeQuery, 35000);
});

$("#save_draft").click(function(){
    executeQuery();
});
</script>

<script src="/plugins/amsify/jquery.amsify.suggestags.js"></script>
<script>
  $('#tag').amsifySuggestags({
  type : 'bootstrap',
  suggestions: <?php echo json_encode(array_column($tags,"name")); ?>,
  selectOnHover:false
});
</script>