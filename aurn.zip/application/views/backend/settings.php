                <div class="row">
                    <div class="col-12 mb-4">
                        <h3>General Settings</h3>
                    </div>
					<div class="col-md-6 col-12" id="settings">
		
					           <form action="" id="add" method="post">
					           
					           
							   <?php foreach(array_keys(array_slice($ads,1)) as $ad){ ?>
								<div class="form-group row">
								    <label class="form-label col-6"><?php echo ucfirst(str_replace("_"," ",$ad)); ?></label>
								    <textarea class="form-control col-6" name="<?php echo $ad; ?>"><?php echo $ads[$ad]; ?></textarea>
								</div>
							    <?php } ?>
								<div class="m-2">
									<button type="submit" id="submit" class="btn btn-sm btn-success">Update Settings</button>
								</div>
								</form>
							
					</div>
					
			    </div>
          
<script>
	


	$(document).ready(function(){
    $("#submit").click(function(){
        
        var data = $("#add").serialize();
            
            $.ajax({
                url:"<?php echo site_url('admin/settings/update');?>",
                type:'post',
                data:data,
                success:function(response){
					alert(response)
					$("#ads").load(location.href+" #settings>*","");
    				
                }
            });
			
		});
	});

</script>