<div class="row">
    <div class="col-12 my-2" style="white-space:nowrap;">
        <h2 class="my-auto" style="display:inline-block">Media Library</h2> <button class="btn btn-sm btn-outline-success mx-2 my-auto" style="display:inline-block">Add New</button>
    </div>
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                Media
            </div>
            <div class="card-body bg-light" style="min-height:500px">
                <div class="row">
                <?php foreach($medias as $media){ 
                    $meta=json_decode($media['meta'],TRUE);
                ?>
                
                   <div class="col-auto"><img src="/images/<?php echo $meta['url']; ?>" width="100px" height="100px" onclick();></div>
                <?php } ?>
                </div>
            </div>
        </div>
    </div>
</div>