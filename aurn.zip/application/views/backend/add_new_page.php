<script>

function replace_array(a, b, text) {
if (a.length != b.length) {
return false;
}
for (var i = 0; i < a. length; i++) {
var pat = new RegExp(a[i], 'g');
text = text.replace(pat, b[i]);
}
return text;
}

function conv_hi_to_en(text, method) {
//var text_en = text.replace(/\n/,"<br/>");

var hic = ['क','ख','ग','घ','च','छ','ज','झ','ट','ठ','ड','ढ','ण','त','थ','द','ध','न','प','फ','ब','भ','म','य','र','ल','व','श','ष','स','ह','ळ','ञ', 'ढ़', 'ड़','ख़'];
if (method == 'basic') {
var enc = ['ka','kha', 'ga','gha','cha','chha','ja','za','ta','__i__th__/i__a','da','__i__dh__/i__a','__i__n__/i__a','__i__t__/i__a','tha','__i__d__/i__a','dha','na','pa','fa','ba','bha','ma','ya','ra','la','va','sha','sha','sa','ha','__i__l__/i__a','nya','dh','d','kh'];
} else {
var enc = ['ka','kha','ga','gha','cha','chha','ja','jha','ta','tha','aa','dha','na','ta','tha','da','dha','na','pa','pha','ba','bha','ma','ya','ra','la','va','sha','sha','sa','ha','la','nya','dha','da','kha'];
}
var hih = ['क्','ख्','ग्','घ्','च्','छ्','ज्','झ्','ट्','ठ्','ड्','ढ्','ण्','त्','थ्','द्','ध्','न्','प्','फ्','ब्','भ्','म्','य्','र्','ल्','व्','श्','ष्','स्','ह्','ळ्','ञ्','ङ','ऽ', 'ड़'];
if (method == 'basic') {
var enh = ['k','kh', 'g','gh','ch','chh','j','z','t','__i__th__/i__','d','__i__dh__/i__','__i__n__/i__','__i__t__/i__','th','__i__d__/i__','dh','n','p','f','b','bh','m','y','r','l','v','sh','sh','s','h','__i__l__/i__','ny','n','’','d'];
} else {
var enh = ['k','kh','g','gh','ch','chh','j','z','t','th','d','dh','n','t','th','d','dh','n','p','f','b','bh','m','y','r','l','v','sh','sh','s','h','l','ny','n','’','d'];
}
var hiv = ['ओ','औ','आ','इ','ई','उ','ऊ','ए','ऐ','ऎ','ऒ','ऋ','ॐ','अ'];
if (method == 'basic') {
var env = ['o','au','aa','i','ee','u','oo','e','ai','e','au','hru','aum','a'];
} else {
var env = ['o','au','a','i','i','u','u','e','ai','e','au','ru','aum','a'];
}
var hivs = ['ि','ी','ु','ू','े','ै','ो','ौ','ॆ','ॊ','ं','ृ','्','ः','ा','ॉ'];
if (method == 'basic') {
var envs = ['i','ee','u','oo','e','ai','o','au','e','au','n','ru','','ah','a','au'];
} else {
var envs = ['i','i','u','u','e','ai','o','au','e','au','n','ru','','ah','a','au'];
}

var hin = ['०','१','२','३','४','५','६','७','८','९'];
var enn = ['0','1','2','3','4','5','6','7','8','9'];

var s = [];
var r = [];

for (var i = 0; i < hic.length; i++) {
for (var j = 0; j < hivs.length; j++) {
var s = new RegExp(hic[i] + hivs[j] + 'ઃ ', 'g');
var r = enh[i] + envs[j] + 'h' + envs[j] + ' ';
text_en = text.replace(s, r);
var s = new RegExp(hic[i] + hivs[j] + 'ઃ', 'g');
var r = enh[i] + envs[j] + 'h';
text_en = text_en.replace(s, r);
}
}

for (var i = 0; i < hic.length; i++) {
for (var j = 0; j < hivs.length; j++) {
var s = new RegExp(hic[i] + hivs[j] + 'ં', 'g');
var r = enh[i] + envs[j] + 'n';
text_en = text_en.replace(s, r);
}
}

for (var i = 0; i < hiv.length; i++) {
var s = new RegExp(hiv[i] + 'ં', 'g');
var r = env[i] + 'n';
text_en = text_en.replace(s, r);
}

for (var i = 0; i < hic.length; i++) {
for (var j = 0 ; j < hivs.length; j++) {
var s = new RegExp(hic[i] + hivs[j], 'g');
var r = enh[i] + envs[j];
text_en = text_en.replace(s, r);
}
}

text_en = replace_array(hih, enh, text_en);
text_en = replace_array(hivs, envs, text_en);
text_en = replace_array(hiv, env, text_en);
text_en = replace_array(hic, enc, text_en);
text_en = replace_array(hin, enn, text_en);

if (method == 'baps') {
for (var i = 0; i < enc.length; i++) {
var pat = new RegExp(enc[i] + ' ', 'g');
var rep = enh[i] + ' ';
text_en = text_en.replace(pat, rep);
}
for (var i = 0; i < enh.length; i++) {
for (var j = 0; j < enc.length; j++) {
var pat = new RegExp(enh[i] + enh[j] + ' ', 'g');
var rep = enh[i] + enc[j] + ' ';
text_en = text_en.replace(pat, rep);
}
}
var encomb = ['kh','gh','ch','chh','th','dh','th','dh','bh','sh','sh','ny'];
for (var i = 0; i < env.length; i++) {
for (var j = 0; j < encomb.length; j++) {
var pat = new RegExp(env[i] + encomb[j] + 'a ', 'g');
var rep = env[i] + encomb[j] + ' ';
text_en = text_en.replace(pat, rep);
}
}
}


/*
//capitalize first word in sentence
var lc = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'ā', 'ḍ', 'ĕ', 'ī', 'ḷ', 'ṇ', 'ŏ', 'ṛ', 'ṣ', 'ṭ', 'ū'];
var uc = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'Ā', 'Ḍ', 'Ĕ', 'Ī', 'Ḷ', 'Ṇ', 'Ŏ', 'Ṛ', 'Ṣ', 'Ṭ', 'Ū'];
for (var i = 0; i < lc.length; i++) {
var p1 = new RegExp('(\\.|\\?|!)\\s' + lc[i], 'g');
var p2 = new RegExp(',\\s("|“)' + lc[i], 'g');
var p3 = new RegExp('(\\."|\\.”)\\s' + lc[i], 'g');
var p4 = new RegExp('(\\.|\\?|!)\\s("|“)' + lc[i], 'g');
var p5 = new RegExp('(\\?”+\\?"|!”|!")\\s' + lc[i], 'g');
var p6 = new RegExp('("|”)\\s("|“)' + lc[i], 'g');
var p7 = new RegExp('^' + lc[i], "g");
var p8 = new RegExp('\n' + lc[i], "g");
text_en = text_en.replace(p1, '$1 ' + uc[i]);
text_en = text_en.replace(p2, ', $1' + uc[i]);
text_en = text_en.replace(p3, '$1 ' + uc[i]);
text_en = text_en.replace(p4, '$1 $2' + uc[i]);
text_en = text_en.replace(p5, '$1 ' + uc[i]);
text_en = text_en.replace(p6, '$1 $2' + uc[i]);
text_en = text_en.replace(p7, uc[i]);
text_en = text_en.replace(p8, '\n' + uc[i]);
}

//Post-processing fixes gna and trailing y
text_en = text_en.replace(/yvar\s/g,"ya");
text_en = text_en.replace(/y\s/g, 'ya ');
text_en = text_en.replace(/jnyaa/g, 'gnaa');
text_en = text_en.replace(/jnya/g, 'gna');
text_en = text_en.replace(/jny\s/g, 'gna');
text_en = text_en.replace(/svaa/g, 'swaa');
text_en = text_en.replace(/svā/g, 'swā');
text_en = text_en.replace(/‍/g,'');
text_en = text_en.replace(/‌/g,'');


*/

return text_en;
}
 
 
 
 
 
 
function convertToSlug(text) {
	var str=conv_hi_to_en(text,'barp');
  //replace all special characters | symbols with a space
  str = str.replace(/[`~!@#$%^&*()_\-+=\[\]{};:'"\\|\/,.<>?\s]/g, ' ').toLowerCase();
	
  // trim spaces at start and end of string
  str = str.replace(/^\s+|\s+$/gm,'');
	
  // replace space with dash/hyphen
  str = str.replace(/\s+/g, '-');	
  document.getElementById("slug").value= str;
  $("#slug").trigger( 'change' );
  //return str;
}


function slug_available(slug) {
        
     $.ajax({
        async: true,
        type: "POST",
        url: "<?php echo site_url('dashboard/check_slug');?>",
        data: {'slug' : slug,'type':'testseries_exam'},
        dataType: "text",
        success: function(msg){
             $("#check_slug").html(msg);
        }
    });
}
</script>
				<div class="row">
					<div class="col-lg-9 col-md-8 col-12">
					<h2 class="mb-2">Add New Page</h2>
					<form  action="<?php echo site_url('admin/insert/page'); ?>" method="post" enctype="multipart/form-data">
						<div class="form-group">
							<input class="form-control input-title" type="text" name="title" onload="convertToSlug(this.value)" onkeyup="convertToSlug(this.value)" placeholder="Add Ttile">
						</div>
						<div class="form-group">
							<b>Permalink: </b><?php echo site_url('hi/page/');?><input class="" type="text" id="slug" value="" name="slug">
						</div>
						<div class="form-group">
						    <button type="button" class="btn btn-sm btn-outline-success my-1" data-toggle="modal" data-target="#media"><i class="fas fa-photo-video"></i> Add Media</button>
							<textarea class="summernote form-control" rows="50" name="content"></textarea>	
						</div>
											
					</div>
					<div class="col-lg-3 col-md-4 col-12">
						<div class="card">
							<div class="card-header">
								<b>Publish</b>
							</div>
							<div class="card-body">
							
								<div class="row">
									<div class="col-6">
										<button type="button" class="btn btn-sm btn-outline-success">Save Draft</button>
									</div>
									<div class="col-6">
										<button type="button" style="float:right" class="btn btn-sm btn-outline-primary">Preview</button>
									</div>
								</div>
								<div class="form-group row p-1 mt-1">
									<label class="col-form-label col-auto">Status: </label>
									<div class="col-6 my-auto">
										<select class="form-control-sm" name="status">
											<option value="Published">Published</option>
											<option value="Draft">Draft</option>
										</select>	
									</div>
								</div>
							</div>
							<div class="card-footer">
								<div class="d-flex justify-content-end">
									<button type="submit" class="btn btn-success">Publish</button>
								</div>
							</div>
						</div>
						<div class="card">
							<div class="card-header">
								<b>Featured Image</b>
							</div>
							<div class="card-body">
								<div class="form-group">
									<input type="file" name="file" class="form-control">
								</div>
							</div>
						</div>
						<div class="card">
							<div class="card-header">
								<b>Page Attributes</b>
							</div>
							<div class="card-body">
							</div>
						</div>
					</div>
					</form>
				</div>
