
				<div class="row">
                    <div class="col-12 mb-4">
                        <h3>All Pages</h3>
                    </div>
					<div class="col-12">
						<div class="card" style="max-height:500px; overflow-y:auto">
							<table class="table table-striped table-responsive card-body p-0 small w-100 d-block d-table" id="all_pages">
							    <tr><th><input type="checkbox" name="select_all"></th><th>Title</th></th><th>Slug</th><th>Count</th></tr>
						    </table>
					    </div>
				    </div>
			    </div>
          
<script>

	function page_list(){
            $.ajax({
				type:'post',
				dataType:'html',
                url:"<?php echo site_url('admin/page_list');?>",
                success:function(response){
                    $("#all_pages").append(response);
                }
            });
	}

	$(document).ready(page_list())
	
</script>