
				<div class="row">
					<div class="col-md-6 col-12">
						<div class="card">
							<div class="card-header">
								Add Breaking News
							</div>
							<div class="card-body">
								<div class="form-group">
									<input type="text" id="breaking" class="form-control" placeholder="ब्रेकिंग न्यूज़  यहाँ लिखिए" name="breaking">
								</div>
								<div class="text-center m-2">
									<button id="add_breaking" type="submit" class="btn btn-sm btn-success">Submit</button>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-6 col-12">
						<div class="card" style="max-height:500px; overflow-y:auto">
							<div class="card-header">
								Breaking News
							</div>
							<div class="card-body p-0 table-responsive" id="breaking_posts" onload="breaking_list()">
								
						</div>
					</div>
				</div>
			</div>
          
<script>

	function breaking_list(){
            $.ajax({
				type:'post',
				dataType:'html',
                url:"<?php echo site_url('hi/breaking/');?>",
                success:function(response){
                    $("#breaking_posts").html(response);
                }
            });
	}

	$(document).ready(breaking_list())
	
	
	$(document).ready(function(){
    $("#add_breaking").click(function(){
        var breaking = $("#breaking").val();

        if( breaking != ""){
            $.ajax({
                url:"<?php echo site_url('admin/insert/breaking');?>",
                type:'post',
                data:{breaking:breaking},
                success:function(response){
					alert(response)
					breaking_list()
                }
            });
			}
		});
	});


</script>