
				<div class="row">
                    <div class="col-12 mb-4">
                        <h3>All Posts</h3>
                    </div>
					<div class="col-12">
						<div class="card">
							<table class="table table-striped card-body p-0 table-responsive small" id="all_posts">
							    <tr><th><input type="checkbox" name="select_all"></th><th>Post Format</th><th>Title</th></th><th>Subtitle</th><th>Author</th><th>Categories</th><th>Tags</th><th>Slug</th><th>Count</th></tr>
						    </table>
					    </div>
				    </div>
			    </div>
          
<script>

	function post_list(){
            $.ajax({
				type:'post',
				dataType:'html',
                url:"<?php echo site_url('admin/post_list');?>",
                success:function(response){
                    $("#all_posts").append(response);
                }
            });
	}

	$(document).ready(post_list())
	
</script>