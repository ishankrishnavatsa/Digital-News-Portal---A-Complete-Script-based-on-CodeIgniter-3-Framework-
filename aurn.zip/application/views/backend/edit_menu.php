<link rel="stylesheet" href="/js/bootstrap-iconpicker/css/bootstrap-iconpicker.min.css">
    <div class="row">
		<div class="col-12">
			<h2>Menus</h2>
		</div>
				<div class="col-12">
					<div class="card">
						<div class="card-body form-group row my-0">
							<label for="menus" class="col-form-label col-auto">Select a menu to edit:</label>
							<div class="col-4">
								<select class="form-control" name="menu" id="menus">
									<option value="">-----Select-----</option>
								<?php foreach($menus as $menu_list){ ?>
									<option value="<?php echo $menu_list['mid']; ?>" <?php if($menu['mid']==$menu_list['mid']){echo 'selected';} ?>><?php echo $menu_list['name']; ?></option>
								<?php } ?>
								</select>
							</div>
							<div class="col-auto my-auto">
								<button onclick="gotoMenu()" class="btn btn-outline-info">Select</button>
							</div>
							<div class="col-5 my-auto">
								or <a href="<?php echo site_url('admin/add/menu'); ?>">create a new menu</a>. Don’t forget to save your changes!
							</div>
						</div>
					</div>
				</div>
                <div class="col-md-4">
					<h5><b>Menu Items</b></h5>
					<div class="card border-primary mb-3">
                        <div class="card-header bg-white"  data-toggle="collapse" data-target="#collapseLink" aria-expanded="true" aria-controls="collapseLink">Custom Link</div>
                        <div id="collapseLink" class="collapse show">
							<div class="card-body">
								<form id="frmEdit" class="form-horizontal">
									<div class="form-group">
										<label for="text">Text</label>
										<div class="input-group">
											<input type="text" class="form-control item-menu" name="text" id="text" placeholder="Text">
											<div class="input-group-append">
												<button type="button" id="myEditor_icon" class="btn btn-outline-secondary"></button>
											</div>
										</div>
										<input type="hidden" name="icon" class="item-menu">
									</div>
									<div class="form-group">
										<label for="href">URL</label>
										<input type="text" class="form-control item-menu" id="href" name="href" placeholder="URL">
									</div>
									<div class="form-group">
										<label for="target">Target</label>
										<select name="target" id="target" class="form-control item-menu">
											<option value="_self">Self</option>
											<option value="_blank">Blank</option>
											<option value="_top">Top</option>
										</select>
									</div>
									<div class="form-group">
										<label for="title">Tooltip</label>
										<input type="text" name="title" class="form-control item-menu" id="title" placeholder="Tooltip">
									</div>
								</form>
								<button type="button" id="btnUpdate" class="btn btn-primary" disabled><i class="fas fa-sync-alt"></i> Update</button>
								<button type="button" id="btnAdd" class="btn btn-success"><i class="fas fa-plus"></i> Add</button>
							</div>
						</div>
						<div class="card-header bg-white"  data-toggle="collapse" data-target="#collapseCategory" aria-expanded="true" aria-controls="collapseCategory">Categories</div>
						<div id="collapseCategory" class="collapse">
							<div class="card-body">
<!---
								<?php //foreach($categories as $category){ ?>
								<div class="card card-body">
									<?php //echo $category['name'];?>
									<form>
										<input type="hidden"><button class="btn">Add</button>
									</form>
								</div> 
								<?php //} ?>  --->
							</div>
						</div>
                    </div>

                </div>
                <div class="col-md-8">
				<h5><b>Menu Structure</b></h5>
				<form method="post" action="<?php echo site_url('admin/update/menu/'.$menu['mid']); ?>">
					<div class="card mb-3">
                        <div class="card-header">
							<div class="form-group row my-auto">
								<label class="col-auto col-form-label">Menu Name:</label>
								<div class="col-4">
									<input type="text" placeholder="Enter Menu Name" value="<?php echo $menu['name']; ?>" name="name" class="form-control" required>
								</div>
							</div>
                        </div>
                        <div class="card-body">
                            <ul id="myEditor" class="sortableLists list-group">
                            </ul>
							<input type="hidden" id="menu_items" name="item" value="">
                        </div>
						<div class="card-body border-top py-3">
							<h6>Menu Settings</h6>
							<div class="row">
								<div class="col-auto">
									Display location
								</div>
								<div class="col-auto">
									<div class="custom-control custom-checkbox">
									  <input class="custom-control-input" type="checkbox" value="top_menu" name="location[]" id="topbar" <?php if(in_array('top_menu',explode(",",$menu['location']))){echo 'checked';} ?>>
									  <label for="topbar" class="custom-control-label">Top Bar Navigation</label>
									</div>
									<div class="custom-control custom-checkbox">
									  <input class="custom-control-input" value="main_menu" type="checkbox" name="location[]" id="mainbar" <?php if(in_array('main_menu',explode(",",$menu['location']))){echo 'checked';} ?>>
									  <label for="mainbar" class="custom-control-label">Main Navigation</label>
									</div>
									<div class="custom-control custom-checkbox">
									  <input class="custom-control-input" value="mobile_menu" type="checkbox" name="location[]" id="mobilebar" <?php if(in_array('mobile_menu',explode(",",$menu['location']))){echo 'checked';} ?>>
									  <label for="mobilebar" class="custom-control-label">Mobile Navigation</label>
									</div>
									<div class="custom-control custom-checkbox">
									  <input class="custom-control-input" value="footer_menu" type="checkbox" name="location[]" id="footerbar" <?php if(in_array('footer_menu',explode(",",$menu['location']))){echo 'checked';} ?>>
									  <label for="footerbar" class="custom-control-label">Footer Navigation</label>
									</div>
								</div>
							</div>
						</div>
						<div class="card-footer">
							<div class="row my-auto">
								<div class="col-6">
									<span class="text-danger">Delete Menu</span>
								</div>
								<div class="col-6">
									<button style="float:right" id="submit" type="submit" class="btn btn-sm btn-success">Save Menu</button>
								</div>
							</div>
						</div>
                    </div>
					
					
					
					
					
					
					
					

                </div>
            </div>


<script src='/js/jquery-menu-editor.min.js'></script>
<script type="text/javascript" src="/js/bootstrap-iconpicker/js/iconset/fontawesome5-3-1.min.js"></script>
<script type="text/javascript" src="/js/bootstrap-iconpicker/js/bootstrap-iconpicker.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-Piv4xVNRyMGpqkS2by6br4gNJ7DXjqk09RmUpJ8jgGtD7zP9yug3goQfGII0yAns" crossorigin="anonymous"></script>

<script>
jQuery(document).ready(function () {
                
                // menu items
                var arrayjson = '<?php echo $menu['item']; ?>';
                // icon picker options
                var iconPickerOptions = {searchText: "Icon Name...", labelHeader: "{0}/{1}"};
                // sortable list options
                var sortableListOptions = {
                    placeholderCss: {'background-color': "#cccccc"}
                };
				
                var editor = new MenuEditor('myEditor', {listOptions: sortableListOptions, iconPicker: iconPickerOptions});
                editor.setForm($('#frmEdit'));
                editor.setUpdateButton($('#btnUpdate'));
				
                $(document).ready(function() {
                    editor.setData(arrayjson);
					var str = editor.getString();
					$("#menu_items").val(str);
                });
				
                $("#btnUpdate").click(function(){
                    editor.update();

                });

                $('#btnAdd').click(function(){
                    editor.add();
					
                });
				
				$('#submit').click(function(){
                    var str = editor.getString();
					$("#menu_items").val(str);

                });
				
                /* ====================================== */

                /** PAGE ELEMENTS **/
                $('[data-toggle="tooltip"]').tooltip();
                $.getJSON( "https://api.github.com/repos/davicotico/jQuery-Menu-Editor", function( data ) {
                    $('#btnStars').html(data.stargazers_count);
                    $('#btnForks').html(data.forks_count);
                });
            });


			function gotoMenu(){
				var menuid=document.getElementById("menus").value;
				var url="<?php echo site_url('admin/edit/menu/')?>"+menuid;
				window.location=url
			}
        </script>