                <div class="row">
                    <div class="col-12 mb-4">
                        <h3>Tags</h3>
                    </div>
					<div class="col-md-4 col-12">
					            <h5>Add Tag</h5>
					            <form action="" id="add_tag">
							    <div class="form-group">
							        <label for="category">Name</label>
									<input type="text" class="form-control" id="category" name="name" required>
									<small>The name is how it appears on your site.</small>
								</div>
								<div class="form-group">
							        <label for="slug">Slug</label>
									<input type="text" class="form-control" id="slug" placeholder="Enter Slug" name="slug" required>
									<small>The “slug” is the URL-friendly version of the name. It is usually all lowercase and contains only letters, numbers, and hyphens.</small>
								</div>
								<div class="form-group">
								    <label for="description">Description</label>
									<textarea class="form-control" id="description" name="description"></textarea>
									<small>The description is not prominent by default; however, some themes may show it.</small>
								</div>
								<div class="m-2">
									<button type="submit" id="submit" class="btn btn-sm btn-success">Add Tag</button>
								</div>
								</form>
							
					</div>
					<div class="col-md-8 col-12">
						<div class="card" style="max-height:70vh; overflow-y:auto">
								<div class="card-body m-0">
    							<table id="tag_list" class="table table-striped"><tr><th><input type="checkbox" name="select_all"></th><th>Name</th><th>Description</th><th>Slug</th><th>Count</th></tr>
    						    </table>
						    </div>
					</div>
				</div>
			</div>
          
<script>
	
	function tag_list(){
            $.ajax({
				type:'post',
				dataType:'html',
                url:"<?php echo site_url('admin/tag');?>",
                success:function(response){
                    $("#tag_list").append(response);
                }
            });
	}

	$(document).ready(tag_list());

	$(document).ready(function(){
    $("#submit").click(function(){
        
        var data = $("#add_tag").serialize();

   
            $.ajax({
                url:"<?php echo site_url('admin/insert/tag');?>",
                type:'post',
                data:data,
                success:function(response){
					alert(response)
    				tag_list()
                }
            });
			
		});
	});


</script>