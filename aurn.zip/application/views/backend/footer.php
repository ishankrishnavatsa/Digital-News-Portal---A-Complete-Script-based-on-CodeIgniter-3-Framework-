
	
<!---CONTENT END HERE -->
  </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
	

	<script type="text/javascript"
     src="https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.1/MathJax.js?config=TeX-AMS-MML_HTMLorMML">
  </script>

<div id="loading" style="display:none; position:fixed; top:40vh">
    LOADING PLEASE WAIT
</div>
  
<script>
    $( document ).ajaxStart(function() {
    $( "#loading" ).show();
});


$( document ).ajaxStop(function() {
    $( "#loading" ).hide();
});	
</script>

<footer class="main-footer">
    <strong>Copyright &copy; 2021 Developed by : IT Vision Web Technologies</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      <b>Version</b> 1.0
    </div>
  </footer>

</div>
    <!-- ./wrapper -->
   
   <!-- Toastr JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/admin-lte@3.1/dist/js/adminlte.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.18/summernote-bs4.min.js" integrity="sha512-+cXPhsJzyjNGFm5zE+KPEX4Vr/1AbqCUuzAS8Cy5AfLEWm9+UI9OySleqLiSQOQ5Oa2UrzaeAOijhvV/M4apyQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
	<script>
		$(document).ready(function() {
              
              $('.summernote').summernote({             
                   toolbar: [
                          ['style', ['style']],
                          ['font', ['bold', 'underline','italic','strikethrough', 'superscript', 'subscript', 'clear']],
                          ['fontname', ['fontname']],
                          ['color', ['color']],
                          ['para', ['ul', 'ol', 'paragraph']],
                          ['table', ['table']],
                          ['insert', ['link', 'picture', 'video']],
                          ['view', ['fullscreen', 'codeview', 'help']],
                        ],
                        styleTags: [
                                'p',
                                 {title: 'Blockquote', tag: 'blockquote', className: 'blockquote', value: 'blockquote'},
                                'pre', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6','span',{ style: '' }
                            	],
                    callbacks: {
                        onImageUpload : function(files, editor, welEditable) {
                                for(var i = files.length - 1; i >= 0; i--) {
                                     sendFile(files[i], this);
                                }
                            }
                
                    }
                  
                });
                
                
                function sendFile(file, el) {
                    var form_data = new FormData();
                    form_data.append('file', file);
                    $.ajax({
                        data: form_data,
                        type: "POST",
                        url: "<?php echo site_url('admin/upload_img');?>",
                        cache: false,
                        contentType: false,
                        processData: false,
                    success: function(url) {
                        
                        //$(el).summernote('editor.insertImage', url);
                        
                        /*
                        $(el).summernote('editor.insertImage', url, function ($image) {
                             $image.css('max-width', '100%');
                             
                             
                        });
                        */
                        var htmldata='<p class="gallery"><img src="'+url+'" width="100%"><span class="desc">Image: </span></p><p><br></p>'; 
                        $(el).summernote('pasteHTML', htmldata);
                        
                        
                        
                   }
                   
                    });
                    }
        });
	</script>	
		
		<?php 
		if($this->session->flashdata('toastr')){?>

		<script>
		toastr['<?php echo $this->session->flashdata("toastr")["type"];?>']('<?php echo $this->session->flashdata("toastr")["msg"];?>');
		</script>
		<?php	} ?>
		
		
		
		
		
		
		
		
		
<div class="modal fade" id="media" tabindex="-1" role="dialog" aria-labelledby="medialabel" aria-hidden="true">
  <div class="modal-dialog modal-xl" role="document">
    <div class="modal-content">
      <div class="modal-header" style="border-bottom:none">
        <h5 class="modal-title" id="medialabel">Add Media</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
       
      </div>
      <div class="modal-body">
         <ul class="nav nav-tabs" id="myTab" role="tablist">
              <li class="nav-item">
                <a class="nav-link" id="upload_files-tab" data-toggle="tab" href="#upload_files" role="tab" aria-controls="upload_files" aria-selected="true">Upload Files</a>
              </li>
              <li class="nav-item">
                <a class="nav-link active" id="library-tab" data-toggle="tab" href="#library" role="tab" aria-controls="library" aria-selected="false">Media Library</a>
              </li>
              
        </ul>
            <div class="tab-content" id="myTabContent">
              <div class="tab-pane fade" id="upload_files" role="tabpanel" aria-labelledby="upload_files-tab" style="min-height:60vh">
                  Upload Image
              </div>
              <div class="tab-pane fade show active" id="library" role="tabpanel" aria-labelledby="library-tab">
                  <div class="row">
                      <div class="col-md-9 col-12 p-3" style="min-height:60vh;overflow-y:auto;float:left">
                          
                          <?php foreach ($medias as $media){ 
                            $med_data=json_decode($media['meta'],TRUE);
                          ?>
                            <div class="d-block">
                                <input id="<?php echo 'media'.$media['id']; ?>" type="checkbox" class="css-checkbox" value="<?php echo site_url('images/'.$med_data['url']); ?>">
                                <label for="<?php echo 'media'.$media['id']; ?>" class="css-label"><img src="<?php echo site_url('images/'.$med_data['url']); ?>" height="124px" width="124px" id="media_<?php echo $media['id']; ?>"/>
                                </label>
                        </div>
                          <?php } ?> 
                      </div>
                      <div class="col-md-3 col-12 bg-light small" id="media-meta">
                          
                      </div>
                  </div>
              </div>
              
            </div>



      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" onclick="insert_image();">Insert</button>
      </div>
    </div>
  </div>
</div>	
<script>
function insert_image(){
    
    $('.css-checkbox').on('change', function(){ // on change of state
           if(this.checked) // if changed state is "CHECKED"
            {
                
                $.ajax({
                        data: data,
                        type: "POST",
                        url: "<?php echo site_url('admin/get_media');?>",
                        dataType:json,
                    success: function(url) {
                        
                        //$(el).summernote('editor.insertImage', url);
                        
                        $("#media").modal('hide');
                        $(el).summernote('editor.insertImage', url, function ($image) {
                             $image.css('max-width', '100%');
                             
                             
                        });
                        
                        
                        
                   }
                   
                    });
                
            }
    });
}
</script>		
		

		
		
		
		
		
		
		
		
		
		
		
</body>
</html>
