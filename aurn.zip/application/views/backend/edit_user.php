                <div class="row">
                    <div class="col-12 mb-4">
                        <h3>Users</h3>
                    </div>
					<div class="col-md-4 col-12">
					            <h5>Edit User</h5>
					            <form action="" method="post" id="edit_user">
							    <div class="form-group">
							        <label for="name">Name</label>
									<input type="text" value="<?php echo $user['name']; ?>" class="form-control" id="name" name="name" required>
									
								</div>
								<div class="form-group">
							        <label for="username">Username</label>
									<input type="text" value="<?php echo $user['username']; ?>" class="form-control" id="username" placeholder="Enter Desired Username" name="username" disabled>
									
								</div>
								<div class="form-group">
							        <label for="email">Email ID</label>
									<input type="email" value="<?php echo $user['email']; ?>" class="form-control" id="email" placeholder="Enter Email ID" name="email" required>
									
								</div>
								<div class="form-group">
							        <label for="password">Password</label>
									<input type="password" class="form-control" id="password" placeholder="Enter Password" name="password">
									
								</div>
								
								<div class="form-group">
							        <label for="role">Role</label>
									<select class="form-control" id="role" name="role" required>
									    <option value="Admin" <?php if($user['role']=="Admin"){echo "selected";} ?>>Admin</option>
									    <option value="Author"  <?php if($user['role']=="Author"){echo "selected";} ?>>Author</option>
									</select>
									
								</div>
								
								<div class="form-group">
							        <label for="status">Status</label>
									<select class="form-control" id="status" name="status" required>
									    <option value="Active"  <?php if($user['status']=="Active"){echo "selected";} ?>>Active</option>
									    <option value="Suspended"  <?php if($user['status']=="Suspended"){echo "selected";} ?>>Suspended</option>
									</select>
									
								</div>
								
								
								<div class="m-2">
									<button type="submit" id="submit" class="btn btn-sm btn-success">Edit User</button>
								</div>
								</form>
							
					</div>
					
			</div>
          
<script>
	

	$(document).ready(function(){
    $("#submit").click(function(){
        
        var data = $("#edit_user").serialize();
        event.preventDefault();
            if ($('#edit_user')[0].checkValidity() === false) {
                event.stopPropagation();
            } else {
                
                
                 $.ajax({
                url:"<?php echo site_url('admin/update/user/'.$user['uid']);?>",
                type:'post',
                data:data,
                success:function(response){
					alert(response)
                }
            });
			
                
                
            }
            $('#edit_use').addClass('was-validated');






   
           
		});
	});


</script>