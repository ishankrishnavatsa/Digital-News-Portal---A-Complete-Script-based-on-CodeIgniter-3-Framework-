                <div class="row">
                    <div class="col-12 mb-4">
                        <h3>Categories</h3>
                    </div>
					<div class="col-md-4 col-12">
					            <h5>Add Categories</h5>
					            <form action="" id="add_category">
							    <div class="form-group">
							        <label for="category">Name</label>
									<input type="text" class="form-control" id="category" placeholder="Enter Category Name" name="name" required>
									<small>The name is how it appears on your site.</small>
								</div>
								<div class="form-group">
							        <label for="slug">Slug</label>
									<input type="text" class="form-control" id="slug" placeholder="Enter Slug" name="slug" required>
									<small>The “slug” is the URL-friendly version of the name. It is usually all lowercase and contains only letters, numbers, and hyphens.</small>
								</div>
							    <div class="form-group">
							        <label for="parent">Parent Category</label>
									<select class="form-control" id="parent" name="parent" required>
									    <option value="">--Select Parent Category--</option>
									    <option value="0">No Parent</option>
									    
									</select>
									<small>Categories, unlike tags, can have a hierarchy. You might have a Jazz category, and under that have children categories for Bebop and Big Band. Totally optional.</small>
								</div>
								<div class="form-group">
								    <label for="description">Description</label>
									<textarea class="form-control" id="description" name="description"></textarea>
									<small>The description is not prominent by default; however, some themes may show it.</small>
								</div>
								<div class="m-2">
									<button type="submit" id="submit" class="btn btn-sm btn-success">Add Category</button>
								</div>
								</form>
							
					</div>
					<div class="col-md-8 col-12">
						<div class="card p-0" style="max-height:70vh; overflow-y:auto">
								<div class="card-body m-0">
    							<table id="category_list" class="table table-striped"><tr><th><input type="checkbox" name="select_all"></th><th>Name</th><th>Description</th><th>Slug</th><th>Count</th></tr>
    						    </table>
						    </div>
					</div>
				</div>
			</div>
          
<script>

	function category_select(){
            $.ajax({
				type:'post',
				dataType:'html',
                url:"<?php echo site_url('admin/category/option');?>",
                success:function(response){
                    $("#parent").append(response);
                }
            });
	}
	
	function category_list(){
            $.ajax({
				type:'post',
				dataType:'html',
                url:"<?php echo site_url('admin/category/table');?>",
                success:function(response){
                    $("#category_list").append(response);
                }
            });
	}

	$(document).ready(category_list());
	$(document).ready(category_select());
	
	
	$(document).ready(function(){
    $("#submit").click(function(){
        
        var data = $("#add_category").serialize();

   
            $.ajax({
                url:"<?php echo site_url('admin/insert/category');?>",
                type:'post',
                data:data,
                success:function(response){
					alert(response)
					category_select()
    				category_list()
                }
            });
			
		});
	});


</script>