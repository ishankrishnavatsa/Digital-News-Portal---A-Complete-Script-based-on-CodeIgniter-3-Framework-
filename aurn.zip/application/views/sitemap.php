<?php echo'<?xml version="1.0" encoding="UTF-8" ?>' ?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
    <url>
        <loc><?php echo base_url();?></loc>
        <changefreq>daily</changefreq>
    </url>
    
    <url>
        <loc><?php echo site_url('breakingnews');?></loc>
        <changefreq>daily</changefreq>
    </url>

    <?php foreach($pages as $url) { ?>
    <url>
        <loc><?php echo $url; ?></loc>
        <changefreq>daily</changefreq>
    </url>
    <?php } ?>
    
    <?php foreach($categories as $category) { ?>
    <url>
        <loc><?php echo $category; ?></loc>
        <changefreq>daily</changefreq>
    </url>
    <?php } ?>
    
        <?php foreach($posts as $key=>$post) { ?>
    <url>
        <loc><?php echo $post; ?></loc>
        <lastmod><?php echo $lastmod[$key]; ?></lastmod>
        <changefreq>daily</changefreq>
    </url>
    <?php } ?>
    
    <?php foreach($tags as $tag) { ?>
    <url>
        <loc><?php echo $tag; ?></loc>
    </url>
    <?php } ?>
    
    


</urlset>