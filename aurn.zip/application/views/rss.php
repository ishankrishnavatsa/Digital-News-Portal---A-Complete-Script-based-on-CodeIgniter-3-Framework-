<?php echo '<?xml version="1.0" encoding="'.$encoding.'"?>';?>
<rss version="2.0" 
        xmlns:atom="http://www.w3.org/2005/Atom"
        xmlns:content="http://purl.org/rss/1.0/modules/content/"
    	xmlns:dc="http://purl.org/dc/elements/1.1/"
    	xmlns:sy="http://purl.org/rss/1.0/modules/syndication/"
    >
    <channel>
        <title><?php echo $feed_name; ?></title>
        <atom:link href="<?php echo $feed_url; ?>" rel="self" type="application/rss+xml" />
        <link><?php echo base_url(); ?></link>
        <description><?php echo $page_description; ?></description>
        <lastBuildDate><?php echo date("r", strtotime($posts[0]['publish_date'])); ?></lastBuildDate>
        <language><?php echo $page_language; ?></language>
        <sy:updatePeriod>hourly</sy:updatePeriod>
	<sy:updateFrequency>1</sy:updateFrequency>
        <generator>http://www.codeigniter.com </generator>


    <image>
    	<url><?php echo $feed_logo; ?></url>
    	<title><?php echo $feed_name; ?></title>
    	<link><?php echo base_url(); ?></link>
    	<width>32</width>
    	<height>32</height>
    </image> 
        

 
    <?php foreach($posts as $post) { 
    
    ?>
     
        <item>
 
          <title><?php echo $post['title'] ?></title>
          <link><?php echo site_url('hi/post/' . rawurlencode($post['slug'])); ?></link>
          <guid><?php echo site_url('hi/post/' . rawurlencode($post['slug'])); ?></guid>
            <dc:creator><![CDATA[Aurangabad Now]]></dc:creator>
            <pubDate><?php echo date("r", strtotime($post['publish_date'])); ?></pubDate>
            <description><![CDATA[ <p><img src="<?php echo site_url('images/' . $post['featured_image']); ?>" /></p><?php echo mb_substr(strip_tags($post['content']),0, 200); ?> ]]></description>
            <content:encoded><![CDATA[ <p><img src="<?php echo site_url('images/' . $post['featured_image']); ?>" /></p> <?php echo $post['content']; ?>]]></content:encoded>
        </item>

    <?php } ?>
     
    </channel>
</rss>