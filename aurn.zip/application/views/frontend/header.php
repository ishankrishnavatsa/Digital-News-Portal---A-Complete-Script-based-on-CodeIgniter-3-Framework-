<?php $logged_in=$this->session->userdata('logged_in'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title><?php echo $title; ?></title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
    <!-- MDB -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/3.3.0/mdb.min.css" rel="stylesheet"/>
    <link rel="stylesheet" href="<?php echo site_url('css/custom.css'); ?>">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <meta name="keywords" content="<?php if(isset($meta_keywords)){echo $meta_keywords;} ?>">
    <meta name="description" content="<?php if(isset($meta_description)){echo $meta_description;} ?>">
    <meta name="robots" content="index follow noodp,noydir" />
    <link rel="icon" type="image/png" href="/images/<?php echo $settings['favicon']; ?>"/>
    <meta property="fb:pages" content="106751240966897" />
    <meta property="og:locale" content="hi_IN" />
    <meta property="og:type" content="article" />
    <meta property="og:title" content="<?php echo $title; ?>" />
    <meta property="og:url" content="<?php echo current_url(); ?>" />
    <meta property="fb:app_id" content="305336434601395" />
    <meta property="og:headline" content="<?php echo $title; ?>" />
    <meta property="og:description" content="<?php if(isset($meta_description)){echo $meta_description;} ?>" />
    <meta property="og:image" content="<?php if(isset($single_post['featured_image'])){echo site_url('images/'.$single_post['featured_image']); }else {echo site_url('images/default.webp');}?>" />
    <meta property="og:image:width" content="1200" />
    <meta property="og:image:height" content="630" />
    
    <meta name="twitter:description" content="<?php if(isset($meta_description)){echo $meta_description;} ?>">
    
    <meta name="twitter:title" content="<?php echo $title; ?>">
    <meta name="twitter:card" content="summary_large_image" />
    <script data-ad-client="ca-pub-7732297418473075" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
            <script>
          (adsbygoogle = window.adsbygoogle || []).push({
            google_ad_client: "ca-pub-7732297418473075",
            enable_page_level_ads: true,
            overlays: {bottom: true}
          });
        </script>
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-CJWEKG96QC"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());
    
      gtag('config', 'G-770F68YC5H');
    </script>
    <style>
	.main-footer a{
		color:#86a1ae;
	}
</style>

</head>
<body>

<div class="container-fluid m-0 p-0">
<!--- Top Menu --->
	<div class="container-fluid top-menu border-bottom text-dark">
	  <div class="container">

	     <div class="row">
	         <div class="col-11" style="white-space:nowrap;overflow-x:auto">
	             <?php 
				 if(isset($top_menus)){
				 foreach ($top_menus as $topmenu){ ?>
			        <div style="display:inline-block;">
			       	<a class="nav-link py-0 small text-info" target="<?php echo $topmenu['target']; ?>" href="<?php echo $topmenu['href']; ?>" rel="noreferrer noopener"><span><b><small><?php echo $topmenu['text']; ?></small></b></span></a>
			</div>
		<?php } } ?>
	         </div>
	         <div class="col-1">
	             <?php if($logged_in && ($logged_in['role']=="Admin" || $logged_in['role']=="Author")){ ?>
		                <div style="display:inline-block; float:right">
		                <a href="<?php echo site_url('admin'); ?>" alt="Admin Dashboard"><i class="far fa-user"></i></a>
		                 </div>
		          <?php } ?>
	         </div>
	     </div> 
	  </div>
	</div>
<!--- Main Menu --->
<nav id="mainmenu" class="navbar navbar-expand-sm py-0 navbar-dark mb-5" style="background:red; color:#fff; font-weight:600;">
<div class="container" style="position:relative; justify-content:normal">
		<div id="logo_retina" class="logo d-none d-md-inline-block">
			<a href="/">
				<video autoplay loop muted playsinline width="200px" alt="Logo">  
				  <source src="/images/logo.webm" type="video/webm">  
				</video>
			</a>
		</div>
		<div id="logo_mini" class="d-none" style="position:absolute;left:20px;"><a href="/"><img src="/images/logo_phone.webp" alt="Logo"></a></div>
		<span class="d-block d-md-none p-1 my-auto" onclick="openNav()"><i class="my-auto fas fa-2x fa-bars"></i></span>
		<span class="mx-2 p-1 d-block d-md-none my-auto"><a href="/"><img src="/images/logo_phone.webp" alt="Logo"></a></span>
    <ul class="d-none d-md-inline-block navbar-nav collapse navbar-collapse" style="margin-left:190px;">
	<?php 
	if(isset($main_menus)){
	foreach ($main_menus as $menu){ ?>
      <li class="nav-item">
        <a class="nav-link" target="<?php echo $menu['target']; ?>" href="<?php echo $menu['href']; ?>"><span><?php echo $menu['text']; ?></span></a>
      </li>
	<?php } } ?>

</div>
</nav>
</div>
	<div id="mySidenav" class="sidenav">
		<a class="logo_menu" href="/"><img src="/images/logo_phone.webp" alt="Sidebar Logo"></a>
		<a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
		<div class="mt-3 mx-3" style="overflow-y:auto;background:red">
			<?php foreach ($mobile_menus as $menu){ ?>
			    <div class="p-2 border-bottom border-white">
    				<a target="<?php echo $menu['target']; ?>" href="<?php echo $menu['href']; ?>"><?php echo $menu['text']; ?></a>
				</div>
			<?php } ?>
		</div>
  </div>
</div>
