<div class="container mt-3">
	<div class="row my-3">
		<div class="col-12 py-2 my-2">
			<span><a href="/">होम</a></span><span class="px-3">/</span><span onclick="location.href='<?php echo site_url('hi/breakingnews'); ?>';" class="px-1 badge bg-danger"><?php echo 'ब्रेकिंग न्यूज़'; ?></span>		</div>
		<div class="col-md-9 col-12">
			<div class="border-bottom">
				<h1 style="font-size:1.2em; font-weight:bold">News Flash <?php echo date('d M Y'); ?> <i onclick="breaking_list()" class="px-2 fas fa-sync-alt"></i></h1>
			</div>
			
			
				<div class="row p-2" id="live-updates">
					
				</div>
		
			
		</div>
		<div class="col-md-3 col-12">

			<div class="mb-4">
			<div class="widget-title">
				<span><svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 55 55" style="enable-background:new #000080;" xml:space="preserve"><g><g><path style="fill:#D91F26;" d="M9.867,4h35.258c3.242,0,5.876,2.628,5.876,5.876v35.258c-0.011,2.373-1.452,4.508-3.644,5.406c-2.186,0.921-4.711,0.433-6.404-1.234L5.695,14.048c-1.67-1.687-2.158-4.218-1.234-6.404C5.359,5.446,7.494,4.012,9.867,4"></path></g></g></svg></span>
				<span><h2>लेटेस्ट </h2></span>
			</div>
			<?php for($i=1; $i<6;$i++){ if(isset($latest[$i])){?>
			<div class="py-2 border-bottom widget-2">
				<div class="row no-gutters" onclick="location.href='<?php echo site_url('hi/post/'.$latest[$i]['slug']); ?>';" style="cursor: pointer;">
					<div class="col-4 my-auto">
						<img src="/images/<?php echo $latest[$i]['featured_image']; ?>" width="100%" height="55px">
					</div>
					<div class="col-8 my-auto">
						<h3><?php echo $latest[$i]['title']; ?></h3>
					</div>
				</div>
			</div>
			<?php }} ?>
			</div>
		</div>
		
	</div>
</div>

<script>
	function breaking_list(){
            $.ajax({
				type:'post',
				dataType:'html',
                url:"<?php echo site_url('hi/live_updates/page');?>",
                success:function(result){
                    $("#live-updates").html(result);
                }
            });
	}

	$(document).ready(breaking_list())
	
</script>