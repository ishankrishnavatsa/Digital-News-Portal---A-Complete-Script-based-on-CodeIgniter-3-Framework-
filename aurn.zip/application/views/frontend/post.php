<script type='text/javascript' src='https://platform-api.sharethis.com/js/sharethis.js#property=60cc7017b8a3b100193bbc65&product=inline-share-buttons' async='async'></script>
<?php $logged_in=$this->session->userdata('logged_in'); ?>
<link rel="stylesheet" href="https://cdn.plyr.io/3.5.6/plyr.css" />

<div class="container mt-3">

	<div class="row my-3">
		<div class="col-12 py-2 my-2">
			<span><a href="/">होम</a></span>
			<?php if($breadcrumbs['parent']['cid']!=0){ ?><span class="px-3">/</span><span onclick="location.href='<?php echo site_url('hi/category/'.$breadcrumbs['parent']['slug']); ?>';" class="px-1"><?php echo $breadcrumbs['parent']['name']; ?></span> <?php } ?>
			<span class="px-3">/</span>
			<span onclick="location.href='<?php echo site_url('hi/category/'.$breadcrumbs['category']['slug']); ?>';" class="px-1 badge bg-danger"><?php echo $breadcrumbs['category']['name']; ?></span>
			<?php if($logged_in && ($logged_in['role']=="Admin" || $logged_in['role']=="Author")){ ?>
				<span class="my-auto" style="float:right"><a href="<?php echo site_url('admin/edit/post/'.$single_post['aid']); ?>" class="btn btn-outline-info rounded-pill"><i class="fas fa-pen"></i> Edit Post</a></span>
			<?php } ?>
		</div>
		<div id="printableArea" class="col-md-9 col-12">
			<div id="print_logo" style="display:none">
				<img src="/images/logo_phone.webp"><br>
				<h2 class="p-2 border-bottom border-top my-2">खबरों को सबसे पहले पढ़ने के लिए विजिट करिए <?php echo site_url(); ?></h2>
				
				
			</div>
			<div class="title">
				<h1><?php echo $single_post['title']; ?></h1>
			</div>
			<div class="subtitle">
				<h2 style="font-size:1.5em;font-weight:bold"><?php echo $single_post['subtitle']; ?></h2>
			</div>
			
			<div class="row m-3">
		        <div class="col-12 text-center p-2" id="top-ad">
			        <?php echo $ad['top_ad']; ?>
			    </div>
	        </div>
			<?php if($single_post['post_format']=="Standard"){ ?>
			<div class="featured_image mb-3">
				<img src="/images/<?php echo $single_post['featured_image']; ?>" width="100%" height="auto" alt="<?php echo $single_post['title']; ?>">
			</div>
			<?php }elseif($single_post['post_format']=="Video" && json_decode($single_post['source'],TRUE)){ ?>
			<div class="video-post mb-3 text-center" id="videosource">
				<?php if(json_decode($single_post['source'],TRUE)['type']=="youtube"){ ?>
					<div class="js-player" data-plyr-provider="youtube" data-plyr-embed-id="<?php echo json_decode($single_post['source'],TRUE)['url']; ?>"></div>
				<?php }elseif(json_decode($single_post['source'],TRUE)['type']=="html"){ ?>
					<video poster="<?php echo $single_post['featured_image']; ?>" class="js-player"><source src="<?php echo json_decode($single_post['source'],TRUE)['url']; ?>"/></video>
				<?php } ?>
			</div>
			<?php }elseif($single_post['post_format']=="Audio" && json_decode($single_post['source'],TRUE)){ ?>
			<div class="featured_image mb-3">
				<img src="/images/<?php echo $single_post['featured_image']; ?>" width="100%" height="auto" alt="<?php echo $single_post['title']; ?>">
			</div>
			<div class="video-post mb-3 text-center">
				<audio class="js-player">
					<source src="<?php echo json_decode($single_post['source'],TRUE)['url']; ?>"/>
				</audio>
			</div>
			<?php } ?>
			<div class="row p-2 bg-light border-bottom" id="authordiv">
				<div class="col-md-6 col-12">
					<div class="row">
						<div class="col-2">
							<img class="rounded-circle" src="/images/<?php echo $author['image']; ?>" alt="<?php echo $author['name']; ?>" width="50px" >
						</div>
						<div class="col-10">
							<p class="m-0">
								<b><?php echo $author['name']; ?></b>
							</p>
							<p class="m-0 small"> 
								<?php 
								if ($single_post['place']){ echo $single_post['place'].', ';}
								echo date('M d, Y', strtotime($single_post['publish_date']));
								
								if($single_post['modified_date']){
								    
								    echo ' (अपडेटेड '.date('M d, Y g:i A', strtotime($single_post['modified_date'])).' बजे)';
								
								} ?>
							</p>
							
						</div>
					</div>
				</div>
				<div class="col-md-6 col-12 my-auto">
					<span class="mx-2 " style="float:right">
					<span class="px-2"><a onclick="printDiv('printableArea')" href="#" title="Print this post"><i class="fas fa-2x fa-print"></i></a></span>
						<span class="px-2"><a target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=<?php echo site_url('hi/post/'.$single_post['slug']);?>" title="Share this post to Facebook"><i class="fab fa-2x fa-facebook"></i></a></span>
						<span class="px-2"><a target="_blank" href="https://www.twitter.com/intent/tweet?text=<?php echo urlencode(site_url('hi/post/'.$single_post['slug']));?>" title="Share this post to Twitter"><i class="fab fa-2x fa-twitter"></i></a></span>
						<span class="px-2"><a target="_blank" href="whatsapp://send?text=*<?php echo $single_post['title']; ?>*%0a %0a<?php echo mb_substr(strip_tags($single_post['content']),0,500); ?>... %0a_पूरी खबर पढ़ने के लिए नीचे लिंक पर क्लिक करें_ %0a<?php echo site_url('hi/post/'.$single_post['slug']); ?>" title="Share this post to WhatsApp"><i class="fab fa-2x fa-whatsapp"></i></a></span>
					
					</span>
				</div>
			</div>
			<?php if($single_post['post_format']=="Photo Gallery"){ 
			$total_slides=count(json_decode($single_post['source'],TRUE));
			foreach(json_decode($single_post['source'],TRUE) as $key=>$gallery){?>
				<div class="my-3 border-bottom justify-content-center">
				<div class="relative">
					<img src="<?php echo $gallery['pic']; ?>" width="100%" height="auto">
					<div class="gallery-tag px-3 py-1 text-light"><span><?php echo '<span style="font-size:1.2em">'.($key+1).'</span> / '.$total_slides;?> | </span><i class="fas fa-share-alt" data-container="body" data-bs-toggle="popover" data-placement="left" data-content="Vivamus sagittis lacus vel augue laoreet rutrum faucibus."></i></div>
				</div>
				<p class="my-0 p-3" style="font-size:1.2em;line-height:1.5em"><?php echo $gallery['caption']; ?></p>
				</div>
			<?php }} ?>
			<div id="post-content" class="relative mt-3 p-0">
			<?php if($single_post['highlights']) { ?>
				<div class="highlight px-2 py-0 mb-3 border-bottom border-4">
					<div class="my-auto px-2 py-1 text-white w-100 text-center opacity-2" style="background:red"><b>स्टोरी हाइलाइट्स</b></div>
					<?php foreach(explode("|",$single_post['highlights']) as $highlight) { ?>
						<h3 class="p-3 border-bottom"><?php echo $highlight; ?></h3>
					<?php } ?>
				</div>
			<?php } ?>
				<div id="pcontent" class="pcontent" style="font-size:1.2em;line-height:1.5em">
					<?php echo $single_post['content']; ?>
					<p class="small"><i>Source: <?php echo $single_post['news_source']; ?></i></p>
				</div>
			</div>
			<div class="p-2 mb-3 text-center border border-2 border" style="font-weight:900; color:red;font-size:1.3em">
                <?php echo $settings['below_article']; ?>
			</div> 
			<div id="tags">
			    <h4>Popular Search:</h4>
			    <div class="m-2 p-2" style="white-space:nowrap; overflow-x:auto">
    			    <?php foreach(explode(",",$single_post['tags']) as $tag){ ?>
    			        <span class="p-2 m-2 border border-2 border-primary rounded-pill text-primary"><a href="<?php echo site_url('hi/tag/'.$this->home_model->tag_slug($tag)['slug']); ?>"><?php echo $tag; ?></a></span>
    			    <?php } ?>
    			</div>
			</div>
			<?php if($ad['below_article_ad']){ ?>
			<div class="p-2 text-center" id="below-article-ad">
				<?php echo $ad['below_article_ad']; ?>
			</div>
			<div id="inArticle">
                <p class="text-center my-3">
                    <?php echo $ad['in_article_ad']; ?>
                    <script>(adsbygoogle = window.adsbygoogle || []).push({});</script>
                </p>
            </div>
			<?php } ?>
			<div class="mt-3" id="comments">
				<div id="disqus_thread">
				    <div id="disqus_thread_loader">Loading Comments</div>
				</div>
				<script>
				
					var disqus_config = function () {
					this.page.url = "<?php echo site_url('hi/post/'.$single_post['slug']); ?>";  // Replace PAGE_URL with your page's canonical URL variable
					this.page.identifier = "<?php echo 'post-'.$single_post['aid']; ?>";
					};
					var disqus_observer = new IntersectionObserver(function(entries) {
                    // comments section reached
                    // start loading Disqus now
                    if(entries[0].isIntersecting) {
    
					(function() { // DON'T EDIT BELOW THIS LINE
					var d = document, s = d.createElement('script');
					s.src = 'https://aurangabad-now.disqus.com/embed.js';
					s.setAttribute('data-timestamp', +new Date());
					(d.head || d.body).appendChild(s);
					})();
					
					// once executed, stop observing
                    disqus_observer.disconnect();
                    }
                    }, { threshold: [0] });
                    disqus_observer.observe(document.querySelector("#disqus_thread"));
				
				</script>
			</div>
			
		</div>
		<div class="col-md-3 col-12">
		    <div class="py-2 mb-4 text-center" id="sidebar-ad">
				<?php echo $ad['sidebar_ad']; ?>
			</div>
			<div class="mb-4">
			<div class="widget-title">
				<span><svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 55 55" style="enable-background:new #000080;" xml:space="preserve"><g><g><path style="fill:#D91F26;" d="M9.867,4h35.258c3.242,0,5.876,2.628,5.876,5.876v35.258c-0.011,2.373-1.452,4.508-3.644,5.406c-2.186,0.921-4.711,0.433-6.404-1.234L5.695,14.048c-1.67-1.687-2.158-4.218-1.234-6.404C5.359,5.446,7.494,4.012,9.867,4"></path></g></g></svg></span>
				<span><h2>संबन्धित खबरें</h2></span>
			</div>
			<?php 
			
			
			for($i=0; $i<5;$i++){ if(isset($related[$i])){ if($related[$i]['slug']!=$single_post['slug']){ ?>
			<div class="py-2 border-bottom widget-2">
				<div class="row no-gutters">
					<div class="col-4 my-auto">
						<img src="/images/<?php echo $related[$i]['featured_image'];?>" width="100%" height="55px" alt="<?php echo $related[$i]['title']; ?>">
					</div>
					<div class="col-8 my-auto">
					    <a href="<?php echo site_url('hi/post/'.$related[$i]['slug']); ?>">
						<h3><?php echo $related[$i]['title']; ?></h3></a>
					</div>
				</div>
			</div>
			<?php }}} ?>
			</div>
			<div class="mb-4">
			<div class="widget-title">
				<span><svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 55 55" style="enable-background:new #000080;" xml:space="preserve"><g><g><path style="fill:#D91F26;" d="M9.867,4h35.258c3.242,0,5.876,2.628,5.876,5.876v35.258c-0.011,2.373-1.452,4.508-3.644,5.406c-2.186,0.921-4.711,0.433-6.404-1.234L5.695,14.048c-1.67-1.687-2.158-4.218-1.234-6.404C5.359,5.446,7.494,4.012,9.867,4"></path></g></g></svg></span>
				<span><h2>लेटेस्ट </h2></span>
			</div>
			<?php for($i=1; $i<6;$i++){ if(isset($latest[$i])){?>
			<div class="py-2 border-bottom widget-2">
				<div class="row no-gutters">
					<div class="col-4 my-auto">
						<img src="/images/<?php echo $latest[$i]['featured_image']; ?>" width="100%" height="55px" alt="<?php echo $latest[$i]['title']; ?>">
					</div>
					<div class="col-8 my-auto">
					    <a href="<?php echo site_url('hi/post/'.$latest[$i]['slug']); ?>">
						<h3><?php echo $latest[$i]['title']; ?></h3></a>
					</div>
				</div>
			</div>
			<?php }} ?>
			</div>
		</div>
		
	</div>
	<div class="row m-1">
	    <div class="col-12">
	        <div class="col-12 p-2 text-center" id="footer-ad">
			        <?php echo $ad['footer_ad']; ?>
			</div>
	    </div>
	</div>
	
</div>

<script>
//In article ad


$( document ).ready(function(e) {
    var ads=$("#inArticle").html();
    $("#pcontent p:nth-child(3)").append(ads);
    $("#inArticle").remove();
    
});

// In Article ad ends

//Read Also

<?php 

if(!empty($read_also)){ ?>
$( document ).ready(function(e) {
    var read_also='<div class="my-3 read-also"><h3>ये भी पढ़ें</h3><ul><?php foreach($read_also as $read){if($read["slug"]!=$single_post["slug"]){?><li class="py-1"><a href="<?php echo site_url("hi/post/".$read["slug"]); ?>"><?php echo $read["title"]; ?></a></li><?php }} ?></ul></div>';
    $("#pcontent").append(read_also);
     
});

<?php } ?>
//Read Also




function printDiv(divName) {
	 document.getElementById('print_logo').style.display='block';
     var printContents = document.getElementById(divName).innerHTML;
     var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;

     window.print();

     document.body.innerHTML = originalContents;
	 
	 document.getElementById('print_logo').style.display='none';
}
</script>

    <script src="https://cdn.plyr.io/3.5.6/plyr.js"></script>
  <script>
          document.addEventListener('DOMContentLoaded', () => {
          // Controls (as seen below) works in such a way that as soon as you explicitly define (add) one control
          // to the settings, ALL default controls are removed and you have to add them back in by defining those below.
          // For example, let's say you just simply wanted to add 'restart' to the control bar in addition to the default.
          // Once you specify *just* the 'restart' property below, ALL of the controls (progress bar, play, speed, etc) will be removed,
          // meaning that you MUST specify 'play', 'progress', 'speed' and the other default controls to see them again.
             const controls = [
              'play-large', // The large play button in the center
              'restart', // Restart playback
              'rewind', // Rewind by the seek time (default 10 seconds)
              'play', // Play/pause playback
              'fast-forward', // Fast forward by the seek time (default 10 seconds)
              'progress', // The progress bar and scrubber for playback and buffering
              'current-time', // The current time of playback
              'duration', // The full duration of the media
              'mute', // Toggle mute
              'volume', // Volume control
              'captions', // Toggle captions
              'settings', // Settings menu
              'pip', // Picture-in-picture (currently Safari only)
              'airplay', // Airplay (currently Safari only)
             // 'download', // Show a download button with a link to either the current source or a custom URL you specify in your options
              'fullscreen' // Toggle fullscreen
          ];
          const player = Plyr.setup('.js-player', { controls });
      });
  </script>
  
  <script>window.twttr = (function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0],
    t = window.twttr || {};
  if (d.getElementById(id)) return t;
  js = d.createElement(s);
  js.id = id;
  js.src = "https://platform.twitter.com/widgets.js";
  fjs.parentNode.insertBefore(js, fjs);

  t._e = [];
  t.ready = function(f) {
    t._e.push(f);
  };

  return t;
}(document, "script", "twitter-wjs"));



</script>