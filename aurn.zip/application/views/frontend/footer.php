
<div class="main-footer container-fluid bg-dark text-light border-top border-danger border-5">
    <div class="container">
        <div class="row justify-content-center m-1">
            <div class="col-md-10 col-12 text-center p-2">
                <?php if(isset($footer_menus)){ foreach ($footer_menus as $menu){ ?>
				<a class="mx-2 p-2" target="<?php echo $menu['target']; ?>" href="<?php echo $menu['href']; ?>"><span><?php echo $menu['text']; ?></span></a>
			<?php }} ?>
            </div>
        </div>
        <div class="row">
            <div class="py-2 my-auto bg-dark col-12 text-center mx-auto small">
                <a href="https://www.meity.gov.in/writereaddata/files/Intermediary_Guidelines_and_Digital_Media_Ethics_Code_Rules-2021.pdf" rel="noreferrer noopener" ><small> We strictly follow the Information Technology (Intermediary Guidelines and Digital Media Ethics Code) Rules 2021</small></a>
            </div>
            <div class="py-2 my-auto bg-dark col-12 text-center mx-auto">
                <a href="https://validator.w3.org/feed/check.cgi?url=<?php echo urlencode(base_url('feeds')); ?>"><img src="/images/valid-rss-rogers.png" alt="[Valid RSS]" title="Validate my RSS feed" /></a>
            </div>
            <div class="py-2 my-auto bg-dark col-12 text-center mx-auto">
                Copyright © <?php echo date('Y'); ?> Aurangabad Now. For reprint rights: <a rel="noreferrer noopener" target="_blank" href="https://tankaar.in">Tankaar Infratech Private Limited</a> 
            </div>
        </div>
	</div>
 </div>






























<script>
	window.onscroll = function() {myFunction()};

	var mainmenu = document.getElementById("mainmenu");
	var sticky = mainmenu.offsetTop;
	
    var videosource = document.getElementById("videosource");
	if(videosource){var stickyv = videosource.offsetTop;}

	function myFunction() {
	  if (window.pageYOffset >= sticky) {
		mainmenu.classList.add("sticky_menu");
		document.getElementById('logo_retina').classList.remove("d-md-inline-block");
		document.getElementById('logo_mini').classList.add("d-md-inline-block");
		
	
		
	  } else {
		mainmenu.classList.remove("sticky_menu");
		document.getElementById('logo_retina').classList.add("d-md-inline-block");
		document.getElementById('logo_mini').classList.remove("d-md-inline-block");
	
	}
	
	<?php if(isset($single_post)){ if($single_post['post_format']=="Video" && json_decode($single_post['source'],TRUE)){ ?>
	
	if (window.pageYOffset >= stickyv) {
	
		videosource.classList.add("sticky_video");
		document.getElementById('post-content').classList.add("margin_content_stickyv");
	   

		
	  } else {
		
		videosource.classList.remove("sticky_video");
	   document.getElementById('post-content').classList.remove("margin_content_stickyv");
	}
	
	<?php }} ?>
	
	
	}

	
</script>
<!-- Font Awesome -->
<link
  href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css"
  rel="stylesheet"/>
<!-- Google Fonts -->
<link
  href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap"
  rel="stylesheet"/>
<!-- MDB -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/3.3.0/mdb.min.js"></script>

<script>
function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}
</script>

<!-- start webpushr code --> <script>(function(w,d, s, id) {if(typeof(w.webpushr)!=='undefined') return;w.webpushr=w.webpushr||function(){(w.webpushr.q=w.webpushr.q||[]).push(arguments)};var js, fjs = d.getElementsByTagName(s)[0];js = d.createElement(s); js.id = id;js.async=1;js.src = "https://cdn.webpushr.com/app.min.js";fjs.parentNode.appendChild(js);}(window,document, 'script', 'webpushr-jssdk'));webpushr('setup',{'key':'BNda25i6MECZxURvcbgA-5n1I-w0WBstfmDYosd3PBr635soeIJwearP1FfkzQVNKQcEQaZOwZnsKidxaLHlUto' });</script><!-- end webpushr code -->
	</body>
</html>