<div class="container mt-3">
    
	<div class="row my-3">
	   <div class="row m-3">
		<div class="d-none d-md-block col-12 mx-3 text-center" id="top-ad">
			
		    <?php echo $ad['top_ad']; ?>
			
		</div>
	</div>
		<div class="col-12 py-2 my-2">
			<span><a href="/">होम</a></span><span class="px-3">/</span><span onclick="location.href='<?php echo site_url('hi/tag/'.$breadcrumbs['tag']['slug']); ?>';" style="cursor:pointer" class="px-1 badge bg-danger"><?php echo $breadcrumbs['tag']['name']; ?></span></div>
		<div class="col-md-9 col-12">
			<div class="title border-bottom">
				<h1><?php echo $tag['name']; ?></h1>
			</div>
			
			<?php 
			
			//print_r($post_loops);
		if(isset($post_loops)){
			foreach($post_loops as $key=>$loop){ if($key==1 && $ad['category_feed_ad']!=""){?>
			    <div class="row p-2 border-bottom">
			        <div class="col-12">
			            <?php echo $ad['category_feed_ad']; ?>
			        </div>
			    </div>
			    <?php } ?>
				<div class="row p-2 border-bottom">
					<div class="col-4">
						<img src="/images/<?php echo $loop['featured_image']; ?>" width="100%" height="auto">
					</div>
					<div class="col-8 widget-2">
					    <a href="<?php echo site_url('hi/post/'.$loop['slug']); ?>">
						<h2><?php echo $loop['title']; ?></h2></a>
						<p class="d-none d-md-block p-1 my-0 small text-info">
							<?php echo date('M d, Y', strtotime($loop['publish_date'])); ?>
						</p>
						<p class="d-none d-md-block p-2 my-0 small">
							<?php echo mb_substr(strip_tags($loop['content']),0,300); ?>...
						</p>
					</div>
				</div>
			<?php } }else{ ?>
			
			<h3 class="p-2 m-2">:( Sorry!</h3>
			<p class="p-2 m-2">इस कैटेगरी में कोई पोस्ट नहीं मिला</p>
			
			<?php } ?>
			
		</div>
		<div class="col-md-3 col-12">
            <div class="py-2 mb-4 text-center" id="sidebar-ad">
				<?php echo $ad['sidebar_ad']; ?>
			</div>
			<div class="mb-4">
			<div class="widget-title">
				<span><svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 55 55" style="enable-background:new #000080;" xml:space="preserve"><g><g><path style="fill:#D91F26;" d="M9.867,4h35.258c3.242,0,5.876,2.628,5.876,5.876v35.258c-0.011,2.373-1.452,4.508-3.644,5.406c-2.186,0.921-4.711,0.433-6.404-1.234L5.695,14.048c-1.67-1.687-2.158-4.218-1.234-6.404C5.359,5.446,7.494,4.012,9.867,4"></path></g></g></svg></span>
				<span><h2>लेटेस्ट </h2></span>
			</div>
			<?php for($i=1; $i<6;$i++){ if(isset($latest[$i])){?>
			<div class="py-2 border-bottom widget-2">
				<div class="row no-gutters">
					<div class="col-4 my-auto">
						<img src="/images/<?php echo $latest[$i]['featured_image']; ?>" width="100%" height="55px">
					</div>
					<div class="col-8 my-auto">
					    <a href="<?php echo site_url('hi/post/'.$latest[$i]['slug']); ?>">
						<h3><?php echo $latest[$i]['title']; ?></h3></a>
					</div>
				</div>
			</div>
			<?php }} ?>
			</div>
		</div>
		
	</div>
</div>