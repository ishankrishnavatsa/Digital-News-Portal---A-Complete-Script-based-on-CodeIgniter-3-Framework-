<?php $logged_in=$this->session->userdata('logged_in'); ?>
<link rel="stylesheet" href="https://cdn.plyr.io/3.5.6/plyr.css" />

<div class="container mt-3">
    <div class="row m-3">
		<div class="d-none d-md-block col-12 mx-3 text-center" id="top-ad">
			
		<?php echo $ad['top_ad']; ?>
			
		</div>
	</div>
	<div class="row my-3">
		<div class="col-12 py-2 my-2">
			<span><a href="/">होम</a></span>
			
			<span class="px-3">/</span>
			<span onclick="location.href='<?php echo site_url('hi/page/'.$breadcrumbs['page']['slug']); ?>';" class="px-1 badge bg-danger"><?php echo $breadcrumbs['page']['name']; ?></span>
			<?php if($logged_in && ($logged_in['role']=="Admin" || $logged_in['role']=="Author")){ ?>
				<span class="my-auto" style="float:right"><a href="<?php echo site_url('admin/edit/page/'.$page['pid']); ?>" class="btn btn-outline-info rounded-pill"><i class="fas fa-pen"></i> Edit Page</a></span>
			<?php } ?>
		</div>
		<div id="printableArea" class="col-md-9 col-12">
			<div id="print_logo" style="display:none">
				<img src="/images/logo_phone.webp"><br>
				<h2 class="p-2 border-bottom border-top my-2">खबरों को सबसे पहले पढ़ने के लिए विजिट करिए <?php echo site_url(); ?></h2>
				
				
			</div>
			<div class="title">
				<h1><?php echo $page['title']; ?></h1>
			</div>

			<div id="pcontent" class="pcontent" style="font-size:1.2em;line-height:1.5em">
					<?php echo $page['content']; ?>
				
			</div>
		
			<?php if($ad['below_article_ad']){ ?>
			<div class="py-2 mb-3 text-center" id="below-article-ad">
				<?php echo $ad['below_article_ad']; ?>
			</div>
			<?php } ?>

		</div>
		<div class="col-md-3 col-12">
		    <div class="py-2 mb-4 text-center" id="sidebar-ad">
				<?php echo $ad['sidebar_ad']; ?>
			</div>

			<div class="mb-4">
			<div class="widget-title">
				<span><svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 55 55" style="enable-background:new #000080;" xml:space="preserve"><g><g><path style="fill:#D91F26;" d="M9.867,4h35.258c3.242,0,5.876,2.628,5.876,5.876v35.258c-0.011,2.373-1.452,4.508-3.644,5.406c-2.186,0.921-4.711,0.433-6.404-1.234L5.695,14.048c-1.67-1.687-2.158-4.218-1.234-6.404C5.359,5.446,7.494,4.012,9.867,4"></path></g></g></svg></span>
				<span><h2>लेटेस्ट </h2></span>
			</div>
			<?php for($i=1; $i<6;$i++){ if(isset($latest[$i])){?>
			<div class="py-2 border-bottom widget-2">
				<div class="row no-gutters">
					<div class="col-4 my-auto">
						<img src="/images/<?php echo $latest[$i]['featured_image']; ?>" width="100%" height="55px">
					</div>
					<div class="col-8 my-auto">
					    <a href="<?php echo site_url('hi/post/'.$latest[$i]['slug']); ?>">
						<h3><?php echo $latest[$i]['title']; ?></h3></a>
					</div>
				</div>
			</div>
			<?php }} ?>
			</div>
		</div>
		
	</div>
</div>
<script>
//In article ad

//var node = document.getElementById("pcontent").lastChild;
//document.getElementById("myList1").appendChild(node);


$( document ).ready(function(e) {
    var ads='<div class="text-center my-3"><?php echo $ad["in_article_ad"]; ?></div>';
    $("#pcontent p:nth-child(2)").append(ads);
     
});

// In Article ad ends




function printDiv(divName) {
	 document.getElementById('print_logo').style.display='block';
     var printContents = document.getElementById(divName).innerHTML;
     var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;

     window.print();

     document.body.innerHTML = originalContents;
	 
	 document.getElementById('print_logo').style.display='none';
}
</script>

    <script src="https://cdn.plyr.io/3.5.6/plyr.js"></script>
  <script>
      document.addEventListener('DOMContentLoaded', () => {
          const player = Plyr.setup('.js-player');
      });
  </script>
  
  <script>window.twttr = (function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0],
    t = window.twttr || {};
  if (d.getElementById(id)) return t;
  js = d.createElement(s);
  js.id = id;
  js.src = "https://platform.twitter.com/widgets.js";
  fjs.parentNode.insertBefore(js, fjs);

  t._e = [];
  t.ready = function(f) {
    t._e.push(f);
  };

  return t;
}(document, "script", "twitter-wjs"));
</script>