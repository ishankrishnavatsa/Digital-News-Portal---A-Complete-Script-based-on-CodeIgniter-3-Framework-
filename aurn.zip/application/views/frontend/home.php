<div class="container mt-3">

	<div class="row m-3">
		<div class="col mx-auto col-auto" style="min-height:120px">
			<div class="row px-3 justify-content-md-center rounded-pill text-white" style="background:red; min-width:70vw;cursor: pointer;" onclick="location.href='<?php echo site_url('hi/breakingnews/'); ?>';">
				<div class="col col-md-3 col-12 my-auto text-center">
					<span class="px-2" style="font-size:1.5em;font-weight:bold"><i>BREAKING NEWS</i></span>
				</div>
				<div class="col col-md-9 text-center my-auto">
					<div id="breaking">
					  
					  <?php foreach ($breakings as $key=>$breaking){ if(isset($breaking)){ if(date('d M Y', strtotime($breaking['time']))==date('d M Y')){?>
						<div class="mySlides">
						  <?php echo $breaking['message']; ?>
					    </div>
					  <?php }} } ?>
					  
					</div>
				</div>
			</div>
		</div>
	</div>

	
	<div class="row m-3">
		<div class="d-none d-md-block col-12 mx-3 text-center" id="top-ad">
			
		<?php echo $ad['top_ad']; ?>
			
		</div>
	</div>
	<section class="mb-2" id="section-1">
	<div class="row no-gutters mt-3">
		<div class="col-md-3 col-12">
			<div class="py-2 widget-1"><a href="<?php if(isset($loops)){ echo site_url('hi/post/'.$loops[0]['slug']); ?>">
				<h2><?php echo $loops[0]['title']; ?></h2></a>
				<div class="relative small">
					<img src="/images/<?php echo $loops[0]['featured_image']; ?>" width="100%" height="150px" alt="<?php echo $loops[0]['title']; ?>">
					<?php if($loops[0]['post_format']!="Standard"){ ?><i class="bottom-left p-1 fas fa-<?php if($loops[0]['post_format']=="Video"){echo 'video';}elseif($loops[0]['post_format']=="Audio"){echo 'microphone-alt';} elseif($loops[0]['post_format']=="Photo Gallery"){echo 'camera';} ?> bg-dark text-white" style="left:0px"></i><?php } ?>
				</div>
				<p class="m-0 small"><?php if(strlen(strip_tags($loops[0]['content']))>200) {echo mb_substr(strip_tags($loops[0]['content']),0,strpos($loops[0]['content'],' ', 200));} ?>...</p>
			</div>
			<div class="py-2 widget-1"><a href="<?php echo site_url('hi/post/'.$loops[1]['slug']); ?>">
				<h3><?php echo $loops[1]['title']; ?></h3></a>
				<div class="row no-gutters">
					<div class="col-4 my-auto relative small">
						<img src="/images/<?php echo $loops[1]['featured_image']; ?>" width="100%" alt="<?php echo $loops[1]['title']; ?>">
						<?php if($loops[1]['post_format']!="Standard"){ ?><i class="bottom-left p-1 fas fa-<?php if($loops[1]['post_format']=="Video"){echo 'video';}elseif($loops[1]['post_format']=="Audio"){echo 'microphone-alt';} elseif($loops[1]['post_format']=="Photo Gallery"){echo 'camera';} ?> bg-dark text-white"></i><?php } ?>
					</div>
					<div class="col-8 my-auto">
						<p class="m-0 small"><?php if(strlen(strip_tags($loops[1]['content']))>240){ echo mb_substr(strip_tags($loops[1]['content']),0,strpos($loops[1]['content'],' ', 240));} ?>...</p>
					</div>
				</div>
			</div>
		</div>
		<?php } ?>
		<div class="col-md-4 col-12 widget-1">
			<div class="py-2" id="live-tv">
				<img src="/images/advertise.jpg" width="100%" alt="Advertise with us">
			</div>
			<?php for($i=2; $i<6;$i++){ if(isset($loops[$i])){ ?>
			<div class="py-2">
				<div class="row no-gutters">
					<div class="col-4 my-auto relative small">
						<img class="relative" src="/images/<?php echo $loops[$i]['featured_image']; ?>" width="100%" alt="<?php echo $loops[$i]['title']; ?>">
						<?php if($loops[$i]['post_format']!="Standard"){ ?><i class="bottom-left p-1 fas fa-<?php if($loops[$i]['post_format']=="Video"){echo 'video';}elseif($loops[$i]['post_format']=="Audio"){echo 'microphone-alt';} elseif($loops[$i]['post_format']=="Photo Gallery"){echo 'camera';} ?> bg-dark text-white"></i><?php } ?>
					</div>
					<div class="col-8 my-auto">
						<a href="<?php echo site_url('hi/post/'.$loops[$i]['slug']); ?>"><h3><?php echo $loops[$i]['title']; ?></h3></a>
					</div>
				</div>
			</div>
			<?php }} ?>
		</div>
		<div class="col-md-2 col-12 widget-2">
			<?php for($i=6; $i<14;$i++){ if(isset($loops[$i])){?>
			<div class="py-2">
				<div class="row no-gutters border-bottom">
					<div class="col-12 my-auto">
					    <a href="<?php echo site_url('hi/post/'.$loops[$i]['slug']); ?>">
						<h3>
							<?php if($loops[$i]['post_format']!="Standard"){ ?><i class="fas fa-<?php if($loops[$i]['post_format']=="Video"){echo 'video';}elseif($loops[$i]['post_format']=="Audio"){echo 'microphone-alt';} elseif($loops[$i]['post_format']=="Photo Gallery"){echo 'camera';} ?> "></i><?php } ?>
							<?php echo $loops[$i]['title']; ?>
						</h3></a>
					</div>
				</div>
			</div>
			<?php }} ?>
		</div>
		<div class="col-md-3 col-12 widget-2">
			<div class="py-2 text-center" id="sidebar-ad">
				<?php echo $ad['sidebar_ad']; ?>
			</div>
			<?php for($i=14; $i<18;$i++){if(isset($loops[$i])){ ?>
			<div class="py-2">
				<div class="row no-gutters">
					<div class="col-4 my-auto">
						<img src="/images/<?php echo $loops[$i]['featured_image']; ?>" width="100%" alt="<?php echo $loops[$i]['title']; ?>">
					</div>
					<div class="col-8 my-auto">
						<a href="<?php echo site_url('hi/post/'.$loops[$i]['slug']); ?>"><h3><?php echo $loops[$i]['title']; ?></h3></a>
					</div>
				</div>
			</div>
			<?php }}	?>
		</div>
	</div>
	</section>
	<section class="mb-2" id="section-2">
	<div class="row no-gutters mt-3">
		<div class="col-md-3 col-12">
			<div class="widget-title">
			<span><svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 55 55" style="enable-background:new #000080;" xml:space="preserve"><g><g><path style="fill:#D91F26;" d="M9.867,4h35.258c3.242,0,5.876,2.628,5.876,5.876v35.258c-0.011,2.373-1.452,4.508-3.644,5.406c-2.186,0.921-4.711,0.433-6.404-1.234L5.695,14.048c-1.67-1.687-2.158-4.218-1.234-6.404C5.359,5.446,7.494,4.012,9.867,4"></path></g></g></svg></span>
			<span><h2>बड़ी ख़बर</h2></span>
			</div>
		    <?php for($i=0; $i<5;$i++){ if(isset($bignews[$i])){ ?>
			<div class="py-2 widget-2">
				<div class="row no-gutters border-bottom">
					<div class="col-12 my-auto">
						<a href="<?php echo site_url('hi/post/'.$bignews[$i]['slug']); ?>"><h3><?php echo $bignews[$i]['title']; ?></h3></a>
					</div>
				</div>
			</div>
			<?php } } ?>	
		</div>
		<div class="col-md-6 col-12 widget-1">
			<div class="widget-title">
			<span> </span>
			</div>
			
			<div class="py-2">
				<div class="row widget-1">
				<?php for($i=0; $i<3;$i++){ if(isset($bihar[$i])){ ?>
					<div class="col-4">
						<div class="p-0 border rounded bg-light" style="min-height:250px">
							<img src="/images/<?php echo $bihar[$i]['featured_image']; ?>" width="100%" alt="<?php echo $bihar[$i]['title']; ?>">
							<a href="<?php echo site_url('hi/post/'.$bihar[$i]['slug']); ?>">
							<h3 class="p-2"><?php echo $bihar[$i]['title']; ?></h3></a>
						</div>
					</div>
				<?php } } ?>
				</div>
			</div>
			
		</div>
		<div class="col-md-3 col-12 widget-2">
			<div class="widget-title">
				<span><svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 55 55" style="enable-background:new 0 0 55 55;" xml:space="preserve"><g><g><path style="fill:#D91F26;" d="M9.867,4h35.258c3.242,0,5.876,2.628,5.876,5.876v35.258c-0.011,2.373-1.452,4.508-3.644,5.406c-2.186,0.921-4.711,0.433-6.404-1.234L5.695,14.048c-1.67-1.687-2.158-4.218-1.234-6.404C5.359,5.446,7.494,4.012,9.867,4"></path></g></g></svg></span>
				<span><h2>लाइव अपडेट</h2></span><span onclick="breaking_list()" style="float:right"><svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 24 24" style="enable-background:new 0 0 24 24;" xml:space="preserve"> <style type="text/css"> .st0001{fill:#B2B2B2;} </style> <g> <path class="st0001" d="M12,1C5.92,1,1,5.92,1,12s4.92,11,11,11c5.66,0,10.32-4.28,10.93-9.78c-0.18,0-1.94,0-2.47,0 c-0.6,4.14-4.16,7.33-8.46,7.33c-4.72,0-8.56-3.84-8.56-8.56S7.28,3.44,12,3.44c2.67,0,5.06,1.23,6.63,3.15l-2.96,2.96H23V2.22 l-2.64,2.64C18.34,2.5,15.35,1,12,1L12,1z"></path> </g> </svg></span>
			</div>
			<div  class="border rounded bg-info" onload="breaking_list()" style="height:250px; overflow-y:auto; cursor: pointer;" onclick="location.href='<?php echo site_url('hi/breakingnews/');?>';">
				<div id="wait" style="display:none">
					<video autoplay loop muted playsinline width="200px">  
					  <source src="/images/logo.webm" type="video/webm">  
					</video>
				</div>
				<div id="live-updates">
			</div>
		</div>
	</div>
	</section>
</div>

<?php 
//Widget 1
function widget_1($cat){ ?>
    
                <div class="row no-gutters mb-4">
					<div class="col-12">
						<div class="widget-title">
							<span><svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 55 55" style="enable-background:new 0 0 55 55;" xml:space="preserve"><g><g><path style="fill:#D91F26;" d="M9.867,4h35.258c3.242,0,5.876,2.628,5.876,5.876v35.258c-0.011,2.373-1.452,4.508-3.644,5.406c-2.186,0.921-4.711,0.433-6.404-1.234L5.695,14.048c-1.67-1.687-2.158-4.218-1.234-6.404C5.359,5.446,7.494,4.012,9.867,4"></path></g></g></svg></span>
							<span><h2><?php echo $cat['name']; ?></h2></span><span style="float:right"><h2>और भी →</h2></span>
						</div>
					</div>
					<div class="col-md-6 col-12">
						<div class="py-2 widget-3">
						    <div class="relative">
							<img loading="lazy" src="/images/<?php echo $cat['data'][0]['featured_image']; ?>" width="100%" height="230px" alt="<?php echo $cat['data'][0]['title']; ?>">
							<?php if($cat['data'][0]['post_format']!="Standard"){ ?><i class="bottom-left p-1 fas fa-<?php if($cat['data'][0]['post_format']=="Video"){echo 'video';}elseif($cat['data'][0]['post_format']=="Audio"){echo 'microphone-alt';} elseif($cat['data'][0]['post_format']=="Photo Gallery"){echo 'camera';} ?> bg-dark text-white"></i><?php } ?>
							</div>
							<a href="<?php echo site_url('hi/post/'.$cat['data'][0]['slug']); ?>">							<h2 class="p-2"><?php echo $cat['data'][0]['title']; ?></h2></a>
						</div>
						<div class="py-2 widget-4 border-bottom">
							<div class="row" >
								<div class="col-4 my-auto relative">
									<img loading="lazy" src="/images/<?php echo $cat['data'][1]['featured_image']; ?>" width="100%" height="90px" alt="<?php echo $cat['data'][1]['title']; ?>">
									<?php if($cat['data'][1]['post_format']!="Standard"){ ?><i class="bottom-left p-1 fas fa-<?php if($cat['data'][1]['post_format']=="Video"){echo 'video';}elseif($cat['data'][1]['post_format']=="Audio"){echo 'microphone-alt';} elseif($cat['data'][1]['post_format']=="Photo Gallery"){echo 'camera';} ?> bg-dark text-white"></i><?php } ?>
								</div>
								<div class="col-8 my-auto">
								    <a href="<?php echo site_url('hi/post/'.$cat['data'][1]['slug']); ?>">
									<h2 class="p-2"><?php echo $cat['data'][1]['title']; ?></h2></a>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-6 col-12">
					<?php for($i=2;$i<5;$i++){if(isset($cat['data'][$i])){  ?>
						<div class="py-2 widget-4 border-bottom">
							<div class="row">
								<div class="col-4 my-auto relative">
									<img loading="lazy" src="/images/<?php echo $cat['data'][$i]['featured_image']; ?>" width="100%" height="90px" alt="<?php echo $cat['data'][$i]['title']; ?>">
									<?php if($cat['data'][$i]['post_format']!="Standard"){ ?><i class="bottom-left p-1 fas fa-<?php if($cat['data'][$i]['post_format']=="Video"){echo 'video';}elseif($cat['data'][$i]['post_format']=="Audio"){echo 'microphone-alt';} elseif($cat['data'][$i]['post_format']=="Photo Gallery"){echo 'camera';} ?> bg-dark text-white"></i><?php } ?>
								</div>
								<div class="col-8 my-auto">
								    <a href="<?php echo site_url('hi/post/'.$cat['data'][$i]['slug']); ?>">
									<h2 class="p-2"><?php echo $cat['data'][$i]['title']; ?></h2></a>
								</div>
							</div>
						</div>
					<?php }} ?>
					</div>
				</div>


<?php }



function widget_2($cat){ ?>

				<div class="row no-gutters">
					<div class="col-12">
						<div class="widget-title">
							<span><svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 55 55" style="enable-background:new 0 0 55 55;" xml:space="preserve"><g><g><path style="fill:#D91F26;" d="M9.867,4h35.258c3.242,0,5.876,2.628,5.876,5.876v35.258c-0.011,2.373-1.452,4.508-3.644,5.406c-2.186,0.921-4.711,0.433-6.404-1.234L5.695,14.048c-1.67-1.687-2.158-4.218-1.234-6.404C5.359,5.446,7.494,4.012,9.867,4"></path></g></g></svg></span>
							<span><h2><?php echo $cat['name']; ?></h2></span><span style="float:right"><h2>और भी →</h2></span>
						</div>
					</div>
					<div class="col-12">
						<?php for($i=0; $i<7;$i++){ if(isset($cat['data'][$i])){ ?>
						<div class="py-2 widget-2">
							<div class="row no-gutters border-bottom">
								<div class="col-12 my-auto">
								    <a href="<?php echo site_url('hi/post/'.$cat['data'][$i]['slug']); ?>">
									<h3> <?php if($cat['data'][$i]['post_format']!="Standard"){ ?><i class="fas fa-<?php if($cat['data'][$i]['post_format']=="Video"){echo 'video';}elseif($cat['data'][$i]['post_format']=="Audio"){echo 'microphone-alt';} elseif($cat['data'][$i]['post_format']=="Photo Gallery"){echo 'camera';} ?> "></i><?php } ?> <?php echo $cat['data'][$i]['title']; ?></h3></a>
								</div>
							</div>
						</div>
						<?php } } ?>
					</div>
					<div class="col-12">
					</div>
				</div>





<?php } ?>




	<section class="mb-3" id="section-3">
	<div class="container-fluid d-flex align-items-center p-3" style="min-height:500px; background:red">
		<div class="container my-2">
			<div class="row">
				<div class="col-12">
					<div class="widget-title" style="color:#fff">
							<span><svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" viewBox="0 0 55 55" style="enable-background:new #000080;" xml:space="preserve"><g><g><path style="fill:#D91F26;" d="M9.867,4h35.258c3.242,0,5.876,2.628,5.876,5.876v35.258c-0.011,2.373-1.452,4.508-3.644,5.406c-2.186,0.921-4.711,0.433-6.404-1.234L5.695,14.048c-1.67-1.687-2.158-4.218-1.234-6.404C5.359,5.446,7.494,4.012,9.867,4"></path></g></g></svg></span>
							<span><h2>विडियो </h2></span><span style="float:right"><h2>और भी →</h2></span>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-2 col-6 order-lg-first">
						<div class="py-2 widget-5">
							<img loading="lazy" src="/images/<?php echo $videos[1]['featured_image']; ?>" width="100%" class="border border-white" alt="<?php echo $videos[1]['title']; ?>">
							<a href="<?php echo site_url('hi/post/'.$videos[1]['slug']); ?>">
							<h2 class="py-2"><?php echo $videos[1]['title']; ?></h2></a>
					    </div>
					    <div class="py-2 widget-5">
							<img src="/images/<?php echo $videos[2]['featured_image']; ?>" width="100%" class="border border-white" alt="<?php echo $videos[2]['title']; ?>">
							<a href="<?php echo site_url('hi/post/'.$videos[2]['slug']); ?>">
							<h2 class="py-2"><?php echo $videos[2]['title']; ?></h2></a>
					    </div>
					
					
				</div>
				<div class="col-md-8 col-12 my-auto order order-first">
					<div class="p-2 widget-3">
							<img loading="lazy" src="/images/<?php echo $videos[0]['featured_image']; ?>" width="100%" class="border border-white" alt="<?php echo $videos[0]['title']; ?>">
							<a href="<?php echo site_url('hi/post/'.$videos[0]['slug']); ?>">
							<h2><?php echo $videos[0]['title']; ?></h2></a>
					</div>
				</div>
				<div class="col-md-2 col-6">
                        <div class="py-2 widget-5">
							<img loading="lazy" src="/images/<?php echo $videos[3]['featured_image']; ?>" width="100%" class="border border-white" alt="<?php echo $videos[3]['title']; ?>">
							<a href="<?php echo site_url('hi/post/'.$videos[3]['slug']); ?>">
							<h2 class="py-2"><?php echo $videos[3]['title']; ?></h2></a>
					    </div>
					    <div class="py-2 widget-5">
							<img loading="lazy" src="/images/<?php echo $videos[4]['featured_image']; ?>" width="100%" class="border border-white" alt="<?php echo $videos[4]['title']; ?>">
							<a href="<?php echo site_url('hi/post/'.$videos[4]['slug']); ?>">
							<h2 class="py-2"><?php echo $videos[4]['title']; ?></h2></a>
					    </div>
				</div>
			</div>
		</div>
	</div>
	</section>
	<section id="section-4" class="mb-3">
	<div class="container">
		<div class="row">
			<div class="col-md-9 col-12">
			<!---Widget Area Start--->
			<?php 
				
				//Aurangabad
				$aur= array('name'=>'औरंगाबाद','data'=>$aurangabad);
				echo widget_1($aur);
				//Bihar
				$bh= array('name'=>'बिहार','data'=>$bihar);
				echo widget_1($bh);
				
				
				?>
            <!--Widget Area Ends -->
			</div>
			<div class="col-md-3 col-12">
			 
			    
			
            <!-- Widegt Area SideBar -->
            
            <?php 
            
            
            //Social Viral
				$vir= array('name'=>'सोशल वायरल','data'=>$viral);
				echo widget_2($vir);
            
            ?>
            
            <!--widget area side bar -->
			</div>
		</div>
	</div>
	</section>

<script>
	function breaking_list(){
            $.ajax({
				type:'post',
				dataType:'html',
                url:"<?php echo site_url('hi/live_updates/widget');?>",
                success:function(result){
                    $("#live-updates").html(result);
                }
            });
	}

	$(document).ready(breaking_list())
	
</script>
<script>
var slideIndex = 0;
carousel();

function carousel() {
  var i;
  var x = document.getElementsByClassName("mySlides");
  for (i = 0; i < x.length; i++) {
    x[i].style.display = "none"; 
  }
  slideIndex++;
  if (slideIndex > x.length) {slideIndex = 1} 
  x[slideIndex-1].style.display = "block"; 
  setTimeout(carousel, 5000); 
}
</script>
