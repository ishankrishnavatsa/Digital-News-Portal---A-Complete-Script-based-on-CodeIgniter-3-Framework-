User-agent: *
Disallow: /live_updates/
Sitemap: <?php echo site_url('sitemap.xml'); ?>