<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

    class Push {

	public function __construct () {
		$this->ci =& get_instance();
       
	}
    
 
  function send_push($title,$msg,$slug,$img){


            $end_point = 'https://api.webpushr.com/v1/notification/send/all';
            
            $http_header = array( 
                "Content-Type: Application/Json", 
                "webpushrKey: 220ca065eb03eb9c8296473097a9a00f", 
                "webpushrAuthToken: 30541"
            );
            
            $req_data = array(
                'title' 		=> $title, //required
                'message' 		=> $msg, //required
                'target_url'	=> site_url('hi/post/'.$slug), //required
            
                //following parameters are optional
                //'name'		=> 'Test campaign',
                //'icon'		=> site_url('images/'.$img),
               // 'image'		=> site_url('images/'.$img),
                //'auto_hide'	=> 1,
                //'expire_push'	=> '5m',
                //'send_at'		=> '2021-05-28 14:38 +5:30',
                //'action_buttons'=> array(	
                    //array('title'=> 'Demo', 'url' => 'https://www.webpushr.com/demo'),
                    //array('title'=> 'Rates', 'url' => 'https://www.webpushr.com/pricing')
                //)
            );
            
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_HTTPHEADER, $http_header);
            curl_setopt($ch, CURLOPT_URL, $end_point );
            curl_setopt($ch, CURLOPT_POST, 1);
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($req_data) );
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            
            $response = curl_exec($ch);
            return $response;
            }
















}
?>