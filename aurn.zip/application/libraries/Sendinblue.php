<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class Sendinblue {

	public function __construct () {
		$this->ci =& get_instance();
       
	}
    
 

	public function send($toemail, $subject, $message) 
    {
        
        
 
			include 'api/sendinblue/Mailin.php';
			$mailin = new Mailin('mail2testseries@gmail.com', '13BntIL5VYjm2a7d');
			$mailin->
			addTo($toemail)->
			setFrom('mail2testseries@gmail.com', 'testseries.online')->
			setReplyTo('mail2testseries@gmail.com','testseries.online')->
			setSubject($subject)->
			setHtml($message);
			$res = $mailin->send();
			/**
			Successful send message will be returned in this format:
			{'result' => true, 'message' => 'Email sent'}
			*/
			return $res;

	}

public function welcome_email($toemail,$name){

	require 'api/sendinblue/vendor/autoload.php';
	
	$config = SendinBlue\Client\Configuration::getDefaultConfiguration()->setApiKey('api-key', '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');
	
	$apiInstance = new SendinBlue\Client\Api\TransactionalEmailsApi(
		new GuzzleHttp\Client(),
		$config
	);
	$sendSmtpEmail = new \SendinBlue\Client\Model\SendSmtpEmail();
	$sendSmtpEmail['sender'] = array('name' => 'Testseries.me','email'=>'listen@testseries.me');
	$sendSmtpEmail['templateId'] = 2;
	$sendSmtpEmail['params'] = array('NAME'=>$name);
	$sendSmtpEmail['to'] = array(
		array('email' => $toemail, 'name' => $name)
	);
	$sendSmtpEmail['replyTo'] = array('email' => 'listen@testseries.me', 'name' => 'Testbook.me');

	
	try {
		$result = $apiInstance->sendTransacEmail($sendSmtpEmail);
		//print_r($result);
	} catch (Exception $e) {
		//echo 'Exception when calling TransactionalEmailsApi->sendTransacEmail: ', $e->getMessage(), PHP_EOL;
	}


}

public function account_confirmation($toemail,$name,$vcode){

	require 'api/sendinblue/vendor/autoload.php';
	
	$config = SendinBlue\Client\Configuration::getDefaultConfiguration()->setApiKey('api-key', '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');
	
	$apiInstance = new SendinBlue\Client\Api\TransactionalEmailsApi(
		new GuzzleHttp\Client(),
		$config
	);
	$sendSmtpEmail = new \SendinBlue\Client\Model\SendSmtpEmail();
	$sendSmtpEmail['sender'] = array('name' => 'Testseries.me','email'=>'listen@testseries.me');
	$sendSmtpEmail['templateId'] = 9;
	$sendSmtpEmail['params'] = array('NAME'=>$name, 'OTP'=>$vcode);
	$sendSmtpEmail['to'] = array(
		array('email' => $toemail, 'name' => $name)
	);
	$sendSmtpEmail['replyTo'] = array('email' => 'listen@testseries.me', 'name' => 'Testbook.me');

	
	try {
		$result = $apiInstance->sendTransacEmail($sendSmtpEmail);
		//print_r($result);
	} catch (Exception $e) {
		//echo 'Exception when calling TransactionalEmailsApi->sendTransacEmail: ', $e->getMessage(), PHP_EOL;
	}


}

public function resend_code($toemail,$name,$vcode){

	require 'api/sendinblue/vendor/autoload.php';
	
	$config = SendinBlue\Client\Configuration::getDefaultConfiguration()->setApiKey('api-key', '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');
	
	$apiInstance = new SendinBlue\Client\Api\TransactionalEmailsApi(
		new GuzzleHttp\Client(),
		$config
	);
	$sendSmtpEmail = new \SendinBlue\Client\Model\SendSmtpEmail();
	$sendSmtpEmail['sender'] = array('name' => 'Testseries.me','email'=>'listen@testseries.me');
	$sendSmtpEmail['templateId'] = 10;
	$sendSmtpEmail['params'] = array('NAME'=>$name, 'OTP'=>$vcode);
	$sendSmtpEmail['to'] = array(
		array('email' => $toemail, 'name' => $name)
	);
	$sendSmtpEmail['replyTo'] = array('email' => 'listen@testseries.me', 'name' => 'Testbook.me');

	
	try {
		$result = $apiInstance->sendTransacEmail($sendSmtpEmail);
		//print_r($result);
	} catch (Exception $e) {
		//echo 'Exception when calling TransactionalEmailsApi->sendTransacEmail: ', $e->getMessage(), PHP_EOL;
	}


}

function get_template(){

	require 'api/sendinblue/vendor/autoload.php';

	$config = SendinBlue\Client\Configuration::getDefaultConfiguration()->setApiKey('api-key', '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');

	$apiInstance = new SendinBlue\Client\Api\TransactionalEmailsApi(
		new GuzzleHttp\Client(),
		$config
	);
	$templateStatus = 'true';
	$limit = 50;
	$offset = 0;
	
	try {
		$result = $apiInstance->getSmtpTemplates($templateStatus, $limit, $offset);
		return json_decode($result,true);
	} catch (Exception $e) {
		echo 'Exception when calling TransactionalEmailsApi->getSmtpTemplates: ', $e->getMessage(), PHP_EOL;
		exit;
	}

	
}

function add_contact($emails){

	require 'api/sendinblue/vendor/autoload.php';

	$config = SendinBlue\Client\Configuration::getDefaultConfiguration()->setApiKey('api-key', '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');

	$apiInstance = new SendinBlue\Client\Api\ContactsApi(
		new GuzzleHttp\Client(),
		$config
	);
	$listId = 6;
	$contactIdentifiers = new \SendinBlue\Client\Model\AddContactToList();
	$contactIdentifiers['emails'] = $emails;

	try {
		$result = $apiInstance->addContactToList($listId, $contactIdentifiers);
		//print_r($result);
	} catch (Exception $e) {
		//echo 'Exception when calling ContactsApi->addContactToList: ', $e->getMessage(), PHP_EOL;
		
	}


}

function create_campaign($c_name,$temp_id,$subject){

	require 'api/sendinblue/vendor/autoload.php';

	$config = SendinBlue\Client\Configuration::getDefaultConfiguration()->setApiKey('api-key', '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');

	$apiInstance = new SendinBlue\Client\Api\EmailCampaignsApi(
		new GuzzleHttp\Client(),
		$config
	);
	$emailCampaigns = new \SendinBlue\Client\Model\CreateEmailCampaign();
	date_default_timezone_set("Asia/Kolkata");

	$emailCampaigns['sender'] =  array('name' => 'Testseries.me', 'email' => 'listen@testseries.me');
	$emailCampaigns['name'] = $c_name;
	$emailCampaigns['templateId'] = (int)$temp_id;
	$emailCampaigns['scheduledAt'] = date(DATE_RFC3339,time()+3600);
	$emailCampaigns['subject'] = $subject;
	$emailCampaigns['replyTo'] = 'listen@testseries.me';
	$emailCampaigns['toField'] = '{{contact.FIRSTNAME}} {{contact.LASTNAME}}';
	$emailCampaigns['recipients'] =  array(
		'listIds' => array(6)
	);
	$emailCampaigns['type'] = 'classic';
	$emailCampaigns['header'] = 'If you are not able to see this mail, click {here}';
	$emailCampaigns['footer'] = 'If you wish to unsubscribe from our newsletter, click {here}';
	
	try {
		$result = $apiInstance->createEmailCampaign($emailCampaigns);
		return $result;
	} catch (Exception $e) {
		echo 'Exception when calling EmailCampaignsApi->createEmailCampaign: ', $e->getMessage(), PHP_EOL;
		
	}
}





















}






















?>


















