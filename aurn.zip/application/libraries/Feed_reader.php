<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

    class Feed_reader {

	public function __construct () {
		$this->ci =& get_instance();
       
	}
    
 
  function feed_data($url){
    
   
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        //curl_setopt($ch, CURLOPT_HTTPHEADER, $requestHeaders);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        // get the result of http query
        $output = curl_exec($ch);
        curl_close($ch);
        
        //$rss_feed = new DOMDocument();
        $rss_feed=simplexml_load_string($output);
        
        if(!empty($rss_feed)) {

        return $rss_feed;
        
         }else {
             
             return "No Data";
         }
    
    
      
  }
  
  function slug($string, $delimiter = '-') {
      
        $string = preg_replace("/[~`{}.'\"\!\@\#\$\%\^\&\*\(\)\_\=\+\/\?\>\<\,\[\]\:\;\|\\\]/", "", $string);
    
       
        $string = preg_replace("/[\/_|+ -]+/", $delimiter, $string);
    
        return $string;

    }































}



















?>