<?php
Class main_model extends CI_Model
{

//Basic Input Output Page/Post

	function insert($type){
		
		if($type=='page'){
			
			$userdata=array(
			'title'=>$this->input->post('title'),
			'slug'=>$this->input->post('slug'),
			'content'=>$this->input->post('content'),
			'status'=>$this->input->post('status'),
			'publish_date'=>date('c'),
			'modified_date'=>date('c'),
			);
			
			if($_FILES['file']['name']){
		 $this->load->library('image_lib');
		 
		  // Set preference 
         $config['upload_path'] = './images/'; 
         $config['allowed_types'] = 'jpg|jpeg|png|gif|webp'; 
         $config['max_size'] = '1000000'; // max_size in kb 
         $config['file_name'] = $_FILES['file']['name']; 

         // Load upload library 
          $this->load->library('upload', $config);
   
         // File upload
         if($this->upload->do_upload('file')){ 
            // Get data about the file
            $uploadData = $this->upload->data();
		    $configer =  array(
              'image_library'   => 'gd2',
              'source_image'    =>  $uploadData['full_path'],
              'maintain_ratio'  =>  FALSE,
              'width'           =>  1200,
              'height'          =>  631,
            );
            $this->image_lib->clear();
            $this->image_lib->initialize($configer);
            $this->image_lib->resize();
            $filename = $uploadData['file_name']; 
        
            $destination=$config['upload_path'].pathinfo($filename, PATHINFO_FILENAME).".webp";
            $source=$config['upload_path'].$filename;
                 
        	$extension = pathinfo($source, PATHINFO_EXTENSION);
        	if ($extension == 'jpeg' || $extension == 'jpg') 
        		$image = imagecreatefromjpeg($source);
        	elseif ($extension == 'gif') 
        		$image = imagecreatefromgif($source);
        	elseif ($extension == 'png') 
        		$image = imagecreatefrompng($source);
        	imagewebp($image, $destination, 80);
		 
			$userdata['featured_image']=pathinfo($filename, PATHINFO_FILENAME).".webp";
			
			}
		}
			
		}
		
		if($type=='breaking'){
			
			$userdata=array(
				'message'=>$this->input->post('breaking'),
				'time'=>date('c'),
				'status'=>'Active',
			);
			
		}
		
		if($type=='category'){
			
			$userdata=array(
				'name'=>$this->input->post('name'),
				'slug'=>$this->input->post('slug'),
				'description'=>$this->input->post('description'),
				'parent'=>$this->input->post('parent'),
				'status'=>'Active',
			);
			
			
		}
		
		if($type=='tag'){
			
			$userdata=array(
				'name'=>ltrim($this->input->post('name')),
				'slug'=>ltrim($this->input->post('slug')),
				'description'=>$this->input->post('description'),
			);
			
		}
		
		if($type=='menu'){
			
			$userdata=array(
				'name'=>$this->input->post('name'),
				'item'=>$this->input->post('item'),
				'location'=>implode(",",$this->input->post('location')),
				'status'=>'Active',
			);
			
		}
		
		if($type=='user'){
			
			$userdata=array(
				'name'=>$this->input->post('name'),
				'username'=>$this->input->post('username'),
				'email'=>$this->input->post('email'),
				'password'=>md5($this->input->post('password')),
                'role'=>$this->input->post('role'),
				'status'=>$this->input->post('status'),
				'date'=>date('c'),
			);
			
		}
		
		
		
		
		
		$this->db->insert($type,$userdata);
		$insert_id=$this->db->insert_id();
		
		if($type=='menu'){
			
			foreach($this->input->post('location') as $menu_location){
				
				$setting_data[$menu_location]=$insert_id;
				
			}
			
			
			$this->db->where('id','1');
			$this->db->update('settings',$setting_data);
		}
		
		
		
		$result=array(
			'id'=>$insert_id,
			'status'=>TRUE,
		);
		
		return $result;
		
	}
	
	
	
	function update($type,$id){
			
	   if($type=='post'){
	       
			if($this->input->post('publish_date')==""){
			    $date=date('c');
			}else{
			    $date=$this->input->post('publish_date');
			}
			
			$userdata=array(
			'title'=>$this->input->post('title'),
			'slug'=>$this->input->post('slug'),
			'content'=>$this->input->post('content'),
			'status'=>$this->input->post('status'),
			'publish_date'=>$date,
			'modified_date'=>date('c'),
			'subtitle'=>$this->input->post('subtitle'),
			'cid'=>implode(",",$this->input->post('category')),
			'tags'=>$this->input->post('tag'),
			'author'=>$this->input->post('author'),
			'post_format'=>$this->input->post('post_format'),
			'place'=>$this->input->post('place'),
			'news_source'=>$this->input->post('news_source'),
			'meta_description'=>$this->input->post('meta_description'),
			'meta_keywords'=>$this->input->post('meta_keywords'),
			'site_title'=>$this->input->post('site_title'),

			);
			
			if($this->input->post('highlights')!=''){
				
				$userdata['highlights']=implode("|",$this->input->post('highlights'));
				
			}
			
			if($this->input->post('post_format')=="Video" || $this->input->post('post_format')=="Audio"){
				
				$source=array(
						'type'=>$this->input->post('type'),
						'url'=>$this->input->post('source'),
					);
				
				$userdata['source']=json_encode($source);
				
				
			}elseif($this->input->post('post_format')=="Photo Gallery"){
				foreach($this->input->post('slide') as $key=>$slide){
					$source[]=array(
						'pic'=>$slide,
						'caption'=>$this->input->post('slide_caption')[$key],
					);
				  }
				$userdata['source']=json_encode($source);
			}
			
		foreach(explode(",",$this->input->post('tag')) as $tag){
			
			$this->db->where('name',$tag);
			$query=$this->db->get('tag');
			$result=$query->row_array();
			
			if(!$result){
				$data['slug']=ltrim($tag);
				$data['name']=ltrim($tag);
				$this->db->insert('tag',$data); 
			}
			
		}
		
		if($_FILES['file']['name']){
		 $this->load->library('image_lib');
		 
		  // Set preference 
         $config['upload_path'] = './images/'; 
         $config['allowed_types'] = 'jpg|jpeg|png|gif|webp'; 
         $config['max_size'] = '1000000'; // max_size in kb 
         $config['file_name'] = $_FILES['file']['name']; 

         // Load upload library 
          $this->load->library('upload', $config);
   
         // File upload
         if($this->upload->do_upload('file')){ 
            // Get data about the file
            $uploadData = $this->upload->data();
		    $configer =  array(
              'image_library'   => 'gd2',
              'source_image'    =>  $uploadData['full_path'],
              'maintain_ratio'  =>  FALSE,
              'width'           =>  1200,
              'height'          =>  631,
            );
            $this->image_lib->clear();
            $this->image_lib->initialize($configer);
            $this->image_lib->resize();
            $filename = $uploadData['file_name']; 
        
            $destination=$config['upload_path'].pathinfo($filename, PATHINFO_FILENAME).".webp";
            $source=$config['upload_path'].$filename;
                 
        	$extension = pathinfo($source, PATHINFO_EXTENSION);
        	if ($extension == 'jpeg' || $extension == 'jpg') 
        		$image = imagecreatefromjpeg($source);
        	elseif ($extension == 'gif') 
        		$image = imagecreatefromgif($source);
        	elseif ($extension == 'png') 
        		$image = imagecreatefrompng($source);
        	imagewebp($image, $destination, 80);
		 
			$userdata['featured_image']=pathinfo($filename, PATHINFO_FILENAME).".webp";
			
			}
		 }
		 
		 
	
		    if($this->input->post('push')==1){
		        $this->load->library('push');
		        $this->db->where('aid',$id);
		        $q=$this->db->get('post');
		        $push_data=$q->row_array();
		        
		        if(strlen(strip_tags($push_data['content']))>100) {
		            $push_content=mb_substr(strip_tags($push_data['content']),0,strpos($push_data['content'],' ', 100));
		            }
		           else{
		               
		                $push_content="";
		           }
		        
		        $this->push->send_push($push_data['title'],ltrim($push_content),$push_data['slug'],$push_data['featured_image']);
		    }
		
		 
		 
		 
		 
		 
		 
		 
		 
		 
	   }
	   
	   	if($type=='page'){
			
			$userdata=array(
			'title'=>$this->input->post('title'),
			'slug'=>$this->input->post('slug'),
			'content'=>$this->input->post('content'),
			'status'=>$this->input->post('status'),
			'publish_date'=>date('c'),
			'modified_date'=>date('c'),
			);
			
			if($_FILES['file']['name']){
		 $this->load->library('image_lib');
		 
		  // Set preference 
         $config['upload_path'] = './images/'; 
         $config['allowed_types'] = 'jpg|jpeg|png|gif|webp'; 
         $config['max_size'] = '1000000'; // max_size in kb 
         $config['file_name'] = $_FILES['file']['name']; 

         // Load upload library 
          $this->load->library('upload', $config);
   
         // File upload
         if($this->upload->do_upload('file')){ 
            // Get data about the file
            $uploadData = $this->upload->data();
		    $configer =  array(
              'image_library'   => 'gd2',
              'source_image'    =>  $uploadData['full_path'],
              'maintain_ratio'  =>  FALSE,
              'width'           =>  1200,
              'height'          =>  631,
            );
            $this->image_lib->clear();
            $this->image_lib->initialize($configer);
            $this->image_lib->resize();
            $filename = $uploadData['file_name']; 
        
            $destination=$config['upload_path'].pathinfo($filename, PATHINFO_FILENAME).".webp";
            $source=$config['upload_path'].$filename;
                 
        	$extension = pathinfo($source, PATHINFO_EXTENSION);
        	if ($extension == 'jpeg' || $extension == 'jpg') 
        		$image = imagecreatefromjpeg($source);
        	elseif ($extension == 'gif') 
        		$image = imagecreatefromgif($source);
        	elseif ($extension == 'png') 
        		$image = imagecreatefrompng($source);
        	imagewebp($image, $destination, 80);
		 
			$userdata['featured_image']=pathinfo($filename, PATHINFO_FILENAME).".webp";
			
			}
		}
			
		}
		
		if($type=='breaking'){
			
			$userdata=array(
				'message'=>$this->input->post('breaking'),
				'time'=>date('c'),
				'status'=>'Active',
			);
			
		}
		
		if($type=='category'){
			
			$userdata=array(
				'name'=>$this->input->post('name'),
				'slug'=>$this->input->post('slug'),
				'description'=>$this->input->post('description'),
				'parent'=>$this->input->post('parent'),
				'status'=>'Active',
			);
			
			
		}
		
		if($type=='tag'){
			
			$userdata=array(
				'name'=>$this->input->post('name'),
				'slug'=>$this->input->post('slug'),
				'description'=>$this->input->post('description'),
			);
			
		}
		
		if($type=='settings'){
			
			$userdata=array(
				'url'=>$this->input->post('url'),
				'site_name'=>$this->input->post('site_name'),
				'logo'=>$this->input->post('logo'),
				'favicon'=>$this->input->post('favicon'),
				'meta_description'=>$this->input->post('meta_description'),
				'meta_keywords'=>$this->input->post('meta_keywords'),
				'social'=>$this->input->post('social'),
				'below_article'=>$this->input->post('below_article'),
				
				//'top_menu'=>$this->input->post('below_article_ad'),
				//'main_menu'=>$this->input->post('sidebar_ad'),
				//'footer_menu'=>$this->input->post('footer_ad'),
				//'entry_pass'=>$this->input->post('homepage_feed_ad'),
			);
			
		}
		
		if($type=='advertisement'){
			
			$userdata=array(
				'top_ad'=>$this->input->post('top_ad'),
				'in_article_ad'=>$this->input->post('in_article_ad'),
				'in_article_ad2'=>$this->input->post('in_article_ad2'),
				'in_article_ad3'=>$this->input->post('in_article_ad3'),
				'below_article_ad'=>$this->input->post('below_article_ad'),
				'sidebar_ad'=>$this->input->post('sidebar_ad'),
				'footer_ad'=>$this->input->post('footer_ad'),
				'homepage_feed_ad'=>$this->input->post('homepage_feed_ad'),
				'category_feed_ad'=>$this->input->post('category_feed_ad'),
				'homepage_sidebar_ad'=>$this->input->post('homepage_sidebar_ad'),
			);
			
		}
		
		if($type=='user'){
			
			$userdata=array(
				'name'=>$this->input->post('name'),
				
				'email'=>$this->input->post('email'),
                'role'=>$this->input->post('role'),
				'status'=>$this->input->post('status'),
				'date'=>date('c'),
			);
			
				if($this->input->post('password')!=""){
				    
				    $userdata['password']=md5($this->input->post('password'));
				}
			
		}
		
		if($type=="page"){
			$type_id='pid';
		}
		elseif($type=="post"){
			$type_id='aid';
		}
		elseif($type=="category"){
			$type_id='cid';
		}
		elseif($type=="tag"){
			$type_id='tid';
		}
		elseif($type=="user"){
			$type_id='uid';
		}
		elseif($type=="menu"){
			$type_id='mid';
		}else{
		    $type_id='id';
		}
		
		if($type=='menu'){
			
			$userdata=array(
				'name'=>$this->input->post('name'),
				'item'=>$this->input->post('item'),
				'location'=>implode(",",$this->input->post('location')),
				'status'=>'Active',
			);
			
			foreach($this->input->post('location') as $menu_location){
				
				$setting_data[$menu_location]=$id;
				
			}
		
			
			$this->db->where('id','1');
			$this->db->update('settings',$setting_data);
		}
		
		
		
		
		$this->db->where($type_id,$id);
		$this->db->update($type,$userdata);
		
		
		
		
		$result=array(
			'status'=>TRUE,
		);
		
		return $result;
		
		
		
		
	}
	
	function remove($type,$id){
		
		if($type=="page"){
			$type_id='pid';
		}
		elseif($type=="post"){
			$type_id='aid';
		}
		elseif($type=="breaking"){
			$type_id='bid';
		}
		elseif($type=="category"){
			$type_id='cid';
		}
		elseif($type=="tag"){
			$type_id='tid';
		}
		elseif($type=="user"){
			$type_id='uid';
		}
		elseif($type=="menu"){
			$type_id='mid';
		}
		
		$this->db->where($type_id,$id);
		$query=$this->db->delete($type);
		return true;
		
	}
	
	function lists($type){
		
		if($type=="page"){
			$type_id='pid';
		}
		elseif($type=="post"){
			$type_id='aid';
		}
		elseif($type=="breaking"){
			$type_id='bid';
		}
		elseif($type=="category"){
			$type_id='cid';
		}
		elseif($type=="tag"){
			$type_id='tid';
		}
		elseif($type=="user"){
			$type_id='uid';
		}
		elseif($type=="menu"){
			$type_id='mid';
		}else{
		    $type_id='id';
		}
		
		$this->db->order_by($type_id,'desc');
		$query=$this->db->get($type);
		return $query->result_array();
	}
	
	function get_list($type,$id){
		
		if($type=="page"){
			$type_id='pid';
		}
		elseif($type=="post"){
			$type_id='aid';
		}
		elseif($type=="category"){
			$type_id='cid';
		}
		elseif($type=="tag"){
			$type_id='tid';
		}
		elseif($type=="user"){
			$type_id='uid';
		}
		elseif($type=="menu"){
			$type_id='mid';
		}
		$this->db->where($type_id,$id);
		$query=$this->db->get($type);
		return $query->row_array();
	}
	
	function get_single($slug_enc,$type){
		$slug=rawurldecode($slug_enc);
		$this->db->where('slug',$slug);
		//$this->db->or_where('slug',$slug_enc);
		$query=$this->db->get($type);
		return $query->row_array();
	}
	
	function get_single_preview($aid){
		
		$this->db->where('aid',$aid);
		$query=$this->db->get('post');
		return $query->row_array();
	}
 
 
 //Function Categories 
	
	function get_category($cid){
		
		$this->db->where('cid',$cid);
		$query=$this->db->get('category');
		return $query->row_array();
	}

	
	function category_list($id,$showcat,$type='',$post_cat_id=''){
	    
	    $this->db->where('parent',$id);
	    $query=$this->db->get('category');
	    $results=$query->result_array();
	    
	    if($type=="option"){
	    foreach($results as $list){
	        
	        echo "<option value='".$list['cid']."'";
	        if(in_array($list['cid'],explode(',',$post_cat_id))){ echo 'selected'; }
	        echo ">".$showcat.$list['name']."</option>";
	        $this->category_list($list['cid'],$showcat."&nbsp;&nbsp;&nbsp;",$type,$post_cat_id);
	       
            }
            
             
	    }
	    
	        
	        
	        elseif($type=="table"){
	        foreach($results as $key=>$list){
			echo '<tr><td><input type="checkbox" name="select_'.$key.'"></td><td><div class="edit-menu">'.$showcat.$list['name'].'<p class="hide my-0"><span class="text-info">Edit</span><span class="px-2"> | </span><span class="text-danger"><a onclick="return confirm(\'Do you really want to delete?\');" href="'.site_url("admin/remove/category/".$list['cid']).'">Delete</a></span></p></div></td><td>'.$list['description'].'</td><td>'.$list['slug'].'</td><td>0</td></tr>';
	        $this->category_list($list['cid'],$showcat."--",$type,"");
	            
	        }
	    }
	}
	
	
	
	
	
	
 
 //Function Tags
 
	function insert_tag($tags){
		
		foreach($tags as $tag){
			
			$this->db->where('name',$tag);
			$query=$this->db->get('tag');
			$result=$query->row_array();
			
			if(!$result){
				$data['name']=$tag;
				$this->db->insert('tag',$data); 
			}
			
		}
			
	}
 
 function upload_img($width,$height){
	    
	    if($width > 1200 ){
            $width= 1200;
	    }
	    
	    if($height > 628 ){
            $height= 628;
	    }
	    
		 $this->load->library('image_lib');
		 
		  // Set preference 
         $config['upload_path'] = './images/'; 
         $config['allowed_types'] = 'jpg|jpeg|png|gif|webp'; 
         $config['max_size'] = '1000000'; // max_size in kb 
         $config['file_name'] = $_FILES['file']['name']; 

         // Load upload library 
          $this->load->library('upload', $config);
   
         // File upload
         if($this->upload->do_upload('file')){ 
            // Get data about the file
            $uploadData = $this->upload->data();
		    $configer =  array(
              'image_library'   => 'gd2',
              'source_image'    =>  $uploadData['full_path'],
              'maintain_ratio'  =>  FALSE,
              'width'           =>  $width,
              'height'          =>  $height,
            );
            $this->image_lib->clear();
            $this->image_lib->initialize($configer);
            $this->image_lib->resize();
            $filename = $uploadData['file_name']; 
        
            $destination=$config['upload_path'].pathinfo($filename, PATHINFO_FILENAME).".webp";
            $source=$config['upload_path'].$filename;
                 
        	$extension = pathinfo($source, PATHINFO_EXTENSION);
        	if ($extension == 'jpeg' || $extension == 'jpg') {
        		$image = imagecreatefromjpeg($source);}
        	elseif ($extension == 'gif') {
        		$image = imagecreatefromgif($source);}
        	elseif ($extension == 'png' || $extension == 'PNG' ) {
        		$image = imagecreatefrompng($source);}
        	imagewebp($image, $destination, 80);
		 
			return site_url("/images/".pathinfo($filename, PATHINFO_FILENAME).".webp");
			
		 }
	 
 }
 
 //POST FUNCTION 
 
 function insert_post(){
     $userdata=array(
         'publish_date'=>date('c'),
         'status'=>'Draft',
         );
    if($this->db->insert('post',$userdata)){
        $aid=$this->db->insert_id();

    return $aid;
    
 }
 
}


//MEDIA FUNCTION

function media_list(){
    $query=$this->db->get('media');
    return $query->result_array();
}
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
}

?>
