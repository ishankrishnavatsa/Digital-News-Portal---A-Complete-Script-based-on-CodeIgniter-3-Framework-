<?php
Class automatic_model extends CI_Model
{
    
    function insert(){
        
        $strip_tags=json_encode(array(
                'status'=>$this->input->post('strip_tag_status'),
                'allowed'=>$this->input->post('strip_tag_allowed'),
            ));
        
        
        $userdata=array(
			'campaign_name'=>$this->input->post('name'),
			'feed_url'=>$this->input->post('url'),
			'feed_type'=>$this->input->post('feed_type'),
			'post_status'=>$this->input->post('post_status'),
			'change_text'=>$this->input->post('change_text'),
			'strip_tag'=>$strip_tags,
			'category'=>implode(",",$this->input->post('category')),
			'tags'=>$this->input->post('tags'),
			'author'=>$this->input->post('author'),
			'date'=>date('c'),
			'status'=>$this->input->post('status'),
    
			);
			
			$this->db->insert('automatic',$userdata);
            $insert_id=$this->db->insert_id();
        $result=array(
			'id'=>$insert_id,
			'status'=>TRUE,
		);
		
		return $result;
    }
    function update($id){
        
        $strip_tags=json_encode(array(
                'status'=>$this->input->post('strip_tag_status'),
                'allowed'=>$this->input->post('strip_tag_allowed'),
            ));
        
        
        $userdata=array(
			'campaign_name'=>$this->input->post('name'),
			'feed_url'=>$this->input->post('url'),
			'feed_type'=>$this->input->post('feed_type'),
			'post_status'=>$this->input->post('post_status'),
			'change_text'=>$this->input->post('change_text'),
			'strip_tag'=>$strip_tags,
			'category'=>implode(",",$this->input->post('category')),
			'tags'=>$this->input->post('tags'),
			'author'=>$this->input->post('author'),
			'date'=>date('c'),
			'status'=>$this->input->post('status'),
    
			);
			
			$this->db->where('id',$id);
			$this->db->update('automatic',$userdata);
            
        $result=array(
			'id'=>$id,
			'status'=>TRUE,
		);
		
		return $result;
    }
    
    
    function get_campaign($id){
        
        $this->db->where('id',$id);
        $this->db->where('status','Active');
        $query=$this->db->get('automatic');
        
        return $query->row_array();
        
        
    }

    function get_automatic_post($url){
        
        $this->db->where('post_url',$url);
        $query=$this->db->get('automatic_post');
        
        if($query->num_rows()>0){
            
            return true;
        }
        
        else{
            
            return false;
        }
        
        
    }
    
    function insert_posts($title,$slug,$content,$status,$date,$cid,$tags,$author,$copyright){
        
        	$userdata=array(
			'title'=>$title,
			'slug'=>$slug,
			'content'=>$content,
			'status'=>$status,
			'publish_date'=>$date,
			'modified_date'=>date('c'),
			'cid'=>$cid,
			'tags'=>$tags,
			'author'=>$author,
			'post_format'=>'Standard',
			'copyright'=>$copyright,
			'news_source'=>$copyright,
			);
			
			if($this->db->insert('post',$userdata)){
			    $id=$this->db->insert_id();
                 $result=array(
                        'status'=>TRUE,
                        'id'=>$id,
                     );
                 
                 return $result;
			}else{
			    $result=array(
                        'status'=>FALSE,
                        'id'=>"",
                     );
                 
                 return $result;
			}
        
    }
    
    
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
}

?>
