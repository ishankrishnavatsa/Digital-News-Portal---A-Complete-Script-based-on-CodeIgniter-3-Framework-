<?php
Class login_model extends CI_Model
{

 
 function authenticate(){
	 
	 $username=$this->input->post('username');
	 $password=md5($this->input->post('password'));
	 
	 $this->db->where("(username='$username' OR email='$username')");
	 $this->db->where('password',$password);
	 $query=$this->db->get('user');
	 
	 $user=$query->row_array();
	 if($user!=''){
		 
		 $data=array(
				'status'=>'success',
				'user'=>$user,
		 );
		 
		 }else{
			 
			 $data=array(
				'status'=>'failed',
				);			 
		 }
		 
		 return $data;
 }
 
	function add_user(){
		
		$this->load->library('image_lib');
		
	
	     
		 
         // Set preference 
         $config['upload_path'] = './images/'; 
         $config['allowed_types'] = 'jpg|jpeg|png|gif|webp'; 
         $config['max_size'] = '1000000'; // max_size in kb 
         $config['file_name'] = $_FILES['file']['name']; 

         // Load upload library 
          $this->load->library('upload', $config);
   
         
				
			$userdata=array(
			'name'=>$this->input->post('name'),
			'username'=>$this->input->post('username'),
			'email'=>$this->input->post('email'),
			'mobile'=>$this->input->post('mobile'),
			'password'=>md5($this->input->post('password')),
			'whatsapp'=>$this->input->post('whatsapp'),
			'telegram'=>$this->input->post('telegram'),
			'role'=>$this->input->post('role'),
			'status'=>"Active",
			
			);
			if($_FILES['file']['name']){
				// File upload
				 if($this->upload->do_upload('file')){
					// Get data about the file
					$uploadData = $this->upload->data();
					$configer =  array(
					  'image_library'   => 'gd2',
					  'source_image'    =>  $uploadData['full_path'],
					  'maintain_ratio'  =>  FALSE,
					  'width'           =>  250,
					  'height'          =>  250,
					);
					$this->image_lib->clear();
					$this->image_lib->initialize($configer);
					$this->image_lib->resize();
					$filename = $uploadData['file_name']; 
				
					$destination=$config['upload_path'].pathinfo($filename, PATHINFO_FILENAME).".webp";
					$source=$config['upload_path'].$filename;
						 
					$extension = pathinfo($source, PATHINFO_EXTENSION);
					if ($extension == 'jpeg' || $extension == 'jpg') 
						$image = imagecreatefromjpeg($source);
					elseif ($extension == 'gif') 
						$image = imagecreatefromgif($source);
					elseif ($extension == 'png') 
						$image = imagecreatefrompng($source);
					imagewebp($image, $destination, 80);
				 
					$userdata['photo']=pathinfo($filename, PATHINFO_FILENAME).".webp";
					} 
					else{
						return array(
						'status'=>'failed',
						'msg'=>'Can Not Upload Photo',
						);
						exit;
					}
				}
			
			if($this->input->post('hid')!=NULL){$userdata['hid']=$this->input->post('hid');}
			
			if($this->db->insert('user',$userdata)){
				return array(
				'status'=>'success',
				'msg'=>'User Added Successfully',
			 );
			}else{
				
				return array(
				'status'=>'failed',
				'msg'=>'Unable to Add User',
			 );
			}
			
		 
		 
		 
		
		
		
	}
	
	function edit_user($uid){
		
		
		$this->load->library('image_lib');
		

         // Set preference 
         $config['upload_path'] = './images/'; 
         $config['allowed_types'] = 'jpg|jpeg|png|gif|webp'; 
         $config['max_size'] = '1000000'; // max_size in kb 
         $config['file_name'] = $_FILES['file']['name']; 

         // Load upload library 
          $this->load->library('upload', $config);
   
 	
			$userdata=array(
			'name'=>$this->input->post('name'),
			'email'=>$this->input->post('email'),
			'mobile'=>$this->input->post('mobile'),
			'whatsapp'=>$this->input->post('whatsapp'),
			'telegram'=>$this->input->post('telegram'),
			
			);
			if($_FILES['file']['name']){
				// File upload
				 if($this->upload->do_upload('file')){
					// Get data about the file
					$uploadData = $this->upload->data();
					$configer =  array(
					  'image_library'   => 'gd2',
					  'source_image'    =>  $uploadData['full_path'],
					  'maintain_ratio'  =>  FALSE,
					  'width'           =>  250,
					  'height'          =>  250,
					);
					$this->image_lib->clear();
					$this->image_lib->initialize($configer);
					$this->image_lib->resize();
					$filename = $uploadData['file_name']; 
				
					$destination=$config['upload_path'].pathinfo($filename, PATHINFO_FILENAME).".webp";
					$source=$config['upload_path'].$filename;
						 
					$extension = pathinfo($source, PATHINFO_EXTENSION);
					if ($extension == 'jpeg' || $extension == 'jpg') 
						$image = imagecreatefromjpeg($source);
					elseif ($extension == 'gif') 
						$image = imagecreatefromgif($source);
					elseif ($extension == 'png') 
						$image = imagecreatefrompng($source);
					imagewebp($image, $destination, 80);
				 
					$userdata['photo']=pathinfo($filename, PATHINFO_FILENAME).".webp";
					} 
					else{
						return array(
						'status'=>'failed',
						'msg'=>'Can Not Upload Photo',
						);
						exit;
					}
				}
				
			if($this->input->post('password')!=NULL){$userdata['password']=md5($this->input->post('password'));}
			if($this->input->post('hid')!=NULL){$userdata['hid']=$this->input->post('hid');}
			
			
			
			
			$this->db->where('uid',$uid);
			if($this->db->update('user',$userdata)){
				return array(
				'status'=>'success',
				'msg'=>'User Details Edited Successfully',
			 );
			}else{
				
				return array(
				'status'=>'failed',
				'msg'=>'Unable to Edit Details',
			 );
			}
			
		 
		 
		 
		
		
		
	}
		
	
	function username_check($username){
		
		$this->db->where('username',$username);
		$query=$this->db->get('user');
		
		if($query->row_array()==""){
			return true;
		}
		else{
			return false;
		}
		
	}
	
	function user_list(){
		
		$query=$this->db->get('user');
		return $query->result_array();
	}
	
	function get_user($uid){
		
		$this->db->where('uid',$uid);
		$query=$this->db->get('user');
		return $query->row_array();
	}
	 
	 
	 

















 

}

?>
