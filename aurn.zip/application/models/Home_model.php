<?php
Class home_model extends CI_Model
{

//SETTINGS

	function get_setting(){
		$this->db->where('id','1');
		$query=$this->db->get('settings');
		return $query->row_array();

	}

//MENUS

	function get_menu($id){
		$this->db->where('mid',$id);
		$query=$this->db->get('menu');
		return $query->row_array();

	}
	
	function menu_list(){
		$query=$this->db->get('menu');
		return $query->result_array();
		
	}
	
	
 //Home Page
	
	function get_breaking($limit){
		$this->db->where('status','Active');
		$this->db->limit($limit);
		$this->db->order_by('bid','desc');
		$query=$this->db->get('breaking');
		return $query->result_array();
		
	}
	
	function post_loop(){
		$this->db->where("DATE_FORMAT(publish_date, '%d-%m-%Y') <= 'date(\'d-m-Y\')'");
		//$this->db->where('publish_date <=',date('Y-m-d'));
		//$this->db->where('cid',$category);
		$this->db->where('status','Published');
		$this->db->order_by('aid', "desc");
		$query=$this->db->get('post');
		return $query->result_array();
		
		
	}
	
	function post_filter($type,$data=''){
		
		if($type=='category'){
			$filter_type="cid";
		
		}elseif($type=='tag'){
			$filter_type="tags";
		
		}elseif($type=='format'){
			$filter_type="post_format";
			
		}
		$this->db->where("DATE_FORMAT(publish_date, '%d-%m-%Y') <= 'date(\'d-m-Y\')'");
		//$this->db->where('publish_date <=',date('Y-m-d'));
		$this->db->where('status','Published');
		$this->db->where($filter_type,$data);
		$this->db->order_by('aid', "desc");
		$query=$this->db->get('post');
		return $query->result_array();
		
		
	}
	
	function get_single($slug_enc,$type){
		$slug=rawurldecode($slug_enc);
		$this->db->where('slug',$slug);
		//$this->db->or_where('slug',$slug_enc);
		$query=$this->db->get($type);
		return $query->row_array();
	}
	
	function ad(){
	    $query=$this->db->get('advertisement');
	    return $query->row_array();
	    
	}
	
	function get_related($cat){
	    
	    $cat_arr=explode(",",$cat);
	    
	    $this->db->where('status','Published');
	    $this->db->where_in('cid',$cat_arr);
	    $this->db->order_by('publish_date', "desc");
		$query=$this->db->get('post');
		return $query->result_array();
	   
	}
	
	function get_category($cat){
	    $this->db->where("DATE_FORMAT(publish_date, '%d-%m-%Y') <= 'date(\'d-m-Y\')'");
	  //$this->db->where('publish_date <=',date('Y-m-d'));
            $this->db->where('status','Published');
	    $this->db->where("find_in_set('".$cat."',cid) >",0);
	    //$this->db->or_where('cid',$cat);
	    $this->db->order_by('aid', "desc");
	    $query=$this->db->get('post');
	    return $query->result_array();
	    
	}
	
	function read_also($tags){
	    
	    $tag_arr=explode(",",$tags);
	    
	    $this->db->select('title');
	    $this->db->select('slug');
	    $this->db->where('status','Published');
	    $this->db->where("find_in_set('".$tag_arr[0]."',tags) >",0);
	    //foreach($tag_arr as $key=>$tag){ 
	      //     $this->db->or_where("find_in_set('".$tag."',tags) >",0);
	        //}
	    
	    $this->db->offset(1);
	    $this->db->limit(4);
	    $this->db->order_by('publish_date', "desc");
		$query=$this->db->get('post');
		return $query->result_array();
	    
	}
 

    function get_tag($tag){
        
        $this->db->where("DATE_FORMAT(publish_date, '%d-%m-%Y') <= 'date(\'d-m-Y\')'");
        $this->db->where("find_in_set('".$tag."',tags) >",0);
        $this->db->where('status','Published');
	    $this->db->order_by('aid', "desc");
	    $query=$this->db->get('post');
	    return $query->result_array();
	    
    }
    
    function tag_slug($tag){
        $this->db->where('name',$tag);
	    $query=$this->db->get('tag');
	    return $query->row_array();
    }
    
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
}

?>
