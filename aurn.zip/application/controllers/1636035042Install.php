<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Install extends CI_Controller {

	 function __construct()
	 {
	   parent::__construct();

	 }

	public function index()
	{		
		$data['title']="Tankaar Press Installation";
		$this->load->view('install/installation',$data);
	}
	
	 function config_tp(){
				 
		 // run sql file
			$hostname=$this->input->post('hostname');
			$database=$this->input->post('database');
			$username=$this->input->post('username');
			$password=$this->input->post('password');
			$adminemail=$this->input->post('admin_email');
			$adminusername=$this->input->post('admin_username');
			$adminpassword=$this->input->post('admin_password');
			$sitename=$this->input->post('sitename');
			$base_url=$this->input->post('base_url');
			$entry_pass=$this->input->post('entry_pass');
			
			$link = mysqli_connect($hostname, $username, $password, $database);

			/* check connection */
			if (mysqli_connect_errno()){
				printf("Connect failed: %s\n", mysqli_connect_error());
				exit();
			}else{
				if($this->input->post('force_write')){
					if(chmod("./application/config/tankaarpress_config.php",0777)){ } 	
				}
			 
				$file="./application/config/tankaarpress_config.php";
				$default_controller='hi';
				
				$content="<?php 
				$"."base_url='".$this->input->post('base_url')."';
				$"."hostname='".$this->input->post('hostname')."';
				$"."database='".$this->input->post('database')."';
				$"."username='".$this->input->post('username')."';
				$"."password='".$this->input->post('password')."';
				$"."db_prefix='".$this->input->post('db_prefix')."';
				$"."default_controller='".$default_controller."';
				?>";
				 
				 file_put_contents($file,$content);
				 
				if($this->input->post('force_write')){
					if(chmod("./application/config/tankaarpress_config.php",0644)){ } 	
				}
			}
			
			$query=file_get_contents("db.sql");
			sleep(5);
			if(mysqli_multi_query($link, $query)){
				sleep(15);
				$this->load->database();
			
				$userdata=array(
							'username'=>$adminusername,
							'email'=>$adminemail,
							'password'=>md5($adminpassword),
							'name'=>'Admin',
							);
				$this->db->where('uid','1');
				$this->db->update('user',$userdata);
				
				$settingdata=array(
							'url'=>$base_url,
							'entry_pass'=>$entry_pass,
							'site_name'=>$sitename,
							);
				$this->db->where('id','1');
				$this->db->update('settings',$settingdata);
				
				}
								 
			$data['title']="Success";
			$data['username']=$adminusername;
			$data['password']=$adminpassword;
			$data['entry_pass']=$entry_pass;
			$data['url']=$base_url;
			
			$this->load->view('install/success',$data);
		
			
			//if(chmod("./upload/",0777)){ } 
			//if(chmod("./xls/",0777)){ } 
			//if(chmod("./photo/",0777)){ }  
			rename("./application/controllers/Install.php","./application/controllers/".time()."Install.php");
			
	 }
	 
	 
	 
	
}