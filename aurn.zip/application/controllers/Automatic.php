<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Automatic extends CI_Controller {
	
	 function __construct()
	 {
	   parent::__construct();
	   $this->load->database();
	    $this->load->model('automatic_model');
	    $this->load->library('feed_reader');
	   $this->load->library('slugify');
	 }
	
	
	function index(){
		
		$logged_in=$this->session->userdata('logged_in');
		if($logged_in && ($logged_in['role']=='Admin')){
		
		$data['users']=$this->main_model->lists('user');   
		$data['title']="Campaign";
		
		$this->load->view('backend/header',$data);
		$this->load->view('automatic/new_campaign',$data);
		$this->load->view('backend/footer',$data);
		
		    
		}else{
			
			redirect(site_url());
		}
		
	}
	
	function edit($id){
	    
	    $logged_in=$this->session->userdata('logged_in');
		if($logged_in && ($logged_in['role']=='Admin')){
		$this->db->where('id',$id);
		$query=$this->db->get('automatic');
		$data['campaign']=$query->row_array();
		
		$data['users']=$this->main_model->lists('user');   
		$data['title']="Edit Campaign";
		
		$this->load->view('backend/header',$data);
		$this->load->view('automatic/edit_campaign',$data);
		$this->load->view('backend/footer',$data);
		
		    
		}else{
			
			redirect(site_url());
		}
		
	}
	
	function list(){
	    $logged_in=$this->session->userdata('logged_in');
		if($logged_in && ($logged_in['role']=='Admin')){
	    
	    $query=$this->db->get('automatic');
	    $results=$query->result_array();
	    
	        foreach($results as $key=>$list){
			echo '<tr><td><input type="checkbox" name="select_'.$key.'"></td><td><span onclick="runCampaign('.$list['id'].');"><i class="far fa-2x fa-play-circle"></i></span></td><td><div class="edit-menu"><b>'.$list['campaign_name'].'</b><p class="hide my-0"><span class="text-info"><a href="'.site_url("automatic/edit/".$list['id']).'">Edit</a></span><span class="px-2"> | </span><span class="text-danger"><a onclick="return confirm(\'Do you really want to delete?\');" href="'.site_url("automatic/remove/".$list['id']).'">Delete</a></span></p></div></td><td>'.$list['feed_url'].'</td><td>'.$list['date'].'</td><td>'.$list['status'].'</td></tr>';
	       
	    }
	    
		}else{
			
			redirect(site_url());
		}
	}
	
	function insert(){
	    $logged_in=$this->session->userdata('logged_in');
		if($logged_in && ($logged_in['role']=='Admin')){
	    
	    $result=$this->automatic_model->insert();
		
		if($result['status']){
			//$this->session->set_flashdata('toastr',array('msg'=>'Campaign added successfully','type'=>'success'));
			echo "Success";
			//redirect(site_url('automatic'));
		}else {
		    //$this->session->set_flashdata('toastr',array('msg'=>'Unable to add Campaign','type'=>'danger'));
			//redirect(site_url('automatic'));
			echo "Failed";
		}
	    
		}else{
			
			redirect(site_url());
		}
	}
	
	function remove($id){
	    $logged_in=$this->session->userdata('logged_in');
		if($logged_in && ($logged_in['role']=='Admin')){
		    
		    $this->db->where('id',$id);
		    $this->db->delete('automatic');
		    
		    $this->session->set_flashdata('toastr',array('msg'=>'Campaign deleted successfully','type'=>'success'));
		    redirect(site_url('automatic'));
		    
		    
		}else{
			
			redirect(site_url());
		}	    
	}

    function update($id){
	    $logged_in=$this->session->userdata('logged_in');
		if($logged_in && ($logged_in['role']=='Admin')){
	    
	    $result=$this->automatic_model->update($id);
		
		if($result['status']){
			//$this->session->set_flashdata('toastr',array('msg'=>'Campaign added successfully','type'=>'success'));
			echo "Success";
			//redirect(site_url('automatic'));
		}else {
		    //$this->session->set_flashdata('toastr',array('msg'=>'Unable to add Campaign','type'=>'danger'));
			//redirect(site_url('automatic'));
			echo "Failed";
		}
	    
		}else{
			
			redirect(site_url());
		}
	}


    function feeds($campaign_id){
            
            $campaign=$this->automatic_model->get_campaign($campaign_id);
            if($campaign){
            
            $status=$campaign['post_status'];
            $cid=$campaign['category'];
            $tags=$campaign['tags'];
            $author=$campaign['author'];
            $replace=explode(",",$campaign['change_text']);
            
            $feed_url=$campaign['feed_url'];
            $feed_data=$this->feed_reader->feed_data($feed_url);
           
           echo $feed_data;
            $copyright=$feed_data->channel->title;
            
            foreach($feed_data->channel->item as $item){
                   
                   if(json_decode($campaign['strip_tag'],TRUE)['status']==1){
                       $feed_content=strip_tags($item->children("content", true)->encoded, json_decode($campaign['strip_tag'],TRUE)['allowed']);
                   }else{
                       $feed_content=$item->children("content", true)->encoded;
                   }
                   
                   
                   
                   $title = $item->title;
                   $slug=$this->feed_reader->slug($title);
                   //$slug=strtolower(preg_replace('/[^A-Za-z0-9-]+/', '-', $title));
                   $link = $item->link;
                   $content = str_replace($replace,"",$item->children("content", true)->encoded);
                   $postDate = $item->pubDate;
                   $date = date('c',strtotime($postDate));
                   
                   
            
            if(!$this->automatic_model->get_automatic_post($link)){
                
                $userdata=array(
                    'post_url'=>$link,
                    'date'=>date('c'),
                    'campaign_id'=>$campaign['id'],
                    );
               
                $this->db->insert('automatic_post',$userdata);
                if($content!=""){
                    $result= $this->automatic_model->insert_posts($title,$slug,$content,$status,$date,$cid,$tags,$author,$copyright);
                    if($result['status']){
                        echo "Success! New Post ID: ".$result['id']." Added!<br>";
                    }else{
                        "Error to Add New Post! Kindly Contact Administrator! <br>";
                    }
                    
                }else{
                    echo "Empty Content! Can not insert post!<br>";
                }
            }else{
                
                echo "This Post in the feed is already Added! <br>";
            }
            
         } 
        
       }else{
           
           echo "Feed is not active or deleted";
       }
    
    }
    
    
    





















}
