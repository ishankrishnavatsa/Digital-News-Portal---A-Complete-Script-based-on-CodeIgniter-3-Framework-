<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Hi extends CI_Controller {
	
	var $data = array();
	 function __construct()
	 {
	   parent::__construct();
	   if($this->config->item('base_url')==''){
		redirect(current_url('install'));
		}else{
		
		   $this->load->database();
		   $this->data['settings']=$settings=$this->home_model->get_setting();
		   $this->data['favicon']=$settings['favicon'];
		   $this->data['main_menus']=json_decode($this->home_model->get_menu($settings['main_menu'])['item'],TRUE);
		   $this->data['top_menus']=json_decode($this->home_model->get_menu($settings['top_menu'])['item'],TRUE);
		   $this->data['mobile_menus']=json_decode($this->home_model->get_menu($settings['mobile_menu'])['item'],TRUE);
		   $this->data['footer_menus']=json_decode($this->home_model->get_menu($settings['footer_menu'])['item'],TRUE);
		   $this->data['latest']=$this->home_model->post_loop();
		   $this->data['ad']=$this->home_model->ad();
		}
	 }
	
	public function index()
	{	
		$data = $this->data;
		$data['title']="Welcome to ".$data['settings']['site_name'];
		$data['meta_description']=$data['settings']['meta_description'];
		$data['meta_keywords']=$data['settings']['meta_keywords'];
		
		
		$data['breakings']=$this->home_model->get_breaking(10);
		$loops=$this->home_model->post_loop();
		foreach ($loops as $loop){
		    if(date('Y-m-d',strtotime($loop['publish_date']))<=date('Y-m-d')){
		        $data['loops'][]=$loop;
		    }
		    
		}
		$data['aurangabad']=$this->home_model->post_filter('category',3);
		$data['bihar']=$this->home_model->post_filter('category',2);
		$data['bignews']=$this->home_model->post_filter('category',1);
		$data['videos']=$this->home_model->post_filter('format','Video');
		$data['viral']=$this->home_model->post_filter('category',13);
		
		$this->load->view('frontend/header',$data);
		$this->load->view('frontend/home',$data);
		$this->load->view('frontend/footer',$data);

	}
	
	public function category($slug='')
	{	
		$data = $this->data;
		
		$data['category']=$this->home_model->get_single($slug,'category');
		
		
		if($data['category'] && $slug!=""){
		
		$data['title']=$data['category']['name']." News in Hindi, ".$data['category']['name']." latest news updates - ".$data['settings']['site_name'];
		 $loops=$this->home_model->get_category($data['category']['cid']);
		foreach ($loops as $loop){
		    if(date('Y-m-d',strtotime($loop['publish_date']))<=date('Y-m-d')){
		       $data['post_loops'][]=$loop;
		    }
		    
		}   
		
		$data['breadcrumbs']['category']=$this->main_model->get_single($slug,'category');
		$data['breadcrumbs']['parent']=$this->main_model->get_category($data['breadcrumbs']['category']['parent']);
		
		$this->load->view('frontend/header',$data);
		$this->load->view('frontend/category',$data);
		$this->load->view('frontend/footer',$data);

	    }else{
		    
		   redirect(site_url('hi/not_found'));
		}
	}
	
	public function page($slug='')
	{	
	    
	    
	    $data = $this->data;
	    $data['page']=$this->main_model->get_single($slug,'page');
	    
	    if($data['page'] && $slug!=""){
	    $data['breadcrumbs']['page']=array('name'=>$data['page']['title'],
	                                        'slug'=>$data['page']['slug'],
	                                    );
		
		$data['title']=$data['page']['title']."-".$data['settings']['site_name'];
		
		$this->load->view('frontend/header',$data);
		$this->load->view('frontend/page',$data);
		$this->load->view('frontend/footer',$data);

	    }else{
		    
		   redirect(site_url('hi/not_found'));
		}
	}
	
	public function post($slug='')
	{	
		$data = $this->data;
		$data['single_post']=$this->main_model->get_single($slug,'post');
		
		if($data['single_post'] && $slug!="" && $data['single_post']['status']=="Published" && $data['single_post']['publish_date']<=date('c')){
		
		$data['author']=$this->main_model->get_list('user',$data['single_post']['author']);
		$data['title']=$data['single_post']['title'];
		$data['related']=$this->home_model->get_related($data['single_post']['cid']);
		$data['breadcrumbs']['category']=$this->main_model->get_category($data['single_post']['cid']);
		$data['breadcrumbs']['parent']=$this->main_model->get_category($data['breadcrumbs']['category']['parent']);
		$data['read_also']=$this->home_model->read_also($data['single_post']['tags']);
		if($data['single_post']['meta_description']!=''){
            $data['meta_description']=$data['single_post']['meta_description']; 
		}
		if($data['single_post']['meta_keywords']!=''){
            $data['meta_keywords']=$data['single_post']['meta_keywords']; 
		}
		if($data['single_post']['site_title']!=''){
            $data['title']=$data['single_post']['site_title']; 
		}
		
		
		
		$this->load->view('frontend/header',$data);
		$this->load->view('frontend/post',$data);
		$this->load->view('frontend/footer',$data);
		
		}else{
		    
		   redirect(site_url('hi/not_found'));
		}

	}
	
	public function tag($slug='')
	{	
	    
	    if($slug!=""){
	        
		$data = $this->data;
		
		$data['tag']=$this->home_model->get_single($slug,'tag');
		$data['breadcrumbs']['tag']=$this->main_model->get_single($slug,'tag');
		
		$data['title']=$data['tag']['name']." -News in Hindi, ".$data['tag']['name']." latest news - ".$data['settings']['site_name'];
		
		$loops=$this->home_model->get_tag($data['tag']['name']);
		foreach ($loops as $loop){
		    if(date('Y-m-d',strtotime($loop['publish_date']))<=date('Y-m-d')){
		       $data['post_loops'][]=$loop;
		    }
		    
		}   
		$this->load->view('frontend/header',$data);
		$this->load->view('frontend/tag',$data);
		$this->load->view('frontend/footer',$data);


	   }else{
		    
		   redirect(site_url('hi/not_found'));
		}
	}
	
	function breaking(){
		
		$breakings=$this->main_model->lists('breaking');
		
	?>
		
		<table class="table table-striped">
			<tr>
				<th>
					<input type="checkbox" name="select_all">
				</th>
				<th>
					Title
				</th>
				<th>
					Date
				</th>
			</tr>
	<?php for($i=0;$i<20;$i++){ if(isset($breakings[$i])){ ?>
			<tr>
				<td>
					<input type="checkbox" name="select_<?php echo $i; ?>">
				</td>
				<td>
					<div  class="edit-menu "><?php echo $breakings[$i]['message']; ?>
						<p class="hide my-0">
							<span class="text-info">Edit</span><span class="px-2"> | </span><span class="text-danger">Delete</span>
						</p>
					</div>
				</td>
				<td>
					<?php echo date('M d, Y g:i A', strtotime($breakings[$i]['time'])); ?>
				</td>
			</tr>
	<?php }} ?>
		</table>

	
	<?php
		
	}
	
	function live_updates($type=''){
		
		$breakings=$this->main_model->lists('breaking');
		
		if($type=='widget'){
		
		for($i=0;$i<5;$i++){ if(isset($breakings[$i])){ if(date('d M Y', strtotime($breakings[$i]['time']))==date('d M Y')){ ?>
			<div class="m-3 border rounded bg-light">
				<p class="my-0 p-2 text-black"><b><?php echo date('g:i A', strtotime($breakings[$i]['time'])); ?></b></p>
				<p class="my-0 p-2">
					<?php echo $breakings[$i]['message']; ?>
				</p>
			</div>
		<?php }} }
		
		}elseif($type=='page'){ ?>
		    
			 <div class="row py-4 border-bottom">
			    <div class="col-12 my-auto">
			         <h2 style="font-size:1.5em"><b><?php echo $breakings[0]['message']; ?></b></h2>
				</div>
			</div>
			<?php for($i=1; $i<count($breakings)+1;$i++){ if(isset($breakings[$i])){ if(date('d M Y', strtotime($breakings[$i]['time']))==date('d M Y')){ ?>
			<div class="row py-4 border-bottom">
			    
			    <div class="col-md-auto col-12 my-auto">
			        <b><?php echo date('g:i A', strtotime($breakings[$i]['time'])); ?></b>
			    </div>
				<div class="col-md-9 my-auto col-12 my-auto">
		            <h3 class="my-auto " style="font-size:1em"><b><?php echo $breakings[$i]['message']; ?></b></h3>
				</div>
				<div class="col-md-auto col-12 text-info my-auto justify-content-center">
				    <span class="mx-2 px-2"><a target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=<?php echo site_url('hi/breakingnews');?>" title="Share to Facebook"><i class="fab fa-facebook-f"></a></span></i><span class="mx-2 px-2"><a target="_blank" href="https://www.twitter.com/intent/tweet?text=<?php echo rawurlencode(site_url('hi/breakingnews'));?>" title="Share to Twitter"><i class="fab fa-twitter"></i></a></span>
				</div>
			</div>
		    <?php }} }
		    
		}
		
	}
	
	function breakingnews(){
	    
	    $data = $this->data;
		$data['title']="अब एक क्लिक में पढ़ें ".date('d M')." की अहम खबरें  - Toady Breaking news in Hindi-".$data['settings']['site_name'];
		
		$this->load->view('frontend/header',$data);
		$this->load->view('frontend/breaking',$data);
		$this->load->view('frontend/footer',$data);
	    
	    
	}
	
	
	
	function not_found(){
	    
	    $data = $this->data;
	    $data['title']="404 - Not Found";
	    $this->output->set_status_header('404');
	    $this->load->view('frontend/header',$data);
		$this->load->view('404',$data);
		$this->load->view('frontend/footer',$data);
	    
	}
	
	
	

























}
