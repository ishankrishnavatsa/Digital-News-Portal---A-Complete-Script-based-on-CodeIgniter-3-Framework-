<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {
	 function __construct()
	 {
	   parent::__construct();
	   $this->load->database();
	   $this->load->model("login_model");
	 }
	
	public function admin($entry_pass=NULL)
	{	
	    
	    $logged_in=$this->session->userdata('logged_in');
	    if($logged_in){
	        redirect(site_url('admin'));
	    }else{
		$data['settings']=$this->home_model->get_setting();
		if(rawurldecode($entry_pass)==$data['settings']['entry_pass']){
		
		$data['title']="Login";
		
		$this->load->view('frontend/login/login',$data);
		
		}
		else{
			
			redirect (site_url());
			
		}
		
	 }
		
	}
	
	function authenticate(){
		
		$settings=$this->home_model->get_setting();
		
		if($this->input->post('username')!="" && $this->input->post('password')!=""){
			
			if($this->login_model->authenticate()['status']=="success"){
				
				$this->session->set_userdata('logged_in',$this->login_model->authenticate()['user']); //Starting Session
				
				$this->session->set_flashdata('toastr',array('msg'=>'Login Success','type'=>'success')); //Sending Toastr
				
					if($this->login_model->authenticate()['user']['role']=="Admin" || $this->login_model->authenticate()['user']['role']=="Author"){ 
						redirect(site_url('admin'));
					}else{
						redirect(site_url());
					}
					
				}else{
				
				$this->session->set_flashdata('toastr',array('msg'=>'Username and Password do not match','type'=>'danger')); 
				redirect(site_url('login/admin/'.$settings['entry_pass']));
			}
			
			
		}else{
			
			$this->session->set_flashdata('toastr',array('msg'=>'Username and Password can  not be empty','type'=>'info')); 
			redirect(site_url('login/admin/'.$settings['entry_pass']));
			
		}
		
	}
	
	function logout(){
		
		$this->session->unset_userdata('logged_in');
		$this->session->set_flashdata('toastr',array('msg'=>'Logged out successful','type'=>'success')); 
		redirect(site_url());
		
	}
	
	
	function forget($uid){
		
	}
	
	function settings($uid){
		
					//Password Change Feature Here
	}
	
	
	function username_check(){
		
		$username=$this->input->post('username');
		if($this->login_model->username_check($username)){
			echo "<span class='text-success'><b><i class='fas fa-check'></i> Username Available</b></span>";
			
		}
		else{
			echo "<span class='text-danger'><b><i class='fas fa-times'></i> Username Not Available</b></span>";
		}
		
	}
	
	

	



















}
