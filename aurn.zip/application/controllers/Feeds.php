<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Feeds extends CI_Controller {
	
	var $data = array();
	 function __construct()
	 {
	   parent::__construct();
	   $this->load->database();
	   
	   $this->data['settings']=$settings=$this->home_model->get_setting();
	  
	 }
	public function index($category=0)
	{	
	    if($category==0){
		$data = $this->data;
	    $data['encoding'] = 'utf-8';    
        $data['feed_name'] = $data['settings']['site_name'];        
        $data['feed_url'] = base_url('feeds');        
        $data['page_description'] = $data['settings']['meta_description']; 
        $data['page_language'] = 'en-US';    
        $data['feed_logo']=base_url('images/favicon.png');
        //$data['creator_email'] = 'yashwantchavan@gmail.com';        
        $query = $this->home_model->post_loop();
    
        if ($query) {           
            $data['posts'] = $query;           
        }  	
        header("Content-type: text/xml; charset=utf-8");
        $this->load->view('rss', $data);      
	    }
	    else{
	        
	    $data = $this->data;
	    $data['encoding'] = 'utf-8';    
        $data['feed_name'] = $data['settings']['site_name'];        
        $data['feed_url'] = base_url('feeds');        
        $data['page_description'] = $data['settings']['meta_description']; 
        $data['page_language'] = 'en-US';    
        $data['feed_logo']=base_url('images/favicon.png');
        //$data['creator_email'] = 'yashwantchavan@gmail.com';        
        $query = $this->home_model->post_filter('category',$category);
        if ($query) {           
            $data['posts'] = $query;           
        }  	
        header("Content-type: text/xml; charset=utf-8");
        $this->load->view('rss', $data); 
	        
	    }
	}


	public function sitemap(){
	    
	    $pages=$this->main_model->lists('page');
	    $posts=$this->home_model->post_loop();
	    $categories=$this->main_model->lists('category');
	    $tags=$this->main_model->lists('tag');
	    
	    
	    foreach($pages as $page){
            $data['pages'][]=site_url('hi/page/'.$page['slug']);
	    }
	    
	    foreach($posts as $post){
            $data['posts'][]=site_url('hi/post/'.rawurlencode($post['slug']));
            $data['lastmod'][]=$post['modified_date'];
            
	    }
	    
	    foreach($categories as $category){
            $data['categories'][]=site_url('hi/category/'.$category['slug']);
	    }
	    
	    foreach($tags as $tag){
            $data['tags'][]=site_url('hi/tag/'.rawurlencode($tag['slug']));
            
	    }
	    
	    
	   
	    header("Content-type: text/xml; charset=utf-8");  
	    $this->load->view('sitemap',$data);
	
	    
	}
	
	public function robots(){
	    header("Content-Type: text/plain");
        $this->load->view('robots');
	}
	

	
	
	

























}
