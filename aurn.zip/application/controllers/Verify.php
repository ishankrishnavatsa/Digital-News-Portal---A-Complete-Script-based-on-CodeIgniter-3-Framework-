<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Verify extends CI_Controller {
	 function __construct()
	 {
	   parent::__construct();
	   $this->load->database();
	   $this->load->model("login_model");
	 }
	
	public function index()
	{	
	    
	    
		
		$data['title']="Verify ID Card";
		
		$this->load->view('verify/verify',$data);
		
		
	 }
		
		
		
    function result(){
        
        $data['title']="Verification result";
		$this->db->where('id_number',$this->input->post('id_number'));
		$q=$this->db->get('verify');
		$data['verify']=$q->row_array();
		if(empty($data['verify'])){
		    $this->session->set_flashdata('toastr',array('msg'=>'Invalid ID Card Details','type'=>'error'));
		    redirect('verify');
		}else{
		    $this->load->view('verify/verify_result',$data);
		}
        
    }
	
	

	



















}
