<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {
	var $data = array();
	 function __construct()
	 {
	   parent::__construct();
	   $this->load->database();
	   
	   $logged_in=$this->session->userdata('logged_in');
	   if(!$logged_in || $logged_in['role']=='user'){
		   redirect(site_url());
	   }
	   
	       $this->data['medias']=$settings=$this->main_model->lists('media');
    	   $this->data['settings']=$settings=$this->home_model->get_setting();
    	   $this->data['favicon']=$settings['favicon'];
    	   $this->data['main_menus']=json_decode($this->home_model->get_menu($settings['main_menu'])['item'],TRUE);
    	   $this->data['top_menus']=json_decode($this->home_model->get_menu($settings['top_menu'])['item'],TRUE);
    	   $this->data['mobile_menus']=json_decode($this->home_model->get_menu($settings['mobile_menu'])['item'],TRUE);
    	   $this->data['footer_menus']=json_decode($this->home_model->get_menu($settings['footer_menu'])['item'],TRUE);
    	   $this->data['latest']=$this->home_model->post_loop();
    	   $this->data['ad']=$this->home_model->ad();
	 }
	
	
	
	function index(){
		
		$logged_in=$this->session->userdata('logged_in');
		if($logged_in && ($logged_in['role']=='Admin' || $logged_in['role']=='Author')){
		   
		$data['title']="Admin Dashboard";
		
		$this->load->view('backend/header',$data);
		$this->load->view('backend/index',$data);
		$this->load->view('backend/footer',$data);
		}else{
			
			redirect(site_url());
		}
		
	}
	
	function add($type='',$aid="")
	{	
		$logged_in=$this->session->userdata('logged_in');
		if($logged_in && ($logged_in['role']=='Admin' || $logged_in['role']=='Author')){
		
		$data = $this->data;
		$data['categories']=$this->main_model->lists('category');
		$data['tags']=$this->main_model->lists('tag');
		$data['menus']=$this->main_model->lists('menu');
		
		$data['title']="Add New ".$type;
		$this->load->view('backend/header',$data);
		if($type=="page"){
			
			$this->load->view('backend/add_new_page',$data);
		}
		elseif($type=="post"){
		    $result=$this->main_model->insert_post();
		    $data['aid']=$result;
		    
			$this->load->view('backend/add_new_post',$data);
		}
		elseif($type=="category"){
			$this->load->view('backend/category',$data);
		}
		elseif($type=="tag"){
			$this->load->view('backend/tag',$data);
		}
		elseif($type=="user"){
			$this->load->view('backend/user',$data);
		}
		elseif($type=="menu"){
			
			$this->load->view('backend/add_new_menu',$data);
		}
		else{
			echo "404";
		}
		$this->load->view('backend/footer',$data);
		
		}else{
			
			redirect(site_url());
		}

	}
	
	function insert($type='')
	{	
		
		$logged_in=$this->session->userdata('logged_in');
		if($logged_in && ($logged_in['role']=='Admin' || $logged_in['role']=='Author')){
			
		$result=$this->main_model->insert($type);
		
		if($result['status'] && ($type=="post" || $type=="menu" || $type=="page")){
			$this->session->set_flashdata('toastr',array('msg'=>$type.' published successfully','type'=>'success'));
			redirect(site_url('admin/edit/'.$type.'/'.$result['id']));
		}elseif($result['status'] && ($type=="breaking" || $type=="category" || $type=="tag" || $type="user")){
			
			echo "Success! Insert ID: ".$result['id'];
		}
		}else{
			
			redirect(site_url());
		}
	}
	
	function edit($type='',$id='')
	{	
		
		$logged_in=$this->session->userdata('logged_in');
		
		if($logged_in && $type!="user" && ($logged_in['role']=='Admin' || $logged_in['role']=='Author')){
		
		$data = $this->data;
		$data['categories']=$this->main_model->lists('category');
		$data['tags']=$this->main_model->lists('tag');
		$data['menus']=$this->main_model->lists('menu');
		
		$data[$type]=$this->main_model->get_list($type,$id);
		
		$data['title']="Edit ".$type;
		$this->load->view('backend/header',$data);
		$this->load->view('backend/edit_'.$type,$data);
		$this->load->view('backend/footer',$data);
		
		}elseif($logged_in && $type=="user" && ($logged_in['role']=='Admin' || $logged_in['uid']==$id)){
		  $data['user']=$this->main_model->get_list('user',$id);
		  
    		$data['title']="Edit User";
    		$this->load->view('backend/header',$data);
    		$this->load->view('backend/edit_user',$data);
    		$this->load->view('backend/footer',$data);
		}
		else{
			
			redirect(site_url());
		}
	}
	
	function update($type='',$id='')
	{	
	
		$logged_in=$this->session->userdata('logged_in');
		if($logged_in && ($logged_in['role']=='Admin' || $logged_in['role']=='Author')){
		
		
		$result=$this->main_model->update($type,$id);
		if($result['status']){
			$this->session->set_flashdata('toastr',array('msg'=>$type.' updated successfully','type'=>'success'));
			
			if($type=="user"){
			    echo "Success!";
			}else{
			    
			redirect(site_url('admin/edit/'.$type.'/'.$id));
			}
		}
		}else{
			
			redirect(site_url());
		}
	}
	
	function remove($type='',$id='')
	{	
		$logged_in=$this->session->userdata('logged_in');
		if($logged_in && ($logged_in['role']=='Admin' || $logged_in['role']=='Author')){
		
		$result=$this->main_model->remove($type,$id);
		
		if($result){
			$this->session->set_flashdata('toastr',array('msg'=>$type.' removed successfully','type'=>'success'));
			if($type=="category" || $type=="tag" || $type=="user"){
			    redirect(site_url('admin/add/'.$type));
			}elseif($type=="page" || $type=="post"){
			    redirect(site_url('admin/'.$type));
			}
			else{
			    redirect(site_url('admin'));
			}
		 }else{
			$this->session->set_flashdata('toastr',array('msg'=>$type.' error to remove','type'=>'danger'));
			if($type=="category" || $type=="tag"){
			    redirect(site_url('admin/add/'.$type));
			}
			else{
		    	redirect(site_url('admin/edit/'.$type.'/'.$id));
			}
		}
		
		}else{
			
			redirect(site_url());
		}
	}
	

	function upload_img($width='',$height=''){
	    
	    if($width='' && $height=''){
        	     $fileinfo = @getimagesize($_FILES["file"]["tmp_name"]);
                 $width = $fileinfo[0];
                 $height = $fileinfo[1];
	        }
	        
		if($this->main_model->upload_img($width,$height)){
			echo $this->main_model->upload_img($width,$height);
		}
		
	}




//TREE VIEW CATEGORY FUNCTIONS


    
    function category($type,$post_cat_id=''){
        
        
        $this->main_model->category_list(0,"",$type,$post_cat_id);
            

    
    }
    
//TAGS FUNCTION

    function tag(){
	    
	    $data = $this->data;
	    $query=$this->db->get('tag');
	    $results=$query->result_array();
	    
	        foreach($results as $key=>$list){
			echo '<tr><td><input type="checkbox" name="select_'.$key.'"></td><td><div class="edit-menu">'.$list['name'].'<p class="hide my-0"><span class="text-info">Edit</span><span class="px-2"> | </span><span class="text-danger"><a onclick="return confirm(\'Do you really want to delete?\');" href="'.site_url("admin/remove/tag/".$list['tid']).'">Delete</a></span></p></div></td><td>'.$list['description'].'</td><td>'.$list['slug'].'</td><td>0</td></tr>';
	       
	    }
	}

//FUNCTION POST

    function cidtocategory($cids){
        foreach(explode(",",$cids) as $cid){
            $categories[]=$this->main_model->get_category($cid)['name'];
        }
        
        return implode(",",$categories);
    }

    function post(){
	    
	    $logged_in=$this->session->userdata('logged_in');
		if($logged_in && ($logged_in['role']=='Admin' || $logged_in['role']=='Author')){
		    
		$data = $this->data;
		$data['title']="All Posts";
		$this->load->view('backend/header',$data);
		$this->load->view('backend/post',$data);
		$this->load->view('backend/footer',$data);
		
		}else{
			
			redirect(site_url());
		}

	}
	
	public function preview($aid='')
	{	
		$data = $this->data;
		$data['single_post']=$this->main_model->get_single_preview($aid);
		
		if($data['single_post'] && $aid!=""){
		
		$data['author']=$this->main_model->get_list('user',$data['single_post']['author']);
		$data['title']=$data['single_post']['title'];
		$data['related']=$this->home_model->get_related($data['single_post']['cid']);
		$data['breadcrumbs']['category']=$this->main_model->get_category($data['single_post']['cid']);
		$data['breadcrumbs']['parent']=$this->main_model->get_category($data['breadcrumbs']['category']['parent']);
		$data['read_also']=$this->home_model->read_also($data['single_post']['tags']);
		if($data['single_post']['meta_description']!=''){
            $data['meta_description']=$data['single_post']['meta_description']; 
		}
		if($data['single_post']['meta_keywords']!=''){
            $data['meta_keywords']=$data['single_post']['meta_keywords']; 
		}
		if($data['single_post']['site_title']!=''){
            $data['title']=$data['single_post']['site_title']; 
		}
		
		//print_r($data['read_also']);
		
		
		$this->load->view('frontend/header',$data);
		$this->load->view('frontend/post',$data);
		$this->load->view('frontend/footer',$data);
		
		}else{
		    
		   redirect(site_url('hi/not_found'));
		}

	}

    function post_list(){
	    
	    $this->db->order_by('aid','desc');
	    $query=$this->db->get('post');
	    $results=$query->result_array();
	    
	        foreach($results as $key=>$list){
			echo '<tr><td><input type="checkbox" name="select_'.$key.'"></td><td>'.$list['post_format'].'</td><td><div class="edit-menu"><b><span class="text-info">';
			if($list['status']=='Draft'){ echo '-'.$list['status'];}
			echo ' </span>'.$list['title'].'</b><p class="hide my-0"><span class="text-info"><a href="'.site_url("admin/edit/post/".$list['aid']).'">Edit</a></span><span class="px-2"> | </span><span class="text-danger"><a onclick="return confirm(\'Do you really want to delete?\');" href="'.site_url("admin/remove/post/".$list['aid']).'">Delete</a></span></p></div></td><td>'.$list['subtitle'].'</td><td>'.$this->main_model->get_list('user',$list['author'])['name'].'</td><td>'.$this->cidtocategory($list['cid']).'</td><td>'.$list['tags'].'</td><td>'.$list['slug'].'</td><td>0</td></tr>';
	       
	    }
	}


//FUNCTION PAGE

    
    function page(){
	    
	    $logged_in=$this->session->userdata('logged_in');
		if($logged_in && ($logged_in['role']=='Admin' || $logged_in['role']=='Author')){
		    
		$data = $this->data;
		
		$data['title']="All Posts";
		$this->load->view('backend/header',$data);
		$this->load->view('backend/page',$data);
		$this->load->view('backend/footer',$data);
		
		}else{
			
			redirect(site_url());
		}

	}

    function page_list(){
	    
	    
	    $query=$this->db->get('page');
	    $results=$query->result_array();
	    
	        foreach($results as $key=>$list){
			echo '<tr><td><input type="checkbox" name="select_'.$key.'"></td><td><div class="edit-menu"><b>'.$list['title'].'</b><p class="hide my-0"><span class="text-info"><a href="'.site_url("admin/edit/page/".$list['pid']).'">Edit</a></span><span class="px-2"> | </span><span class="text-danger"><a onclick="return confirm(\'Do you really want to delete?\');" href="'.site_url("admin/remove/page/".$list['pid']).'">Delete</a></span></p></div></td><td>'.$list['slug'].'</td><td>0</td></tr>';
	       
	    }
	}
	
//FUNCTION USER

    function user_list(){
	    
	    
	    $data = $this->data;
	    
	    $query=$this->db->get('user');
	    $results=$query->result_array();
	    
	        foreach($results as $key=>$list){
			echo '<tr><td><input type="checkbox" name="select_'.$key.'"></td><td><div class="edit-menu"><b>'.$list['name'].'</b><p class="hide my-0"><span class="text-info"><a href="'.site_url("admin/edit/user/".$list['uid']).'">Edit</a></span><span class="px-2"> | </span><span class="text-danger"><a onclick="return confirm(\'Do you really want to delete?\');" href="'.site_url("admin/remove/user/".$list['uid']).'">Delete</a></span></p></div></td><td>'.$list['username'].'</td><td>'.$list['email'].'</td><td>'.$list['role'].'</td><td>'.$list['status'].'</td></tr>';
	       
	    }
	}
	

//FUNCTION SETTINGS & ADVERTISEMENT

    function advertisement($action=''){
        
        $logged_in=$this->session->userdata('logged_in');
		if($logged_in && ($logged_in['role']=='Admin' || $logged_in['role']=='Author')){
		
		$data = $this->data;
		$query=$this->db->get('advertisement');
		$data['ads']=$query->row_array();
		$data['title']="Advertisement Settings";
		
		 if($action!="update"){
            
    		$this->load->view('backend/header',$data);
    		$this->load->view('backend/advertisement',$data);
    		$this->load->view('backend/footer',$data);
            
		     }elseif($action="update"){
		         
		        $result=$this->main_model->update('advertisement',1);
            		if($result['status']){
            			echo "Success!";
            		} else{
            		    echo "Failed";
            		    
            		}
		         
		         
		         
		     }
            
            
            
		}else{
			
			redirect(site_url());
		}
          
    }
    
    function settings($action=''){
        
        $logged_in=$this->session->userdata('logged_in');
		if($logged_in && ($logged_in['role']=='Admin' || $logged_in['role']=='Author')){
		
		$data = $this->data;
		$query=$this->db->get('settings');
		$data['ads']=$query->row_array();
		$data['title']="General Settings";
		
		 if($action!="update"){
            
    		$this->load->view('backend/header',$data);
    		$this->load->view('backend/settings',$data);
    		$this->load->view('backend/footer',$data);
            
		     }elseif($action="update"){
		         
		        $result=$this->main_model->update('settings',1);
            		if($result['status']){
            			echo "Success!";
            		} else{
            		    echo "Failed";
            		    
            		}
		         
		         
		         
		     }
            
            
            
		}else{
			
			redirect(site_url());
		}
          
    }
    
    
 //MEDIA FUNCTION
 
 function media(){
     
     $logged_in=$this->session->userdata('logged_in');
		if($logged_in && ($logged_in['role']=='Admin' || $logged_in['role']=='Author')){
		    
		$data = $this->data;
		
		$data['title']="Media Library";
		$data['medias']=$this->main_model->media_list();
		$this->load->view('backend/header',$data);
		$this->load->view('backend/media',$data);
		$this->load->view('backend/footer',$data);
		
		}else{
			
			redirect(site_url());
		}
     
 }

 function upload_media(){
     
 }
 
 function delete_media($mid){
     
 }
    
    
    
    
    
    
    
    
    
    
    
    
    




















}
